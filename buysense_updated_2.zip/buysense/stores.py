"""
stores.py
---------
Nearby Store Finder using OpenStreetMap (Nominatim for geocoding,
Overpass for shops). No API key is needed. If the network or these free
services fail, callers still get a Google Maps / OpenStreetMap search
LINK so the feature degrades gracefully.

Privacy: the location is used only for the request itself. It is NOT
written to the database or to disk. Cached lookups are keyed on
coordinates rounded to ~100 m and live only in Streamlit's in-memory
cache.
"""

import math
from urllib.parse import quote_plus

import requests

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

USER_AGENT = "BuySense/1.0 (student project; nearby store finder)"
NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"
TIMEOUT = 15

# BuySense category -> OpenStreetMap shop tags
CATEGORY_TO_OSM = {
    "Electronics": ["electronics", "mobile_phone", "computer"],
    "Fashion": ["clothes", "shoes", "boutique"],
    "Home Decor": ["furniture", "interior_decoration", "houseware"],
    "Books": ["books", "stationery"],
    "Fitness": ["sports", "outdoor"],
    "Beauty": ["beauty", "cosmetics", "perfumery"],
    "Sports": ["sports", "outdoor"],
    "Grocery": ["supermarket", "convenience", "greengrocer"],
    "Toys": ["toys", "games"],
    "Automotive": ["car_parts", "car", "motorcycle"],
}


def maps_search_url(category, location_text):
    """Always-available fallback: a Google Maps search link (no API)."""
    return "https://www.google.com/maps/search/" + quote_plus(f"{category} store near {location_text}")


def _geocode(place_text):
    resp = requests.get(
        NOMINATIM_URL,
        params={"q": place_text, "format": "json", "limit": 1},
        headers={"User-Agent": USER_AGENT},
        timeout=TIMEOUT,
    )
    resp.raise_for_status()
    results = resp.json()
    if not results:
        return None
    return float(results[0]["lat"]), float(results[0]["lon"]), results[0].get("display_name", "")


def _overpass(lat, lon, tags, radius_m):
    shop_filter = "|".join(tags)
    query = (
        f'[out:json][timeout:20];(node["shop"~"^({shop_filter})$"](around:{radius_m},{lat},{lon});'
        f'way["shop"~"^({shop_filter})$"](around:{radius_m},{lat},{lon}););out center 40;'
    )
    resp = requests.post(OVERPASS_URL, data={"data": query},
                         headers={"User-Agent": USER_AGENT}, timeout=TIMEOUT + 10)
    resp.raise_for_status()
    return resp.json().get("elements", [])


if st is not None:
    _geocode = st.cache_data(ttl=3600, show_spinner=False)(_geocode)
    _overpass = st.cache_data(ttl=1800, show_spinner=False)(_overpass)


def _distance_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def find_stores(category, place_text=None, lat=None, lon=None, radius_km=3):
    """
    Returns (stores, center, error). `stores` is a list of
    {"name","type","lat","lon","distance_km","address","osm_url"} sorted by
    distance; center is (lat, lon, label). error is None, or one of
    "no_location", "location_not_found", "no_stores", "network".
    """
    try:
        if lat is None or lon is None:
            if not place_text or not place_text.strip():
                return [], None, "no_location"
            geo = _geocode(place_text.strip())
            if not geo:
                return [], None, "location_not_found"
            lat, lon, label = geo
        else:
            label = ""
        # round so cache keys don't hold a precise position
        lat_r, lon_r = round(float(lat), 3), round(float(lon), 3)
        tags = CATEGORY_TO_OSM.get(category) or ["department_store", "mall"]
        elements = _overpass(lat_r, lon_r, tags, int(radius_km * 1000))
    except Exception:  # pragma: no cover - network dependent
        return [], None, "network"

    stores = []
    for el in elements:
        tags = el.get("tags") or {}
        name = tags.get("name")
        if not name:
            continue
        e_lat = el.get("lat") or (el.get("center") or {}).get("lat")
        e_lon = el.get("lon") or (el.get("center") or {}).get("lon")
        if e_lat is None or e_lon is None:
            continue
        address = ", ".join(
            x for x in (tags.get("addr:housenumber"), tags.get("addr:street"),
                        tags.get("addr:suburb") or tags.get("addr:city")) if x
        )
        stores.append(
            {
                "name": name,
                "type": (tags.get("shop") or "").replace("_", " "),
                "lat": float(e_lat),
                "lon": float(e_lon),
                "distance_km": round(_distance_km(lat_r, lon_r, float(e_lat), float(e_lon)), 2),
                "address": address,
                "osm_url": f"https://www.openstreetmap.org/{el.get('type', 'node')}/{el.get('id')}",
            }
        )
    stores.sort(key=lambda s: s["distance_km"])
    if not stores:
        return [], (lat_r, lon_r, label), "no_stores"
    return stores[:25], (lat_r, lon_r, label), None
