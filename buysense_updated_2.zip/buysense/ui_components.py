"""
ui_components.py
----------------
Reusable Streamlit pieces shared by several pages: the compare basket,
the product card with its action buttons (wishlist / compare / details)
and small formatting helpers.
"""

import html

import streamlit as st

import db
import product_details
import shopping
import templates as tpl
from i18n import t

MAX_COMPARE = 4
MIN_COMPARE = 2

# Fields kept when a product is copied into the compare basket / saved.
_KEEP_FIELDS = (
    "title", "price", "price_value", "image", "link", "source", "rating", "key",
    "reviews_count", "old_price", "old_price_value", "tag", "delivery", "snippet",
    "extensions", "condition", "product_id", "page_token", "availability",
)


def fmt_price(value):
    return f"₹{value:,.0f}" if value is not None else "—"


def compact_product(product):
    out = {k: product.get(k) for k in _KEEP_FIELDS}
    out["key"] = out.get("key") or shopping.product_key(out.get("title"))
    return out


# ---------------------- compare basket ----------------------

def get_compare_list():
    return st.session_state.setdefault("compare_list", [])


def _same(a, b):
    return a.get("key") == b.get("key") and (a.get("source") or "") == (b.get("source") or "")


def in_compare(product):
    p = compact_product(product)
    return any(_same(p, q) for q in get_compare_list())


def add_to_compare(product):
    """Returns "added", "duplicate" or "full"."""
    basket = get_compare_list()
    p = compact_product(product)
    if any(_same(p, q) for q in basket):
        return "duplicate"
    if len(basket) >= MAX_COMPARE:
        return "full"
    basket.append(p)
    return "added"


def remove_from_compare(index):
    basket = get_compare_list()
    if 0 <= index < len(basket):
        basket.pop(index)


# ---------------------- product card ----------------------

def render_product(conn, username, product, ctx, idx, category_label="General",
                   all_products=None, show_details=True):
    """
    One real product: card, rating/discount line, link, and action
    buttons. `ctx` + `idx` make widget keys unique per page/position.
    """
    tpl.live_product_card(
        html.escape(product["title"], quote=True),
        html.escape(str(product.get("price") or "")),
        html.escape(product.get("image") or "", quote=True),
        html.escape(product.get("source") or ""),
    )

    bits = []
    if product.get("rating"):
        count = product.get("reviews_count")
        bits.append(f"⭐ {product['rating']}" + (f" ({count:,})" if isinstance(count, (int, float)) else ""))
    if product.get("tag"):
        bits.append(f"🏷️ {product['tag']}")
    if product.get("availability") == "out_of_stock":
        bits.append("⛔ " + t("avail_out_of_stock"))
    elif product.get("availability") == "in_stock":
        bits.append("✅ " + t("avail_in_stock"))
    if bits:
        st.caption(" · ".join(bits))
    if product.get("link"):
        st.markdown(f"[🔗 {t('view_product')}]({product['link']})")

    col_w, col_c = st.columns(2)
    with col_w:
        if username:
            if db.is_in_wishlist(conn, username, product["title"]):
                st.caption("❤️ " + t("wishlist_title"))
            elif st.button(t("add_to_wishlist"), key=f"{ctx}_wl_{idx}"):
                db.add_to_wishlist(
                    conn, username, product["title"], category_label,
                    image_url=product.get("image"), price=product.get("price"),
                    product_link=product.get("link"),
                    price_value=product.get("price_value"),
                    product_key=product.get("key"), source=product.get("source"),
                    rating=product.get("rating"),
                    availability=product.get("availability"),
                )
                st.toast(t("added_to_wishlist"))
                st.rerun()
    with col_c:
        if in_compare(product):
            st.caption("✅ " + t("in_compare"))
        elif st.button(t("add_to_compare"), key=f"{ctx}_cmp_{idx}"):
            status = add_to_compare(product)
            if status == "full":
                st.toast(t("compare_full", n=MAX_COMPARE))
            else:
                st.toast(t("added_to_compare"))
            st.rerun()

    if show_details:
        with st.expander(t("product_details")):
            product_details.render_details(
                conn, username, product, f"{ctx}_{idx}", all_products or [], category_label
            )
