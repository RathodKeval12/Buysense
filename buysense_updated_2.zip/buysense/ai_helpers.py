"""
ai_helpers.py
-------------
Small shared layer over Groq used by every AI feature added to BuySense
(review summaries, natural-language search parsing, gift queries, image
analysis, voice transcription, the shopping assistant).

It reuses the key lookup and model fallback list from personalize.py, so
there is still only ONE credential to configure (GROQ_API_KEY).

Every function returns (result, error) instead of raising, so callers can
show a friendly message and the app keeps working without a key, offline,
or when Groq rate-limits.
"""

import json
import re

from groq import Groq

import personalize

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

LANG_NAMES = {"en": "English", "hi": "Hindi", "gu": "Gujarati"}


def get_groq_key():
    return personalize.get_groq_key()


def has_groq():
    return bool(get_groq_key())


def friendly_error(error):
    """Turns raw exception text into a short, key-free message."""
    text = str(error or "").lower()
    if not text:
        return "unknown_error"
    if "no_api_key" in text:
        return "no_api_key"
    if "429" in text or ("rate" in text and "limit" in text):
        return "rate_limited"
    if "timeout" in text or "timed out" in text:
        return "timeout"
    if "connection" in text or "network" in text or "resolve" in text:
        return "network"
    if "401" in text or "invalid api key" in text or "authentication" in text:
        return "bad_key"
    return "api_error"


def _chat_uncached(messages_json, max_tokens, temperature, json_mode, api_key):
    client = Groq(api_key=api_key, timeout=25)
    messages = json.loads(messages_json)
    last_error = None
    for model_name in personalize.PREFERRED_MODELS:
        kwargs = dict(
            model=model_name, messages=messages,
            temperature=temperature, max_tokens=max_tokens,
        )
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        try:
            response = client.chat.completions.create(**kwargs)
            return response.choices[0].message.content.strip(), None, model_name
        except Exception as exc:  # pragma: no cover - network dependent
            last_error = exc
            if json_mode:  # some models reject response_format; retry plain
                try:
                    kwargs.pop("response_format", None)
                    response = client.chat.completions.create(**kwargs)
                    return response.choices[0].message.content.strip(), None, model_name
                except Exception as exc2:
                    last_error = exc2
            continue
    return None, friendly_error(last_error), None


# Identical requests within 10 minutes reuse the previous answer (saves
# Groq calls on reruns / language or theme switches).
if st is not None:
    _chat_cached = st.cache_data(ttl=600, show_spinner=False)(_chat_uncached)
else:  # pragma: no cover
    _chat_cached = _chat_uncached


def chat(messages, max_tokens=500, temperature=0.3, json_mode=False, cache=True):
    """
    messages: list of {"role","content"}. Returns (text, error, model).
    error is None on success, else a short code such as "no_api_key",
    "rate_limited", "timeout", "network", "bad_key", "api_error".
    """
    api_key = get_groq_key()
    if not api_key:
        return None, "no_api_key", None
    payload = json.dumps(messages, ensure_ascii=False)
    fn = _chat_cached if cache else _chat_uncached
    try:
        return fn(payload, max_tokens, temperature, json_mode, api_key)
    except Exception as exc:  # pragma: no cover
        return None, friendly_error(exc), None


def parse_json(text):
    """Extracts the first JSON object from model output (handles ``` fences)."""
    if not text:
        return None
    cleaned = re.sub(r"```(?:json)?", "", text).strip()
    try:
        value = json.loads(cleaned)
        return value if isinstance(value, dict) else None
    except ValueError:
        pass
    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        try:
            value = json.loads(match.group(0))
            return value if isinstance(value, dict) else None
        except ValueError:
            return None
    return None


def error_key(error):
    """i18n key for a friendly error code (see i18n_extra.py)."""
    return {
        "no_api_key": "err_no_groq_key",
        "rate_limited": "err_rate_limited",
        "timeout": "err_timeout",
        "network": "err_network",
        "bad_key": "err_bad_key",
    }.get(error, "err_generic_ai")
