"""
product_details.py
------------------
The "Product details" panel shown under every product card:
Price History · Sellers · Reviews · Offers.

All of it comes from real data: prices stored from live searches, and —
only when the user presses the button — one SerpApi Immersive Product
lookup for sellers and review text. If the source has no data for a
section, the section says so instead of showing anything made up.
"""

import pandas as pd
import streamlit as st

import db_features as dbf
import pricing
import reviews as reviews_mod
import shopping
import templates as tpl
from ai_helpers import error_key
from i18n import t


def _fmt(value):
    return f"₹{value:,.0f}" if value is not None else "—"


def render_details(conn, username, product, ctx, all_products, category_label="General"):
    tab_price, tab_sellers, tab_reviews, tab_offers = st.tabs(
        [t("tab_price_history"), t("tab_sellers"), t("tab_reviews"), t("tab_offers")]
    )
    with tab_price:
        render_price_history(conn, product.get("key"), f"{ctx}_ph")
    with tab_sellers:
        render_sellers(product, ctx, all_products)
    with tab_reviews:
        render_reviews(conn, product, ctx)
    with tab_offers:
        render_offers(product)


# ---------------------------------------------------------------
# Price history
# ---------------------------------------------------------------

def render_price_history(conn, product_key, ctx):
    """Stats + chart for one product key. Shared with the Price Tracker page."""
    if not product_key:
        st.info(t("price_history_insufficient", n=0))
        return
    try:
        points = dbf.get_price_points(conn, product_key)
    except Exception:
        st.warning(t("db_error"))
        return
    if points.empty:
        st.info(t("price_history_insufficient", n=0))
        return

    seller = None
    sellers = dbf.get_price_sellers(conn, product_key)
    if len(sellers) > 1:
        all_label = t("all_sellers_lowest")
        choice = st.selectbox(
            t("seller"), [all_label] + sellers, key=f"{ctx}_seller_pick"
        )
        seller = None if choice == all_label else choice

    series = pricing.build_series(points, seller)
    stats = pricing.compute_price_stats(series)

    if not stats["sufficient"]:
        tpl.metric_card(t("current_price"), _fmt(stats["current"]))
        st.info(t("price_history_insufficient", n=stats["points"]))
        return

    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        tpl.metric_card(t("current_price"), _fmt(stats["current"]))
    with c2:
        tpl.metric_card(t("previous_price"), _fmt(stats["previous"]))
    with c3:
        tpl.metric_card(t("lowest_price"), _fmt(stats["lowest"]))
    with c4:
        tpl.metric_card(t("highest_price"), _fmt(stats["highest"]))
    with c5:
        pct = stats["change_pct"]
        arrow = "▲" if (pct or 0) > 0 else ("▼" if (pct or 0) < 0 else "■")
        tpl.metric_card(t("price_change"), f"{arrow} {pct:+.1f}%" if pct is not None else "—")

    fig = pricing.plot_price_history(series, st.session_state.get("theme", "dark"))
    if fig is not None:
        st.plotly_chart(fig, use_container_width=True, key=f"{ctx}_chart")
    else:  # Plotly not installed -> built-in chart
        st.line_chart(series.set_index("recorded_at")["price"])
    st.caption(t("price_history_note", n=stats["points"]))


# ---------------------------------------------------------------
# Details (sellers + reviews) – one SerpApi call, only on request
# ---------------------------------------------------------------

def _details_cache():
    return st.session_state.setdefault("details_cache", {})


def _load_details_button(product, ctx, where):
    token = product.get("page_token")
    if not token:
        return None
    cached = _details_cache().get(token)
    if cached is not None:
        return cached
    if st.button(t("load_details_btn"), key=f"{ctx}_load_details_{where}"):
        with st.spinner(t("loading")):
            details, err = shopping.fetch_product_details(token)
        if details is None:
            if err == "no_api_key":
                st.error(t("err_no_serpapi_key"))
            elif err == "no_details_token":
                st.warning(t("err_details_failed"))
            else:
                st.warning(t(shopping.error_i18n_key(err)))
            return None
        _details_cache()[token] = details
        st.rerun()
    st.caption(t("load_details_hint"))
    return None


# ---------------------------------------------------------------
# Sellers
# ---------------------------------------------------------------

def similar_listings(product, all_products):
    """Other listings of the SAME product found in the current search."""
    rows = []
    for p in all_products or []:
        if shopping.title_similarity(p.get("title"), product.get("title")) >= 0.6:
            rows.append(
                {
                    "seller": p.get("source") or "—",
                    "price_value": p.get("price_value"),
                    "rating": p.get("rating"),
                    "link": p.get("link") or "",
                    "availability": p.get("availability"),
                }
            )
    return rows


def seller_dataframe(rows, sort_by):
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    avail_map = {"in_stock": t("avail_in_stock"), "out_of_stock": t("avail_out_of_stock")}
    df["availability"] = df["availability"].map(avail_map).fillna(t("avail_unknown"))
    if sort_by == "rating":
        df = df.sort_values("rating", ascending=False, na_position="last")
    else:
        df = df.sort_values("price_value", ascending=True, na_position="last")
    return df.rename(
        columns={
            "seller": t("seller"), "price_value": t("price"), "rating": t("rating"),
            "link": t("link"), "availability": t("availability"),
        }
    )[[t("seller"), t("price"), t("rating"), t("availability"), t("link")]]


def render_sellers(product, ctx, all_products):
    details = _load_details_button(product, ctx, "sellers")
    rows = []
    source_note = t("sellers_from_search")
    if details and details.get("sellers"):
        rows = details["sellers"]
        source_note = t("sellers_from_details")
    else:
        rows = similar_listings(product, all_products)

    if len({r["seller"] for r in rows}) < 2:
        st.info(t("sellers_single"))
        if rows:
            r = rows[0]
            st.caption(f"{r['seller']} · {_fmt(r.get('price_value'))}")
        return

    sort_choice = st.radio(
        t("sort_by"), ["price", "rating"], horizontal=True, key=f"{ctx}_seller_sort",
        format_func=lambda v: t("sort_price") if v == "price" else t("sort_rating"),
    )
    df = seller_dataframe(rows, sort_choice)
    st.dataframe(
        df, use_container_width=True, hide_index=True,
        column_config={
            t("price"): st.column_config.NumberColumn(format="₹%.0f"),
            t("link"): st.column_config.LinkColumn(t("link"), display_text="🔗"),
        },
    )
    st.caption(source_note)


# ---------------------------------------------------------------
# Reviews
# ---------------------------------------------------------------

def render_reviews(conn, product, ctx):
    lang = st.session_state.get("lang", "en")
    if product.get("rating"):
        count = product.get("reviews_count")
        st.caption(
            t("source_rating", rating=product["rating"],
              count=f"{count:,}" if isinstance(count, (int, float)) else "?")
        )

    details = _load_details_button(product, ctx, "reviews")
    if not product.get("page_token"):
        st.info(t("reviews_unavailable"))
        return
    if details is None:
        return

    revs = details.get("reviews") or []
    if not revs:
        st.info(t("reviews_unavailable"))
        return

    summary = reviews_mod.get_cached_summary(conn, product.get("key"), revs, lang)
    if summary is None:
        if not st.button(t("summarize_reviews_btn"), key=f"{ctx}_sum_btn"):
            st.caption(t("reviews_found", n=len(revs)))
            return
        with st.spinner(t("loading")):
            summary, status = reviews_mod.summarize_reviews(
                conn, product.get("key"), product["title"], revs, lang
            )
        if summary is None:
            if status == "too_few_reviews":
                st.info(t("reviews_too_few"))
            else:
                st.warning(t(error_key(status)))
            return

    st.markdown(f"**{t('positive_points')}**")
    for point in summary.get("positive") or []:
        st.markdown(f"- {point}")
    if not summary.get("positive"):
        st.caption(t("none_mentioned"))
    st.markdown(f"**{t('negative_points')}**")
    for point in summary.get("negative") or []:
        st.markdown(f"- {point}")
    if not summary.get("negative"):
        st.caption(t("none_mentioned"))
    st.markdown(f"**{t('overall_review_summary')}**")
    st.markdown(f"- {summary.get('overall') or '—'}")
    st.caption(t("review_ai_note", n=len(revs)))


# ---------------------------------------------------------------
# Offers
# ---------------------------------------------------------------

def compute_offer(product):
    """Real offer data only. Returns dict with original/current/discount."""
    current = product.get("price_value")
    original = product.get("old_price_value")
    discount_pct = None
    if current is not None and original and original > current:
        discount_pct = (original - current) / original * 100
    return {"current": current, "original": original, "discount_pct": discount_pct}


def render_offers(product):
    offer = compute_offer(product)
    has_data = offer["original"] or product.get("tag")

    c1, c2, c3 = st.columns(3)
    with c1:
        tpl.metric_card(t("original_price"), _fmt(offer["original"]) if offer["original"] else "—")
    with c2:
        tpl.metric_card(t("current_price"), _fmt(offer["current"]))
    with c3:
        d = offer["discount_pct"]
        tpl.metric_card(t("discount"), f"{d:.0f}%" if d is not None else "—")

    if product.get("tag"):
        st.markdown(f"🏷️ **{t('offer_label')}:** {product['tag']}")
    notes = [e for e in (product.get("extensions") or []) if any(
        w in e.lower() for w in ("off", "offer", "coupon", "deal", "save", "cashback"))]
    for note in notes:
        st.markdown(f"- {note}")
    if product.get("delivery"):
        st.caption(f"🚚 {product['delivery']}")
    if not has_data and not notes:
        st.info(t("no_offer_data"))
    else:
        st.caption(t("no_coupon_codes"))
    avail = product.get("availability")
    st.caption(
        f"{t('availability')}: "
        + {"in_stock": t("avail_in_stock"), "out_of_stock": t("avail_out_of_stock")}.get(
            avail, t("avail_unknown"))
    )
