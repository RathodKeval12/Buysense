"""
multimodal.py
-------------
Image-based product search (Groq vision model) and voice search (Groq
Whisper speech-to-text).

Privacy: uploaded images and recorded audio are held in memory only for
the duration of the request — nothing is written to disk or to the
database. Only the resulting TEXT query is passed on.

Both features are optional: without GROQ_API_KEY, or when the model /
network fails, they return a friendly error code instead of raising.

Model names can be overridden with the optional settings
GROQ_VISION_MODEL / GROQ_STT_MODEL (env var or secrets) because Groq
retires models from time to time.
"""

import base64
import os

from groq import Groq

import ai_helpers

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

DEFAULT_VISION_MODELS = [
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "meta-llama/llama-4-maverick-17b-128e-instruct",
]
DEFAULT_STT_MODELS = ["whisper-large-v3-turbo", "whisper-large-v3"]

MAX_IMAGE_BYTES = 4 * 1024 * 1024  # Groq's base64 image limit is ~4MB
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif"}


def _setting(name):
    value = os.environ.get(name, "")
    if not value and st is not None:
        try:
            value = st.secrets.get(name, "")
        except Exception:
            value = ""
    return value


def _models(setting_name, defaults):
    override = _setting(setting_name)
    return [override] + [m for m in defaults if m != override] if override else list(defaults)


# ------------------------------ image ------------------------------

VISION_PROMPT = (
    "You help a shopper search for a product from a photo. Describe ONLY what is "
    "visible. Do not claim an exact model number unless it is clearly readable in "
    "the image. If the image is not a product (e.g. a selfie, landscape, document), "
    'say so. Reply with JSON only:\n'
    '{"is_product": true/false, "category": "general product type", '
    '"brand": "brand only if a logo/text is clearly visible, else empty", '
    '"characteristics": ["colour, material, style, visible features"], '
    '"confidence": "low|medium|high", '
    '"search_query": "short English Google Shopping query"}'
)


def analyze_product_image(image_bytes, mime_type):
    """
    Returns (result_dict | None, error_code | None). error codes:
    no_api_key, unsupported_image, image_too_large, not_a_product,
    rate_limited, timeout, network, bad_key, api_error.
    """

    api_key = ai_helpers.get_groq_key()
    if not api_key:
        return None, "no_api_key"
    if mime_type not in ALLOWED_IMAGE_TYPES:
        return None, "unsupported_image"
    if len(image_bytes) > MAX_IMAGE_BYTES:
        return None, "image_too_large"

    data_url = f"data:{mime_type};base64,{base64.b64encode(image_bytes).decode('ascii')}"
    client = Groq(api_key=api_key, timeout=40)
    last_error = None
    for model in _models("GROQ_VISION_MODEL", DEFAULT_VISION_MODELS):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": VISION_PROMPT},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                }],
                temperature=0.1,
                max_tokens=400,
            )
            data = ai_helpers.parse_json(response.choices[0].message.content)
            if not data:
                last_error = "invalid response"
                continue
            result = {
                "is_product": bool(data.get("is_product", True)),
                "category": str(data.get("category") or "").strip(),
                "brand": str(data.get("brand") or "").strip(),
                "characteristics": [str(c).strip() for c in (data.get("characteristics") or []) if str(c).strip()][:6],
                "confidence": str(data.get("confidence") or "low").lower(),
                "search_query": str(data.get("search_query") or "").strip(),
                "model": model,
            }
            if not result["is_product"] or not result["search_query"]:
                return result, "not_a_product"
            return result, None
        except Exception as exc:  # pragma: no cover - network dependent
            last_error = exc
            continue
    return None, ai_helpers.friendly_error(last_error)


# ------------------------------ voice ------------------------------

def transcribe_audio(audio_bytes, filename="speech.wav"):
    """Speech -> text with Groq Whisper. Returns (text | None, error_code | None)."""
    api_key = ai_helpers.get_groq_key()
    if not api_key:
        return None, "no_api_key"
    if not audio_bytes:
        return None, "empty_audio"

    client = Groq(api_key=api_key, timeout=40)
    last_error = None
    for model in _models("GROQ_STT_MODEL", DEFAULT_STT_MODELS):
        try:
            result = client.audio.transcriptions.create(
                file=(filename, audio_bytes),
                model=model,
                response_format="text",
                temperature=0.0,
            )
            text = result if isinstance(result, str) else getattr(result, "text", "")
            text = (text or "").strip()
            if not text:
                return None, "empty_audio"
            return text, None
        except Exception as exc:  # pragma: no cover - network dependent
            last_error = exc
            continue
    return None, ai_helpers.friendly_error(last_error)


def audio_input_supported():
    """st.audio_input needs Streamlit >= 1.40."""
    return st is not None and hasattr(st, "audio_input")
