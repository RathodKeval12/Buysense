"""
page_gift.py
------------
AI Gift Recommendation. Groq (or a template when no key is set) only
writes the shopping QUERY; the gift ideas shown are real products from
the live Google Shopping search.
"""

import streamlit as st

import gift
import model as ml
import reco_flow
import templates as tpl
from i18n import t

RESULT_KEY = "gift_results"


def render(conn, username):
    tpl.hero(t("gift_title"), t("gift_subtitle"), pill_text=t("gift_pill"))

    with st.form("gift_form"):
        c1, c2 = st.columns(2)
        with c1:
            occasion = st.selectbox(t("gift_occasion"), gift.OCCASIONS,
                                    format_func=lambda v: t(f"occ_{v.lower().replace(' ', '_')}"))
            recipient = st.selectbox(t("gift_recipient"), gift.RECIPIENTS,
                                     format_func=lambda v: t(f"rec_{v.lower()}"))
            category = st.selectbox(t("gift_category"), [""] + ml.CATEGORY_OPTIONS,
                                    format_func=lambda v: v or t("any_category"))
        with c2:
            budget = st.number_input(t("gift_budget"), min_value=0.0, value=2000.0, step=500.0)
            interests = st.text_input(t("gift_interests"), placeholder="music, cooking, travel")
        go = st.form_submit_button(t("gift_find_btn"))

    if go:
        query, source = gift.build_gift_query(occasion, recipient, interests, category, budget)
        st.caption(t("gift_query_ai" if source == "ai" else "gift_query_template", query=query))
        profile = {
            "product_query": query,
            "interests": interests.strip(),
            "preferred_categories": category,
            "budget_max": budget if budget > 0 else None,
            "price_sensitivity": "medium",
            "min_rating": 0,
        }
        reco_flow.run_recommendation(
            conn, username, profile, category_label=category or "Gifts",
            result_key=RESULT_KEY, query_override=query,
        )

    reco_flow.render_results(conn, username, result_key=RESULT_KEY, ctx="gift")
