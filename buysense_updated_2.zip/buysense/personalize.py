"""
personalize.py
---------------
GenAI personalization layer for the Recommendation page.

This does NOT choose or invent products. The real products always
come from shopping.py's live SerpApi Google Shopping search, ranked
by model.rank_products() against the shopper's profile — this module
only writes a short, natural-language explanation of that ranking
using the shopper's own profile plus the real products already found.

Uses the same GROQ_API_KEY already configured for the Chatbot page —
no new credential to set up. If it isn't configured, or every model
call fails, get_personalized_insight() returns (None, reason) instead
of raising, so the Recommendation page keeps working exactly as
before, just without this optional tip.
"""

import os

from groq import Groq

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

# Same fallback order used on the Chatbot page, kept here too so this
# module works even if that page's model list ever changes.
PREFERRED_MODELS = [
    "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "openai/gpt-oss-20b",
    "openai/gpt-oss-120b",
]


def get_groq_key():
    key = os.environ.get("GROQ_API_KEY", "")
    if not key and st is not None:
        try:
            key = st.secrets.get("GROQ_API_KEY", "")
        except Exception:
            key = ""
    return key


def _build_prompt(profile, query, products):
    product_lines = "\n".join(
        f"- {p.get('title')} ("
        + (p.get("price") or "price N/A")
        + (f", {p['rating']}★" if p.get("rating") else "")
        + (f", from {p['source']}" if p.get("source") else "")
        + ")"
        for p in products
    ) or "(no specific products available)"

    return f"""You are BuySense's personalization assistant. A live Google
Shopping search for "{query}" has already been run via SerpApi and the
real results below have already been ranked against this shopper's
profile — do NOT invent, rename, reprice, or add any product. Only
discuss the products actually listed below.

Shopper profile:
- Interests: {profile.get('interests') or 'not specified'}
- Preferred categories: {profile.get('preferred_categories') or 'not specified'}
- Budget (max): {profile.get('budget_max') or 'not specified'}
- Preferred brands: {profile.get('brand_preference') or 'not specified'}
- Price sensitivity: {profile.get('price_sensitivity') or 'medium'}
- Minimum rating preference: {profile.get('min_rating') or 'not specified'}

Top-ranked real products for this search:
{product_lines}

In 2-3 short sentences (max ~80 words), plain text, no headers or
bullet points: say which ONE of the listed products best fits this
specific shopper and briefly why, then add one practical tip tailored
to their budget, price sensitivity, or brand preference."""


def _call_groq(prompt, api_key):
    client = Groq(api_key=api_key)
    last_error = None
    for model_name in PREFERRED_MODELS:
        try:
            response = client.chat.completions.create(
                model=model_name,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=180,
            )
            return response.choices[0].message.content.strip(), None
        except Exception as exc:  # pragma: no cover - network/credentials dependent
            last_error = exc
            continue
    return None, str(last_error) if last_error else "unknown_error"


# Cache identical (prompt, key) pairs briefly so re-rendering the same
# result (theme/lang switches, reruns) doesn't re-spend API calls.
if st is not None:
    _call_groq = st.cache_data(ttl=600, show_spinner=False)(_call_groq)


def get_personalized_insight(profile, query, products):
    """
    profile: dict of the shopper's saved/submitted profile fields
        (interests, preferred_categories, budget_max, brand_preference,
        price_sensitivity, min_rating).
    query: the search string sent to SerpApi Google Shopping.
    products: list of real product dicts returned by shopping.py,
        already ranked by model.rank_products() (pass the top ~5).

    Returns (text, error): text is None if GROQ_API_KEY isn't set or
    every model call failed; error names why, for a quiet UI fallback.
    """
    api_key = get_groq_key()
    if not api_key:
        return None, "no_api_key"

    prompt = _build_prompt(profile, query, products)
    text, error = _call_groq(prompt, api_key)
    return text, error
