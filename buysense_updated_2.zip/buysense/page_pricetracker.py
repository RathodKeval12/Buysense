"""
page_pricetracker.py
--------------------
Price Tracker: price history for products you've seen, plus an overview
of your price / availability alerts and notifications. Alerts themselves
are created per wishlist item on the Wishlist page.
"""

import pandas as pd
import streamlit as st

import db_features as dbf
import product_details
import templates as tpl
from i18n import t


def render(conn, username):
    tpl.hero(t("tracker_title"), t("tracker_subtitle"), pill_text=t("tracker_pill"))
    if not username:
        st.warning(t("enter_name_view"))
        return

    tab_hist, tab_alerts = st.tabs([t("tab_price_history"), t("tab_my_alerts")])

    with tab_hist:
        try:
            tracked = dbf.get_tracked_products(conn, username)
        except Exception:
            st.error(t("db_error"))
            tracked = []
        if not tracked:
            st.info(t("tracker_empty"))
        else:
            labels = {key: f"{title[:70]}  ({n})" for key, title, n in tracked}
            choice = st.selectbox(
                t("tracker_pick"), list(labels), format_func=lambda k: labels[k], key="pt_pick"
            )
            product_details.render_price_history(conn, choice, "pt")

    with tab_alerts:
        wl = dbf.get_wishlist_advanced(conn, username)
        alerts = wl[(wl["PriceAlertOn"].notna()) | (wl["AvailAlertOn"].notna())] if not wl.empty else wl
        if alerts.empty:
            st.info(t("alerts_empty"))
        else:
            rows = []
            for _, r in alerts.iterrows():
                cur = r["CurrentPriceValue"]
                target = r["TargetPrice"]
                reached = cur is not None and target is not None and cur <= target
                rows.append({
                    t("product"): r["Item"][:60],
                    t("target_price"): target,
                    t("current_price"): cur,
                    t("price_alert"): ("🟢 " if r["PriceAlertOn"] == 1 else "⚪ ") + (t("target_reached") if reached else t("watching")) if target is not None else "—",
                    t("avail_alert"): ("🟢 " + t("alert_on")) if r["AvailAlertOn"] == 1 else "—",
                })
            st.dataframe(
                pd.DataFrame(rows), use_container_width=True, hide_index=True,
                column_config={
                    t("target_price"): st.column_config.NumberColumn(format="₹%.0f"),
                    t("current_price"): st.column_config.NumberColumn(format="₹%.0f"),
                },
            )
            st.caption(t("alerts_manage_hint"))

        st.write("")
        tpl.section_title("🔔 " + t("notification_history"))
        notes = dbf.get_notifications(conn, username, limit=30)
        if not notes:
            st.caption(t("no_notifications"))
        for _, kind, message, link, created, is_read in notes:
            icon = "📉" if kind == "price_drop" else "📦"
            st.markdown(f"{icon} {message}  ·  _{created}_" + (f"  ·  [{t('view_product')}]({link})" if link else ""))
