"""
reviews.py
----------
AI Review Summarizer.

Only REAL review text returned by the product source (SerpApi's Google
Immersive Product API, via shopping.fetch_product_details) is ever sent
to Groq. If the source returns no review text, no summary is produced —
we never ask the model to "imagine" reviews.

Summaries are cached in the review_summaries table (keyed by product,
language and a hash of the review text), so reopening a product or
switching tabs doesn't spend another Groq call.
"""

import hashlib

import ai_helpers
import db_features as dbf

MAX_REVIEWS = 25
MAX_CHARS_PER_REVIEW = 400
MIN_REVIEWS = 2  # one review isn't enough to "summarise"


def reviews_hash(reviews):
    joined = "\n".join(r.get("text", "") for r in reviews)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()[:32]


def _build_messages(title, reviews, lang):
    lines = []
    for i, r in enumerate(reviews[:MAX_REVIEWS], 1):
        rating = f" [{r['rating']}/5]" if r.get("rating") else ""
        lines.append(f"{i}.{rating} {r['text'][:MAX_CHARS_PER_REVIEW]}")
    language = ai_helpers.LANG_NAMES.get(lang, "English")
    system = (
        "You summarise customer reviews. Use ONLY the reviews provided by the "
        "user. Do not add facts, specifications, prices or opinions that are "
        "not stated in those reviews. If the reviews do not mention a "
        "negative, return an empty list for it. Reply with JSON only."
    )
    user = (
        f"Product: {title}\n\nReviews:\n" + "\n".join(lines) + "\n\n"
        f"Write the answer in {language}. Return exactly this JSON shape:\n"
        '{"positive": ["short point", ...], "negative": ["short point", ...], '
        '"overall": "2-3 sentence neutral summary"}\n'
        "Max 5 points per list, each under 20 words."
    )
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def _clean_summary(data):
    if not isinstance(data, dict):
        return None
    pos = [str(x).strip() for x in (data.get("positive") or []) if str(x).strip()][:5]
    neg = [str(x).strip() for x in (data.get("negative") or []) if str(x).strip()][:5]
    overall = str(data.get("overall") or "").strip()
    if not (pos or neg or overall):
        return None
    return {"positive": pos, "negative": neg, "overall": overall}


def summarize_reviews(conn, product_key, title, reviews, lang="en"):
    """
    Returns (summary_dict_or_None, status). status is one of:
      "ok" / "cached"          -> summary is a dict
      "no_reviews"             -> source provided no review text
      "too_few_reviews"        -> fewer than MIN_REVIEWS review texts
      an error code from ai_helpers ("no_api_key", "rate_limited", ...)
    """
    reviews = [r for r in (reviews or []) if r.get("text")]
    if not reviews:
        return None, "no_reviews"
    if len(reviews) < MIN_REVIEWS:
        return None, "too_few_reviews"

    rhash = reviews_hash(reviews[:MAX_REVIEWS])
    try:
        cached = dbf.get_cached_review_summary(conn, product_key, lang, rhash)
    except Exception:
        cached = None
    if cached:
        return cached, "cached"

    text, error, model = ai_helpers.chat(
        _build_messages(title, reviews, lang),
        max_tokens=600, temperature=0.2, json_mode=True,
    )
    if error:
        return None, error
    summary = _clean_summary(ai_helpers.parse_json(text))
    if summary is None:
        return None, "api_error"
    try:
        dbf.save_review_summary(conn, product_key, lang, rhash, summary, model)
    except Exception:
        pass
    return summary, "ok"


def get_cached_summary(conn, product_key, reviews, lang="en"):
    """Cache-only lookup (no Groq call). Returns the summary dict or None."""
    reviews = [r for r in (reviews or []) if r.get("text")]
    if len(reviews) < MIN_REVIEWS:
        return None
    try:
        return dbf.get_cached_review_summary(
            conn, product_key, lang, reviews_hash(reviews[:MAX_REVIEWS])
        )
    except Exception:
        return None
