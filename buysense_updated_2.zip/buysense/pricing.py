"""
pricing.py
----------
Price history statistics + chart, and the alert engine that powers
Price Drop Alerts and Availability Alerts.

Everything is computed from prices that were really observed in live
SerpApi searches and stored by db_features.record_price(). Nothing is
estimated or filled in: with fewer than two observations the UI shows
"insufficient history" instead of a made-up trend.

Alert rules (to avoid repeated alerts for the same price event):
  * Price alert fires when current price <= target AND either no alert
    has been sent yet for this target, or the price fell FURTHER than the
    price we last alerted on. If the price rises back above the target,
    the marker is cleared so a future drop can alert again.
  * Availability alert fires only on a transition from a *known*
    "out_of_stock" to a *known* "in_stock". Unknown stays unknown.
"""

import sqlite3

import db
import db_features as dbf
import notify
import shopping
from i18n import t

try:  # Plotly is optional: the UI falls back to Streamlit's own chart.
    import plotly.graph_objects as go
except Exception:  # pragma: no cover
    go = None


# ---------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------

def build_series(points_df, seller=None):
    """
    points_df: output of db_features.get_price_points().
    seller=None  -> one point per day = the LOWEST price any seller listed
                    that day (so the line isn't a zig-zag between sellers).
    seller=name  -> that seller's own observations.
    Returns a DataFrame [recorded_at, price].
    """
    if points_df is None or points_df.empty:
        return points_df
    df = points_df
    if seller:
        df = df[df["source"] == seller]
        return df[["recorded_at", "price"]].reset_index(drop=True)
    daily = df.assign(day=df["recorded_at"].dt.date).groupby("day", as_index=False).agg(
        recorded_at=("recorded_at", "max"), price=("price", "min")
    )
    return daily[["recorded_at", "price"]].reset_index(drop=True)


def compute_price_stats(series_df):
    """
    Returns a dict:
        points, sufficient (>=2 points), current, previous, lowest, highest,
        change_pct (current vs previous), change_abs
    Values are None when there isn't enough real data.
    """
    empty = {
        "points": 0, "sufficient": False, "current": None, "previous": None,
        "lowest": None, "highest": None, "change_pct": None, "change_abs": None,
    }
    if series_df is None or series_df.empty:
        return empty
    prices = list(series_df["price"])
    stats = dict(empty)
    stats.update(
        points=len(prices),
        current=prices[-1],
        lowest=min(prices),
        highest=max(prices),
    )
    if len(prices) >= 2:
        prev = prices[-2]
        stats["sufficient"] = True
        stats["previous"] = prev
        stats["change_abs"] = prices[-1] - prev
        stats["change_pct"] = ((prices[-1] - prev) / prev * 100) if prev else None
    return stats


def price_change_pct(old, new):
    """% change from old to new (None if not computable)."""
    try:
        if old in (None, 0) or new is None:
            return None
        return (float(new) - float(old)) / float(old) * 100
    except (TypeError, ValueError):
        return None


def plot_price_history(series_df, theme="dark", title=""):
    """Plotly line chart (transparent background, matches app theme).
    Returns None when Plotly isn't installed."""
    if go is None:
        return None
    is_light = theme == "light"
    text = "#2A2438" if is_light else "#EEEEEE"
    grid = "rgba(0,0,0,0.08)" if is_light else "rgba(255,255,255,0.10)"
    fig = go.Figure(
        go.Scatter(
            x=series_df["recorded_at"],
            y=series_df["price"],
            mode="lines+markers",
            line=dict(color="#7C3AED", width=3),
            marker=dict(size=8, color="#FB923C"),
            hovertemplate="%{x|%d %b %Y %H:%M}<br>₹%{y:,.0f}<extra></extra>",
        )
    )
    fig.update_layout(
        title=title,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=text),
        margin=dict(l=10, r=10, t=40, b=10),
        height=340,
        xaxis=dict(gridcolor=grid),
        yaxis=dict(gridcolor=grid, tickprefix="₹"),
    )
    return fig


# ---------------------------------------------------------------
# Alert engine
# ---------------------------------------------------------------

def _fmt(price):
    return f"₹{price:,.0f}" if price is not None else "—"


def _notify(conn, username, kind, message, link, email_subject, email_lines, lang):
    """Stores the in-app notification and emails if the user opted in."""
    dbf.add_notification(conn, username, kind, message, link)
    email_status = None
    if db.get_email_notify_pref(conn, username):
        sent, info = notify.send_alert_email(
            db.get_user_email(conn, username), username, email_subject, email_lines
        )
        email_status = "sent" if sent else info
    return email_status


def evaluate_alerts(conn, username, products, lang="en"):
    """
    Compares a list of REAL live products against the user's wishlist:
      * refreshes each matched wishlist item's current price,
      * fires price-drop alerts and back-in-stock alerts.
    Returns a list of event dicts {"kind", "item", "price", "message", "email"}.
    Never raises on database problems.
    """
    events = []
    if not username or not products:
        return events
    try:
        wl = dbf.get_wishlist_advanced(conn, username)
        if wl.empty:
            return events
        price_alerts = {a[1]: a for a in dbf.get_active_price_alerts(conn, username)}
        avail_alerts = {a[1]: a for a in dbf.get_active_availability_alerts(conn, username)}

        for _, row in wl.iterrows():
            match = shopping.find_matching_product(products, row["Item"], row.get("Source"))
            if not match:
                continue
            wid = int(row["ID"])
            price = match.get("price_value")
            link = match.get("link") or row.get("Link")

            if price is not None:
                dbf.set_wishlist_current_price(conn, wid, price)
                dbf.record_price(
                    conn, match.get("key"), match.get("title") or row["Item"],
                    match.get("source"), price, username,
                )

            if match.get("availability"):
                dbf.set_wishlist_availability(conn, wid, match["availability"])

            # ---- price drop ----
            alert = price_alerts.get(wid)
            if alert and price is not None:
                alert_id, _, item_name, _, _, target, last_notified = alert
                if price <= target:
                    fresh_drop = last_notified is None or price < last_notified - 0.005
                    if fresh_drop:
                        msg = t("alert_price_drop_msg", lang=lang, item=item_name,
                                price=_fmt(price), target=_fmt(target))
                        email = _notify(
                            conn, username, "price_drop", msg, link,
                            f"BuySense: price drop — {item_name[:60]}",
                            [msg, f"Seller: {match.get('source') or '—'}", f"Link: {link or '—'}"],
                            lang,
                        )
                        dbf.mark_price_checked(conn, alert_id, price, notified=True)
                        events.append({"kind": "price_drop", "item": item_name,
                                       "price": price, "message": msg, "email": email})
                    else:
                        dbf.mark_price_checked(conn, alert_id, price, notified=False)
                else:
                    if last_notified is not None:
                        dbf.clear_price_notified(conn, alert_id)
                    dbf.mark_price_checked(conn, alert_id, price, notified=False)

            # ---- back in stock ----
            avail = avail_alerts.get(wid)
            status = match.get("availability")
            if avail and status:
                alert_id, _, item_name, _, _, last_status = avail
                if last_status == "out_of_stock" and status == "in_stock":
                    msg = t("alert_back_in_stock_msg", lang=lang, item=item_name)
                    email = _notify(
                        conn, username, "back_in_stock", msg, link,
                        f"BuySense: back in stock — {item_name[:60]}",
                        [msg, f"Link: {link or '—'}"], lang,
                    )
                    dbf.update_availability_status(conn, alert_id, status, notified=True)
                    events.append({"kind": "back_in_stock", "item": item_name,
                                   "price": price, "message": msg, "email": email})
                else:
                    dbf.update_availability_status(conn, alert_id, status)
    except sqlite3.Error:
        pass
    return events


def check_wishlist_now(conn, username, lang="en", max_items=8, only_alerts=True):
    """
    Explicit "check now": runs one (cached) live search per wishlist item
    that has an alert, then evaluates alerts. Capped to protect SerpApi
    credits. only_alerts=False refreshes every wishlist item's current
    price instead. Returns (events, items_checked, error_or_None).
    """
    if not shopping.get_serpapi_key():
        return [], 0, "no_api_key"
    events, checked, error = [], 0, None
    try:
        wl = dbf.get_wishlist_advanced(conn, username)
    except sqlite3.Error:
        return [], 0, "db_error"
    if only_alerts:
        wl = wl[(wl["PriceAlertOn"] == 1) | (wl["AvailAlertOn"] == 1)]
    for _, row in wl.head(max_items).iterrows():
        products, err = shopping.search_products(row["Item"], num_results=10)
        checked += 1
        if err and err != "no_results":
            error = err
            continue
        events += evaluate_alerts(conn, username, products, lang=lang)
    return events, checked, error
