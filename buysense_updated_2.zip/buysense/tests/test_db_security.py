import hashlib
import os
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta

from conftest import DBTestCase  # noqa: F401
import db
import db_features as dbf


class TestPasswords(DBTestCase):
    def test_new_hash_is_salted_and_verifies(self):
        h1, h2 = db.hash_password("Secret123!"), db.hash_password("Secret123!")
        self.assertNotEqual(h1, h2)
        self.assertTrue(h1.startswith("pbkdf2_sha256$"))
        self.assertEqual(db.check_hash("Secret123!", h1), (True, False))
        self.assertEqual(db.check_hash("wrong", h1), (False, False))

    def test_signup_login_roundtrip(self):
        self.make_user("alice")
        self.assertTrue(db.verify_user(self.conn, "alice", "Passw0rd!"))
        self.assertFalse(db.verify_user(self.conn, "alice", "nope"))
        self.assertFalse(db.verify_user(self.conn, "ghost", "Passw0rd!"))
        stored = self.conn.execute("select password_hash from users where username='alice'").fetchone()[0]
        self.assertNotIn("Passw0rd!", stored)

    def test_duplicate_and_lookalike_usernames_rejected(self):
        self.make_user("Alice")
        self.assertFalse(db.create_user(self.conn, "alice", "Passw0rd!", "a@b.co", "q", "a"))
        self.assertFalse(db.create_user(self.conn, "Alice", "Passw0rd!", "a@b.co", "q", "a"))

    def test_username_policy_blocks_html_and_odd_names(self):
        for bad in ("<img src=x onerror=alert(1)>", "ab", "has space", "x" * 40, "", None, "bob'--"):
            self.assertFalse(db.create_user(self.conn, bad, "Passw0rd!", "a@b.co", "q", "a"), repr(bad))
        self.assertTrue(db.create_user(self.conn, "good.name-1_x", "Passw0rd!", "a@b.co", "q", "a"))

    def test_sql_injection_strings_are_inert(self):
        self.make_user("bob")
        for evil in ("' OR '1'='1", "bob'--", "x'; DROP TABLE users;--"):
            self.assertFalse(db.verify_user(self.conn, evil, evil))
        self.assertEqual(self.conn.execute("select count(*) from users where username='bob'").fetchone()[0], 1)

    def test_password_policy(self):
        self.assertEqual(db.validate_new_password("abc"), "too_short")
        self.assertEqual(db.validate_new_password("abcdefgh"), "too_weak")
        self.assertIsNone(db.validate_new_password("Abcdefg1"))
        self.assertEqual(db.validate_new_password(None), "too_short")

    def test_reset_password_and_security_answer(self):
        self.make_user("carol")
        self.assertTrue(db.verify_security_answer(self.conn, "carol", "  ANSWER "))
        self.assertFalse(db.verify_security_answer(self.conn, "carol", "other"))
        self.assertFalse(db.verify_security_answer(self.conn, "ghost", "answer"))
        db.reset_password(self.conn, "carol", "NewPass1!")
        self.assertTrue(db.verify_user(self.conn, "carol", "NewPass1!"))
        self.assertFalse(db.verify_user(self.conn, "carol", "Passw0rd!"))


class TestLockout(DBTestCase):
    def test_lock_persists_across_connections(self):
        for i in range(4):
            left, locked = db.register_failure(self.conn, "login", "dave")
            self.assertEqual((left, locked), (4 - i, 0))
        left, locked = db.register_failure(self.conn, "login", "dave")
        self.assertGreater(locked, 0)
        # a brand-new connection (page refresh / new session) is still locked
        conn2 = db.init_db()
        self.assertGreater(db.lock_seconds_remaining(conn2, "login", "dave"), 0)
        self.assertGreater(db.lock_seconds_remaining(conn2, "login", "DAVE "), 0)  # case/space-insensitive
        conn2.close()

    def test_lock_scoped_and_clearable(self):
        for _ in range(5):
            db.register_failure(self.conn, "login", "erin")
        self.assertEqual(db.lock_seconds_remaining(self.conn, "reset", "erin"), 0)
        db.clear_failures(self.conn, "login", "erin")
        self.assertEqual(db.lock_seconds_remaining(self.conn, "login", "erin"), 0)

    def test_lock_expires(self):
        for _ in range(5):
            db.register_failure(self.conn, "login", "fay")
        past = (datetime.now() - timedelta(seconds=1)).strftime("%Y-%m-%d %H:%M:%S")
        self.conn.execute("update login_attempts set locked_until=?", (past,)); self.conn.commit()
        self.assertEqual(db.lock_seconds_remaining(self.conn, "login", "fay"), 0)


class TestLegacyMigration(unittest.TestCase):
    """An OLD database (unsalted hashes, old columns, existing data) must
    upgrade without losing anything."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "old.db")
        c = sqlite3.connect(self.path)
        c.executescript("""
            CREATE TABLE users (username TEXT PRIMARY KEY, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
            CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, timestamp TEXT NOT NULL,
                age_group TEXT, city_name TEXT, avg_order_value REAL, predicted_category TEXT, confidence REAL);
            CREATE TABLE wishlist (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, timestamp TEXT NOT NULL,
                item_name TEXT NOT NULL, predicted_category TEXT);
            CREATE TABLE feedback (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, timestamp TEXT NOT NULL,
                rating INTEGER NOT NULL, comment TEXT);
        """)
        c.execute("insert into users values ('olduser', ?, '2024-01-01 00:00:00')",
                  (hashlib.sha256(b"oldpass").hexdigest(),))
        c.execute("insert into history (username,timestamp,predicted_category) values ('olduser','2024-01-02 00:00:00','Books')")
        c.execute("insert into wishlist (username,timestamp,item_name,predicted_category) values ('olduser','2024-01-03 00:00:00','Old Book','Books')")
        c.execute("insert into feedback (username,timestamp,rating,comment) values ('olduser','2024-01-04 00:00:00',5,'nice')")
        c.commit(); c.close()
        self._old = db.DB_PATH; db.DB_PATH = self.path

    def tearDown(self):
        db.DB_PATH = self._old; self.tmp.cleanup()

    def test_upgrade_keeps_data_and_logins(self):
        for _ in range(2):  # re-runnable
            conn = db.init_db()
        counts = {t: conn.execute(f"select count(*) from {t}").fetchone()[0]
                  for t in ("users", "history", "wishlist", "feedback")}
        self.assertEqual(counts, {"users": 1, "history": 1, "wishlist": 1, "feedback": 1})
        tables = {r[0] for r in conn.execute("select name from sqlite_master where type='table'")}
        for t in ("price_history", "price_alerts", "availability_alerts", "review_summaries",
                  "wishlist_notes", "product_comparisons", "notifications"):
            self.assertIn(t, tables)
        # legacy hash still logs in, then is upgraded in place
        self.assertTrue(db.verify_user(conn, "olduser", "oldpass"))
        stored = conn.execute("select password_hash from users").fetchone()[0]
        self.assertTrue(stored.startswith("pbkdf2_sha256$"))
        self.assertTrue(db.verify_user(conn, "olduser", "oldpass"))
        self.assertFalse(db.verify_user(conn, "olduser", "bad"))
        # old wishlist row readable through both old and new APIs
        self.assertEqual(db.get_wishlist(conn, "olduser").iloc[0]["Item"], "Old Book")
        self.assertEqual(dbf.get_wishlist_advanced(conn, "olduser").iloc[0]["Item"], "Old Book")
        self.assertEqual(db.get_search_history(conn, "olduser").shape[0], 1)
        conn.close()


class TestUserIsolation(DBTestCase):
    def setUp(self):
        super().setUp()
        self.make_user("user1"); self.make_user("user2")
        self.w1 = db.add_to_wishlist(self.conn, "user1", "Item One", "Books", price="₹100", price_value=100.0,
                                     product_key="item one", source="S", rating=4.0)
        self.w2 = db.add_to_wishlist(self.conn, "user2", "Item Two", "Books")

    def test_cannot_delete_other_users_wishlist_item(self):
        self.assertFalse(db.remove_from_wishlist(self.conn, self.w1, "user2"))
        self.assertEqual(db.get_wishlist_count(self.conn, "user1"), 1)
        self.assertTrue(db.remove_from_wishlist(self.conn, self.w1, "user1"))

    def test_cannot_set_alerts_or_notes_on_other_users_item(self):
        self.assertFalse(dbf.set_price_alert(self.conn, "user2", self.w1, 50, True))
        self.assertFalse(dbf.set_availability_alert(self.conn, "user2", self.w1, True, "out_of_stock"))
        self.assertFalse(dbf.save_wishlist_note(self.conn, self.w1, "user2", "x", "y"))
        self.assertEqual(self.conn.execute("select count(*) from price_alerts").fetchone()[0], 0)

    def test_views_are_per_user(self):
        dbf.add_notification(self.conn, "user1", "price_drop", "m1")
        dbf.save_comparison(self.conn, "user1", "cmp", [{"title": "x"}])
        self.assertEqual(dbf.get_notifications(self.conn, "user2"), [])
        self.assertEqual(dbf.get_saved_comparisons(self.conn, "user2"), [])
        cid = dbf.get_saved_comparisons(self.conn, "user1")[0][0]
        dbf.delete_comparison(self.conn, "user2", cid)  # wrong user: no effect
        self.assertEqual(len(dbf.get_saved_comparisons(self.conn, "user1")), 1)
        self.assertEqual(list(dbf.get_wishlist_advanced(self.conn, "user2")["Item"]), ["Item Two"])
        self.assertTrue(db.get_search_history(self.conn, "user2").empty)

    def test_cascade_on_remove(self):
        dbf.set_price_alert(self.conn, "user1", self.w1, 50, True)
        dbf.save_wishlist_note(self.conn, self.w1, "user1", "c", "n")
        db.remove_from_wishlist(self.conn, self.w1, "user1")
        for t in ("price_alerts", "wishlist_notes"):
            self.assertEqual(self.conn.execute(f"select count(*) from {t}").fetchone()[0], 0)


class TestEmptyAndNull(DBTestCase):
    def test_empty_database_pages_dont_crash(self):
        self.make_user("zed")
        self.assertTrue(db.get_wishlist(self.conn, "zed").empty)
        self.assertTrue(dbf.get_wishlist_advanced(self.conn, "zed").empty)
        self.assertTrue(db.get_search_history(self.conn, "zed").empty)
        self.assertTrue(dbf.get_recent_searches(self.conn, "zed").empty)
        self.assertEqual(dbf.get_user_dashboard_stats(self.conn, "zed")["total_searches"], 0)
        self.assertIsNone(dbf.get_user_dashboard_stats(self.conn, "zed")["avg_price_searched"])
        self.assertEqual(dbf.get_tracked_products(self.conn, "zed"), [])
        self.assertTrue(db.get_all_feedback(self.conn).empty)
        db.get_platform_stats(self.conn); db.get_category_distribution(self.conn)

    def test_profile_defaults(self):
        self.make_user("pia")
        p = db.get_profile(self.conn, "pia")
        self.assertIsInstance(p, dict)

    def test_feedback_validation(self):
        self.make_user("fbk")
        db.save_feedback(self.conn, "fbk", 99, "x" * 5000)
        db.save_feedback(self.conn, "fbk", "bad", "ok")
        df = db.get_user_feedback(self.conn, "fbk")
        self.assertEqual(sorted(df["Rating"]), [1, 5])
        self.assertTrue(all(len(c) <= 2000 for c in df["Comment"]))

    def test_feedback_roundtrip(self):
        self.make_user("fbk")
        db.save_feedback(self.conn, "fbk", 5, "great")
        self.assertEqual(db.get_user_feedback(self.conn, "fbk").shape[0], 1)
        self.assertEqual(db.get_all_feedback(self.conn).shape[0], 1)


if __name__ == "__main__":
    unittest.main()
