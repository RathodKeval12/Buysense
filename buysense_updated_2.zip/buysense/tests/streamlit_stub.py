import sys,types
class SS(dict):
    __getattr__=dict.get
    def __setattr__(s,k,v): s[k]=v
st=types.ModuleType('streamlit'); st.session_state=SS(lang='en',theme='dark')
st.cache_data=lambda **k:(lambda f:f)
class _Ctx:
    def __enter__(s): return s
    def __exit__(s,*a): return False
    def __getattr__(s,n): return lambda *a,**k:_Ctx()
    def __iter__(s): return iter([_Ctx(),_Ctx(),_Ctx()])
def _cols(n,*a,**k):
    n=n if isinstance(n,int) else len(n); return [_Ctx() for _ in range(n)]
def _any(*a,**k): return _Ctx()
st.columns=_cols; st.tabs=lambda l:[_Ctx() for _ in l]
for n in 'markdown caption info warning error success toast write dataframe image metric line_chart map plotly_chart title subheader spinner expander form chat_message'.split(): setattr(st,n,_any)
for n in 'button form_submit_button checkbox'.split(): setattr(st,n,lambda *a,**k:False)
st.text_input=lambda *a,**k:k.get('value','')
st.text_area=lambda *a,**k:k.get('value','')
st.number_input=lambda *a,**k:k.get('value',0.0)
def _selectbox(label, options=None, *a, **k):
    options = list(options if options is not None else k.get("options", []))
    idx = k.get("index", 0) or 0
    return options[idx] if options else None
st.selectbox=_selectbox
st.multiselect=lambda *a,**k:[]
st.radio=lambda l,o,*a,**k:o[0]
st.slider=lambda *a,**k:a[3] if len(a)>3 else 0
st.column_config=types.SimpleNamespace(NumberColumn=_any,LinkColumn=_any)
st.rerun=lambda:None
st._IS_STUB=True
class StopApp(Exception): pass
def _stop(): raise StopApp()
st.stop=_stop
def _cache_resource(*a,**k):
    if a and callable(a[0]): return a[0]
    return lambda f:f
st.cache_resource=_cache_resource
st.sidebar=_Ctx()
st.secrets={}
st.progress=_any; st.set_page_config=_any; st.download_button=lambda *a,**k:False
st.file_uploader=lambda *a,**k:None
st.audio_input=lambda *a,**k:None
st.chat_input=lambda *a,**k:None
st.container=_any; st.empty=_any; st.divider=_any; st.code=_any; st.json=_any
st.html=_any; st.link_button=lambda *a,**k:False; st.pyplot=_any
st.date_input=lambda *a,**k:None
def _mod_getattr(name):
    return _any
st.__getattr__=_mod_getattr
sys.modules['streamlit']=st
om=types.ModuleType('streamlit_option_menu'); om.option_menu=lambda **k:k['options'][k.get('default_index',0) or 0]
sys.modules['streamlit_option_menu']=om

g=types.ModuleType('groq'); g.Groq=object; sys.modules['groq']=g
