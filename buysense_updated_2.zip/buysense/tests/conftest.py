"""Shared test setup: fake streamlit/groq (not needed to test logic) and
an isolated temporary SQLite database per test."""
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for p in (HERE, ROOT):
    if p not in sys.path:
        sys.path.insert(0, p)

try:  # use the real packages when installed
    import streamlit  # noqa: F401
except Exception:
    import streamlit_stub  # noqa: F401  (installs a minimal fake)
try:
    import groq  # noqa: F401
except Exception:
    import types
    g = types.ModuleType("groq"); g.Groq = object; sys.modules["groq"] = g


class DBTestCase(unittest.TestCase):
    """Each test gets a brand-new empty database file."""
    def setUp(self):
        import db
        self.tmp = tempfile.TemporaryDirectory()
        self._old_path = db.DB_PATH
        db.DB_PATH = os.path.join(self.tmp.name, "test.db")
        self.db = db
        self.conn = db.init_db()

    def tearDown(self):
        self.conn.close()
        self.db.DB_PATH = self._old_path
        self.tmp.cleanup()

    def make_user(self, name, pw="Passw0rd!", email="a@b.co"):
        assert self.db.create_user(self.conn, name, pw, email, "q", "answer")
