import unittest
from unittest import mock

import pandas as pd

from conftest import DBTestCase
import ai_helpers
import assistant
import db
import db_features as dbf
import exports
import gift
import model as ml
import multimodal
import nlsearch
import notify
import page_budget
import page_compare
import pricing
import product_details
import reviews
import shopping
import stores


def prod(title, price, src="ShopA", **kw):
    p = {"title": title, "price": f"₹{price}" if price is not None else "Price unavailable",
         "price_value": price, "source": src, "key": shopping.product_key(title), "rating": 4.4,
         "link": "https://x", "availability": None, "image": ""}
    p.update(kw)
    return p


class TestPriceHistory(DBTestCase):
    def test_no_fabricated_history(self):
        k = shopping.product_key("Phone X")
        stats = pricing.compute_price_stats(pricing.build_series(dbf.get_price_points(self.conn, k)))
        self.assertFalse(stats["sufficient"]); self.assertIsNone(stats["current"])
        dbf.record_price(self.conn, k, "Phone X", "A", 100)
        stats = pricing.compute_price_stats(pricing.build_series(dbf.get_price_points(self.conn, k)))
        self.assertFalse(stats["sufficient"]); self.assertEqual(stats["points"], 1)

    def test_stats_and_dedup(self):
        k = "k"
        self.assertTrue(dbf.record_price(self.conn, k, "t", "A", 200))
        self.assertFalse(dbf.record_price(self.conn, k, "t", "A", 200))
        self.conn.execute("update price_history set recorded_at='2026-01-01 00:00:00'"); self.conn.commit()
        dbf.record_price(self.conn, k, "t", "A", 150)
        s = pricing.compute_price_stats(pricing.build_series(dbf.get_price_points(self.conn, k)))
        self.assertEqual((s["current"], s["previous"], s["lowest"], s["highest"]), (150, 200, 150, 200))
        self.assertAlmostEqual(s["change_pct"], -25.0)

    def test_invalid_prices_not_recorded(self):
        for bad in (None, "abc", float("nan"), float("inf"), 0, -3):
            dbf.record_price(self.conn, "k", "t", "A", bad)
        self.assertEqual(self.conn.execute("select count(*) from price_history").fetchone()[0], 0)

    def test_record_prices_for_products_skips_unpriced(self):
        n = dbf.record_prices_for_products(self.conn, [prod("A", 10), prod("B", None)], "u")
        self.assertEqual(n, 1)


class TestAlerts(DBTestCase):
    def setUp(self):
        super().setUp()
        self.make_user("user1")
        self.title = "Samsung Galaxy M35 5G 8GB 128GB"
        self.wid = db.add_to_wishlist(self.conn, "user1", self.title, "Electronics", price="₹20,000",
                                      price_value=20000.0, product_key=shopping.product_key(self.title),
                                      source="ShopA", rating=4.4)

    def run_eval(self, price, src="ShopA", **kw):
        return pricing.evaluate_alerts(self.conn, "user1", [prod(self.title, price, src, **kw)])

    def test_price_alert_fires_only_when_target_met_and_not_repeated(self):
        dbf.set_price_alert(self.conn, "user1", self.wid, 18000, True)
        self.assertEqual(self.run_eval(19000), [])
        self.assertEqual(len(self.run_eval(17900)), 1)
        self.assertEqual(self.run_eval(17900), [])            # same event: no duplicate
        self.assertEqual(self.run_eval(17950), [])            # tiny rise, still same event
        self.assertEqual(len(self.run_eval(17000)), 1)        # further drop alerts again
        self.assertEqual(self.run_eval(19500), [])            # back above target ...
        self.assertEqual(len(self.run_eval(17900)), 1)        # ... re-armed
        self.assertEqual(dbf.count_unread_notifications(self.conn, "user1"), 3)

    def test_disabled_alert_never_fires(self):
        dbf.set_price_alert(self.conn, "user1", self.wid, 18000, False)
        self.assertEqual(self.run_eval(1000), [])

    def test_invalid_targets_rejected(self):
        for bad in (0, -5, "abc", None, float("nan"), float("inf")):
            self.assertFalse(dbf.set_price_alert(self.conn, "user1", self.wid, bad, True), repr(bad))
        self.assertEqual(self.conn.execute("select count(*) from price_alerts").fetchone()[0], 0)

    def test_unpriced_or_unmatched_products_ignored(self):
        dbf.set_price_alert(self.conn, "user1", self.wid, 18000, True)
        self.assertEqual(self.run_eval(None), [])
        self.assertEqual(pricing.evaluate_alerts(self.conn, "user1", [prod("Totally different laptop", 1)]), [])
        self.assertEqual(pricing.evaluate_alerts(self.conn, "user1", []), [])
        self.assertEqual(pricing.evaluate_alerts(self.conn, "", [prod(self.title, 1)]), [])

    def test_changing_target_rearms(self):
        dbf.set_price_alert(self.conn, "user1", self.wid, 18000, True)
        self.assertEqual(len(self.run_eval(17000)), 1)
        dbf.set_price_alert(self.conn, "user1", self.wid, 16000, True)
        self.assertEqual(self.run_eval(17000), [])
        self.assertEqual(len(self.run_eval(15000)), 1)

    def test_availability_alert_needs_known_transition(self):
        dbf.set_wishlist_availability(self.conn, self.wid, "out_of_stock")
        dbf.set_availability_alert(self.conn, "user1", self.wid, True, "out_of_stock")
        self.assertEqual(self.run_eval(20000), [])                              # unknown: no alert, no guess
        self.assertEqual(self.run_eval(20000, availability="out_of_stock"), [])
        ev = self.run_eval(20000, availability="in_stock")
        self.assertEqual([e["kind"] for e in ev], ["back_in_stock"])
        self.assertEqual(self.run_eval(20000, availability="in_stock"), [])     # not repeated

    def test_email_only_when_enabled_and_failures_tolerated(self):
        dbf.set_price_alert(self.conn, "user1", self.wid, 18000, True)
        with mock.patch.object(notify, "send_alert_email") as send:
            self.run_eval(17000); send.assert_not_called()
        db.set_email_notify_pref(self.conn, "user1", True)
        dbf.set_price_alert(self.conn, "user1", self.wid, 16000, True)
        with mock.patch.object(notify, "send_alert_email", return_value=(False, "boom")) as send:
            ev = self.run_eval(15000)
            send.assert_called_once()
        self.assertEqual(len(ev), 1)  # in-app notification still delivered

    def test_alert_email_without_smtp(self):
        with mock.patch.object(notify, "get_smtp_config", return_value=None):
            self.assertEqual(notify.send_alert_email("a@b.co", "u", "s", ["x"]), (False, "smtp_not_configured"))
        with mock.patch.object(notify, "get_smtp_config", return_value={"host": "h", "port": 1, "user": "u", "password": "p", "sender": "s"}):
            self.assertEqual(notify.send_alert_email("nope", "u", "s", ["x"]), (False, "invalid_email"))

    def test_check_wishlist_now_handles_missing_key_and_errors(self):
        with mock.patch.object(shopping, "get_serpapi_key", return_value=""):
            self.assertEqual(pricing.check_wishlist_now(self.conn, "user1"), ([], 0, "no_api_key"))
        dbf.set_price_alert(self.conn, "user1", self.wid, 18000, True)
        with mock.patch.object(shopping, "get_serpapi_key", return_value="k"), \
             mock.patch.object(shopping, "search_products", return_value=([], "network")):
            ev, checked, err = pricing.check_wishlist_now(self.conn, "user1")
        self.assertEqual((ev, checked, err), ([], 1, "network"))


class TestExports(unittest.TestCase):
    def test_pdf_text_is_latin1_safe(self):
        out = exports.pdf_safe_text("gaming laptop under ₹50000 — नमस्ते ગુજરાતી “q”")
        out.encode("latin-1")  # must not raise
        self.assertIn("Rs.50000", out)

    def test_csv_formula_injection_neutralised(self):
        df = pd.DataFrame({"Search Query": ["=HYPERLINK(\"http://evil\")", "+1+1", "@SUM(A1)", "-2", "normal"], "n": [1, 2, 3, 4, 5]})
        text = exports.csv_bytes(df).decode("utf-8-sig")
        for line in text.splitlines()[1:5]:
            self.assertTrue(line.startswith("'") or line.startswith('"\''), line)
        self.assertIn("normal", text)

    def test_csv_keeps_unicode(self):
        df = pd.DataFrame({"q": ["फोन ₹5000"]})
        self.assertIn("फोन ₹5000", exports.csv_bytes(df).decode("utf-8-sig"))


class TestNLSearch(unittest.TestCase):
    def test_examples(self):
        r = nlsearch.rule_parse("I want a Samsung phone under ₹25,000 with at least 4.3 rating")
        self.assertEqual((r["brand"], r["budget_max"], r["min_rating"], r["product"]), ("Samsung", 25000.0, 4.3, "Samsung phone"))
        r = nlsearch.rule_parse("Show me wireless headphones under 3000 rupees")
        self.assertEqual((r["budget_max"], r["product"]), (3000.0, "wireless headphones"))
        r = nlsearch.rule_parse("running shoes between 2000 and 4,000 with 4+ stars")
        self.assertEqual((r["budget_min"], r["budget_max"], r["min_rating"]), (2000.0, 4000.0, 4.0))
        self.assertEqual(nlsearch.rule_parse("tv under 1.5 lakh")["budget_max"], 150000.0)

    def test_garbage_and_empty(self):
        for text in ("", "   ", "!!!", "a" * 5000, None):
            r = nlsearch.rule_parse(text)
            self.assertIn("product", r)
        self.assertIsNone(nlsearch.rule_parse("phone rated 9 stars")["min_rating"])

    def test_without_groq_falls_back_to_rules(self):
        with mock.patch.object(ai_helpers, "has_groq", return_value=False):
            params, err = nlsearch.parse_query("phone under 20k")
        self.assertEqual(err, "no_api_key"); self.assertEqual(params["budget_max"], 20000.0)

    def test_ai_numbers_never_override_rules(self):
        ai = {"product": "phone", "brand": "", "budget_min": None, "budget_max": 999.0, "min_rating": None,
              "interests": "", "constraints": [], "source": "ai"}
        with mock.patch.object(ai_helpers, "has_groq", return_value=True), \
             mock.patch.object(nlsearch, "ai_parse", return_value=(ai, None)):
            params, _ = nlsearch.parse_query("phone under 20k")
        self.assertEqual(params["budget_max"], 20000.0)

    def test_ai_junk_values_sanitised(self):
        self.assertIsNone(nlsearch._num_or_none("abc")); self.assertIsNone(nlsearch._num_or_none(-4))
        self.assertIsNone(nlsearch._num_or_none(7, 0, 5))

    def test_profile_merge_keeps_unstated_fields(self):
        p = nlsearch.params_to_profile({"product": "phone", "budget_max": 100.0}, {"interests": "Gaming", "min_rating": 3})
        self.assertEqual((p["product_query"], p["budget_max"], p["interests"], p["min_rating"]), ("phone", 100.0, "Gaming", 3))


class TestRankingAndBudget(unittest.TestCase):
    def test_build_query_handles_bad_budget(self):
        self.assertEqual(ml.build_search_query({"product_query": "tv", "budget_max": "abc"}), "tv")
        self.assertEqual(ml.build_search_query({"product_query": "tv", "budget_max": 5000}), "tv under ₹5000")
        self.assertEqual(ml.build_search_query({}), "trending products")

    def test_rank_handles_missing_values(self):
        items = [prod("A", None, rating=None), prod("B", 100), prod("C", 9000)]
        ranked = ml.rank_products(items, {"budget_max": 1000, "min_rating": 4})
        self.assertEqual(len(ranked), 3)
        self.assertEqual(ranked[0]["title"], "B")  # in budget beats over budget

    def test_budget_groups_are_disjoint_and_correct(self):
        items = [prod("cheap", 500), prod("mid", 900), prod("top", 1000), prod("above", 1100),
                 prod("far", 5000), prod("nopr", None)]
        groups, skipped = page_budget.group_products(items, 1000, 0.15)
        names = {k: [p["title"] for p in v] for k, v in groups.items()}
        self.assertEqual(names, {"alt": ["cheap"], "within": ["mid", "top"], "above": ["above"]})
        self.assertEqual(skipped, 1)


class TestCompare(unittest.TestCase):
    def test_table_reports_objective_differences_without_best_label(self):
        a, b = prod("Phone A", 20000, rating=4.5), prod("Phone B", 25000, rating=4.0, source="ShopB")
        table, lo, hi = page_compare.build_comparison_table([a, b])
        self.assertEqual((lo, hi), (20000, 4.5))
        flat = " ".join(str(v) for v in table.values.flatten()).lower()
        self.assertNotIn("best", flat)
        self.assertIn("+₹5,000", flat)

    def test_missing_data_renders_dashes(self):
        table, lo, hi = page_compare.build_comparison_table([prod("A", None, rating=None), prod("B", None, rating=None)])
        self.assertIsNone(lo); self.assertIsNone(hi)

    def test_offer_math(self):
        self.assertEqual(product_details.compute_offer({"price_value": 80, "old_price_value": 100})["discount_pct"], 20)
        self.assertIsNone(product_details.compute_offer({"price_value": 120, "old_price_value": 100})["discount_pct"])
        self.assertIsNone(product_details.compute_offer({})["discount_pct"])


class TestReviews(DBTestCase):
    REVS = [{"text": "Battery lasts two days"}, {"text": "Screen cracked quickly"}]

    def test_unavailable_and_too_few(self):
        self.assertEqual(reviews.summarize_reviews(self.conn, "k", "t", [], "en"), (None, "no_reviews"))
        self.assertEqual(reviews.summarize_reviews(self.conn, "k", "t", [{"text": "x"}], "en"), (None, "too_few_reviews"))

    def test_summary_cached_and_only_real_reviews_sent(self):
        out = '{"positive": ["Long battery"], "negative": ["Fragile screen"], "overall": "Mixed."}'
        with mock.patch.object(ai_helpers, "chat", return_value=(out, None, "m")) as chat:
            s1, st1 = reviews.summarize_reviews(self.conn, "k", "Phone", self.REVS, "en")
            s2, st2 = reviews.summarize_reviews(self.conn, "k", "Phone", self.REVS, "en")
        self.assertEqual((st1, st2), ("ok", "cached")); self.assertEqual(s1, s2)
        self.assertEqual(chat.call_count, 1)
        prompt = chat.call_args.args[0][1]["content"]
        self.assertIn("Battery lasts two days", prompt)

    def test_api_failure_and_bad_json(self):
        with mock.patch.object(ai_helpers, "chat", return_value=(None, "rate_limited", None)):
            self.assertEqual(reviews.summarize_reviews(self.conn, "k", "t", self.REVS, "en"), (None, "rate_limited"))
        with mock.patch.object(ai_helpers, "chat", return_value=("not json", None, "m")):
            self.assertEqual(reviews.summarize_reviews(self.conn, "k", "t", self.REVS, "en"), (None, "api_error"))

    def test_no_key(self):
        with mock.patch.object(ai_helpers, "get_groq_key", return_value=""):
            self.assertEqual(ai_helpers.chat([{"role": "user", "content": "x"}])[1], "no_api_key")


class TestAIHelpers(unittest.TestCase):
    def test_parse_json(self):
        self.assertEqual(ai_helpers.parse_json('```json\n{"a": 1}\n```'), {"a": 1})
        self.assertEqual(ai_helpers.parse_json('Sure! {"a": 2} done'), {"a": 2})
        for bad in (None, "", "no json", "[1,2]"):
            self.assertIsNone(ai_helpers.parse_json(bad))

    def test_friendly_errors_hide_details(self):
        self.assertEqual(ai_helpers.friendly_error("Error code: 429 rate limit"), "rate_limited")
        self.assertEqual(ai_helpers.friendly_error("401 invalid api key gsk_abc"), "bad_key")
        self.assertEqual(ai_helpers.error_key("weird"), "err_generic_ai")


class TestMultimodalAndStores(unittest.TestCase):
    def test_image_validation_before_any_api_call(self):
        with mock.patch.object(ai_helpers, "get_groq_key", return_value=""):
            self.assertEqual(multimodal.analyze_product_image(b"x", "image/png"), (None, "no_api_key"))
        with mock.patch.object(ai_helpers, "get_groq_key", return_value="k"):
            self.assertEqual(multimodal.analyze_product_image(b"x", "application/pdf"), (None, "unsupported_image"))
            big = b"0" * (multimodal.MAX_IMAGE_BYTES + 1)
            self.assertEqual(multimodal.analyze_product_image(big, "image/png"), (None, "image_too_large"))

    def test_voice_validation(self):
        with mock.patch.object(ai_helpers, "get_groq_key", return_value="k"):
            self.assertEqual(multimodal.transcribe_audio(b""), (None, "empty_audio"))
        with mock.patch.object(ai_helpers, "get_groq_key", return_value=""):
            self.assertEqual(multimodal.transcribe_audio(b"x"), (None, "no_api_key"))

    def test_stores_paths(self):
        self.assertEqual(stores.find_stores("Electronics", "  ")[2], "no_location")
        with mock.patch.object(stores, "_geocode", return_value=None):
            self.assertEqual(stores.find_stores("Electronics", "nowhere")[2], "location_not_found")
        with mock.patch.object(stores, "_geocode", side_effect=OSError):
            self.assertEqual(stores.find_stores("Electronics", "x")[2], "network")
        els = [{"type": "node", "id": 1, "lat": 22.30, "lon": 70.80, "tags": {"name": "Shop", "shop": "electronics"}},
               {"type": "node", "id": 2, "lat": 22.31, "lon": 70.81, "tags": {}}]
        with mock.patch.object(stores, "_overpass", return_value=els):
            found, center, err = stores.find_stores("Electronics", lat=22.3, lon=70.8)
        self.assertEqual((len(found), err), (1, None)); self.assertEqual(round(center[0], 3), 22.3)
        with mock.patch.object(stores, "_overpass", return_value=[]):
            self.assertEqual(stores.find_stores("Electronics", lat=22.3, lon=70.8)[2], "no_stores")

    def test_gift_query_fallback(self):
        with mock.patch.object(ai_helpers, "has_groq", return_value=False):
            q, src = gift.build_gift_query("Birthday", "Friend", "music, cooking", "Electronics", 2000)
        self.assertEqual(src, "template"); self.assertIn("under ₹2000", q); self.assertIn("music", q)


class TestAssistant(DBTestCase):
    def test_intents(self):
        self.assertEqual(assistant.detect_intent("I need a gaming laptop under ₹60,000 with good ratings."), "search")
        self.assertEqual(assistant.detect_intent("Find a phone for photography under ₹30,000."), "search")
        self.assertEqual(assistant.detect_intent("Compare these products"), "compare")
        self.assertEqual(assistant.detect_intent("Why is this product suitable for my budget?"), "suitable")
        self.assertEqual(assistant.detect_intent("what is RAM"), "general")

    def test_search_uses_only_real_results_and_degrades_without_key(self):
        self.make_user("abc")
        with mock.patch.object(shopping, "get_serpapi_key", return_value=""):
            turn = assistant.prepare_turn(self.conn, "abc", "find a phone under 30000", [], "en")
        self.assertEqual(turn["products"], []); self.assertIn("Do not name", turn["context"])
        real = [prod("Real Phone", 21000)]
        with mock.patch.object(shopping, "get_serpapi_key", return_value="k"), \
             mock.patch.object(shopping, "search_products", return_value=(real, None)):
            turn = assistant.prepare_turn(self.conn, "abc", "find a phone under 30000", [], "en")
        self.assertIn("Real Phone", turn["context"]); self.assertEqual(turn["products"][0]["title"], "Real Phone")

    def test_compare_without_products_forbids_inventing(self):
        self.make_user("abc")
        turn = assistant.prepare_turn(self.conn, "abc", "compare these products", [], "en")
        self.assertIn("Do not invent", turn["context"])

    def test_messages_drop_extra_keys_and_system_roles(self):
        msgs = assistant.build_messages([{"role": "user", "content": "hi", "products": [1]}], {}, "CTX", "hi")
        self.assertTrue(all(set(m) == {"role", "content"} for m in msgs))
        self.assertIn("NEVER invent", msgs[0]["content"])


class TestI18N(unittest.TestCase):
    def test_every_used_key_exists_in_all_languages(self):
        import glob, os, re
        import i18n
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        used = set()
        for f in glob.glob(os.path.join(root, "*.py")):
            if os.path.basename(f) in ("i18n.py", "i18n_extra.py"):
                continue
            with open(f, encoding="utf-8") as fh:
                src = fh.read()
            used |= set(re.findall(r"\bt\(\s*[\"']([a-z0-9_]+)[\"']", src))
            used |= set(re.findall(r"[\"']((?:err|nav|nl|chat)_[a-z_]+)[\"']", src))
        used -= {"chat_history", "nl_form"}  # session/widget keys, not translations
        missing = sorted(k for k in used if k not in i18n.TRANSLATIONS)
        self.assertEqual(missing, [])
        for k, v in i18n.TRANSLATIONS.items():
            for lang in ("en", "hi", "gu"):
                self.assertTrue(v.get(lang), f"{k}/{lang}")

    def test_placeholders_match_across_languages(self):
        import string, i18n
        ph = lambda s: {x[1] for x in string.Formatter().parse(s) if x[1]}
        for k, v in i18n.TRANSLATIONS.items():
            self.assertEqual(ph(v["en"]), ph(v["hi"]), k); self.assertEqual(ph(v["en"]), ph(v["gu"]), k)


if __name__ == "__main__":
    unittest.main()


class TestTemplatesEscape(unittest.TestCase):
    def test_user_text_is_escaped_before_html_templates(self):
        import templates as tpl
        self.assertEqual(tpl.esc('<img src=x onerror=alert(1)>'), '&lt;img src=x onerror=alert(1)&gt;')
        self.assertEqual(tpl.esc(None), "")
