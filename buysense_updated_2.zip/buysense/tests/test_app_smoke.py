"""Executes app.py end-to-end for every page against a stand-in Streamlit
(only used when the real streamlit isn't installed). Catches NameErrors,
bad imports and wiring mistakes between app.py and the page modules."""
import os
import runpy
import sys
import tempfile
import unittest

import conftest  # noqa: F401

REAL_STREAMLIT = not getattr(sys.modules.get("streamlit"), "_IS_STUB", False)
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

PAGES = ["Home", "Recommendation", "Smart Search", "Gift Ideas", "Compare", "Budget Optimizer",
         "Price Tracker", "Nearby Stores", "Dashboard", "My History", "Wishlist", "Feedback",
         "Chatbot", "Profile", "About"]


@unittest.skipIf(REAL_STREAMLIT, "stand-in streamlit only")
class TestAppRuns(unittest.TestCase):
    def setUp(self):
        import db
        import streamlit as st
        import i18n
        self.tmp = tempfile.TemporaryDirectory()
        self.old = db.DB_PATH
        db.DB_PATH = os.path.join(self.tmp.name, "smoke.db")
        self.cwd = os.getcwd(); os.chdir(ROOT)
        conn = db.init_db()
        db.create_user(conn, "smoker", "Passw0rd!", "s@e.co", "q", "a")
        db.add_to_wishlist(conn, "smoker", "Test Phone 128GB", "Electronics", price="₹999", price_value=999.0,
                           product_key="128gb phone test", source="S", rating=4.0)
        db.save_search(conn, "smoker", "phone under ₹5000", "5000", "Electronics", 3, 1500.0)
        conn.close()
        self.st, self.db, self.i18n = st, db, i18n

    def tearDown(self):
        os.chdir(self.cwd); self.db.DB_PATH = self.old; self.tmp.cleanup()

    def run_page(self, page, lang="en", theme="dark", logged_in=True):
        st = self.st
        st.session_state.clear()
        st.session_state.update(lang=lang, theme=theme, logged_in=logged_in,
                                username="smoker" if logged_in else "")
        sys.modules["streamlit_option_menu"].option_menu = (
            lambda **k: next(l for l in k["options"] if self.label_for(page, lang) == l))
        import streamlit_stub
        try:
            runpy.run_path(os.path.join(ROOT, "app.py"), run_name="__main__")
        except streamlit_stub.StopApp:
            pass  # st.stop() after rendering the login page is expected

    def label_for(self, page, lang):
        keys = {"Home": "nav_home", "Recommendation": "nav_recommendation", "Smart Search": "nav_smart_search",
                "Gift Ideas": "nav_gift", "Compare": "nav_compare", "Budget Optimizer": "nav_budget",
                "Price Tracker": "nav_tracker", "Nearby Stores": "nav_stores", "Dashboard": "nav_dashboard",
                "My History": "nav_history", "Wishlist": "nav_wishlist", "Feedback": "nav_feedback",
                "Chatbot": "nav_chatbot", "Profile": "nav_profile", "About": "nav_about"}
        return self.i18n.t(keys[page], lang=lang)

    def test_login_page_all_languages_and_themes(self):
        for lang in ("en", "hi", "gu"):
            for theme in ("dark", "light"):
                self.run_page("Home", lang, theme, logged_in=False)

    def test_every_page_every_language_and_theme(self):
        for page in PAGES:
            for lang, theme in (("en", "dark"), ("hi", "light"), ("gu", "dark")):
                with self.subTest(page=page, lang=lang, theme=theme):
                    self.run_page(page, lang, theme)


if __name__ == "__main__":
    unittest.main()
