import unittest
from unittest import mock

import conftest  # noqa: F401
import currency
import shopping


class TestParsing(unittest.TestCase):
    def test_amounts(self):
        cases = {"₹1,29,999.00": 129999.0, "$12.99 - $20": 12.99, "1.299,50 €": 1299.5,
                 "From ₹499": 499.0, "Rs. 2,499": 2499.0, "£1,299.50": 1299.5}
        for text, want in cases.items():
            self.assertEqual(currency.parse_amount(text), want, text)

    def test_bad_values(self):
        for bad in ("", None, "abc", "₹0", "-₹50", 0, -5):
            self.assertIsNone(currency.parse_amount(bad), repr(bad))

    def test_currency_detection(self):
        self.assertEqual(currency.detect_currency("₹1,299"), "INR")
        self.assertEqual(currency.detect_currency("Rs.499"), "INR")
        self.assertEqual(currency.detect_currency("$9.99"), "USD")
        self.assertEqual(currency.detect_currency("€5"), "EUR")
        self.assertIsNone(currency.detect_currency("1299"))
        self.assertIsNone(currency.detect_currency(None))


class TestConversion(unittest.TestCase):
    def setUp(self):
        currency._RATE_CACHE.clear()

    def test_inr_needs_no_rate(self):
        with mock.patch("currency.requests.get") as g:
            self.assertEqual(currency.to_inr(100, "INR"), 100.0)
            g.assert_not_called()

    def test_usd_uses_live_rate(self):
        resp = mock.Mock(); resp.json.return_value = {"rates": {"INR": 83.5}}
        resp.raise_for_status = lambda: None
        with mock.patch("currency.requests.get", return_value=resp) as g:
            self.assertEqual(currency.to_inr(10, "USD"), 835.0)
            currency.to_inr(20, "USD")
            self.assertEqual(g.call_count, 1, "rate must be cached")

    def test_no_rate_means_no_inr_value_not_a_guess(self):
        with mock.patch("currency.requests.get", side_effect=OSError("down")):
            self.assertIsNone(currency.to_inr(10, "USD"))

    def test_garbage_rate_rejected(self):
        resp = mock.Mock(); resp.json.return_value = {"rates": {"INR": "x"}}
        resp.raise_for_status = lambda: None
        with mock.patch("currency.requests.get", return_value=resp):
            self.assertIsNone(currency.to_inr(10, "USD"))
        resp.json.return_value = {"rates": {"INR": -1}}
        with mock.patch("currency.requests.get", return_value=resp):
            self.assertIsNone(currency.to_inr(10, "USD"))


def fake_serp(items=None, error=None):
    data = {"error": error} if error else {"shopping_results": items or []}
    return data


class TestSearchProducts(unittest.TestCase):
    def setUp(self):
        currency._RATE_CACHE.clear()
        self.key = mock.patch.object(shopping, "get_serpapi_key", return_value="SECRETKEY123")
        self.key.start()

    def tearDown(self):
        self.key.stop()

    def search(self, data):
        with mock.patch.object(shopping, "_raw_search", return_value=data):
            return shopping.search_products("phone")

    def test_india_market_requested(self):
        self.assertEqual(shopping.MARKET_PARAMS["gl"], "in")
        self.assertEqual(shopping.MARKET_PARAMS["google_domain"], "google.co.in")
        with mock.patch("shopping.requests.get") as g:
            g.return_value.json.return_value = {}
            shopping._raw_search.__wrapped__ if hasattr(shopping._raw_search, "__wrapped__") else None
            try:
                shopping._raw_search.__wrapped__("q", "k", 5)
            except AttributeError:
                shopping.requests.get.reset_mock()
                shopping.requests.get.return_value.json.return_value = {}
                shopping._raw_search("q", "k", 5)
            params = g.call_args.kwargs["params"]
        self.assertEqual(params["gl"], "in")

    def test_inr_product_normalised(self):
        products, err = self.search(fake_serp([{"title": "Phone", "price": "₹12,999",
            "extracted_price": 12999, "product_link": "https://x.in/p", "thumbnail": "https://i/1.jpg",
            "source": "Shop", "rating": 4.4, "old_price": "₹15,999", "extracted_old_price": 15999}]))
        self.assertIsNone(err)
        p = products[0]
        self.assertEqual((p["price_value"], p["currency"], p["old_price_value"]), (12999.0, "INR", 15999.0))

    def test_usd_without_rate_keeps_text_but_no_inr(self):
        with mock.patch("currency.requests.get", side_effect=OSError):
            products, _ = self.search(fake_serp([{"title": "Phone", "price": "$199", "extracted_price": 199}]))
        self.assertIsNone(products[0]["price_value"])
        self.assertEqual(products[0]["price"], "$199")
        self.assertEqual(products[0]["currency"], "USD")

    def test_usd_with_rate_converted(self):
        resp = mock.Mock(); resp.json.return_value = {"rates": {"INR": 80}}; resp.raise_for_status = lambda: None
        with mock.patch("currency.requests.get", return_value=resp):
            products, _ = self.search(fake_serp([{"title": "Phone", "price": "$10", "extracted_price": 10}]))
        self.assertEqual(products[0]["price_value"], 800.0)

    def test_missing_negative_malformed_prices(self):
        items = [{"title": "A"}, {"title": "B", "price": "₹-5", "extracted_price": -5},
                 {"title": "C", "price": "free!"}, {"title": "D", "price": "₹100", "extracted_price": "abc"}]
        products, _ = self.search(fake_serp(items))
        self.assertEqual([p["price_value"] for p in products], [None, None, None, 100.0])
        self.assertEqual(products[0]["price"], "Price unavailable")

    def test_unsafe_urls_dropped(self):
        products, _ = self.search(fake_serp([{"title": "A", "product_link": "javascript:alert(1)",
                                              "thumbnail": "file:///etc/passwd"}]))
        self.assertEqual((products[0]["link"], products[0]["image"]), ("", ""))

    def test_non_dict_items_and_bad_payload(self):
        products, _ = self.search(fake_serp(["junk", None, {"title": "ok"}]))
        self.assertEqual(len(products), 1)
        self.assertEqual(self.search([1, 2])[1], "request_failed")

    def test_empty_results(self):
        self.assertEqual(self.search(fake_serp([])), ([], "no_results"))
        self.assertEqual(self.search(fake_serp(error="Google hasn't returned any results for this query.")),
                         ([], "no_results"))

    def test_api_errors_classified_and_key_redacted(self):
        self.assertEqual(self.search(fake_serp(error="Invalid API key. Your API key should be here"))[1], "invalid_api_key")
        self.assertEqual(self.search(fake_serp(error="Your account has run out of searches."))[1], "quota_exceeded")
        err = self.search(fake_serp(error="boom api_key=SECRETKEY123"))[1]
        self.assertNotIn("SECRETKEY123", err)

    def test_exceptions_never_leak_key(self):
        import requests
        resp = mock.Mock(status_code=401)
        exc = requests.HTTPError("401 for url: https://serpapi.com/search.json?api_key=SECRETKEY123", response=resp)
        with mock.patch.object(shopping, "_raw_search", side_effect=exc):
            err = shopping.search_products("phone")[1]
        self.assertEqual(err, "invalid_api_key"); self.assertNotIn("SECRETKEY123", err)
        for e, want in ((requests.Timeout("x"), "timeout"), (requests.ConnectionError("x"), "network"),
                        (ValueError("api_key=SECRETKEY123"), "request_failed")):
            with mock.patch.object(shopping, "_raw_search", side_effect=e):
                self.assertEqual(shopping.search_products("phone")[1], want)

    def test_missing_key_and_empty_query(self):
        with mock.patch.object(shopping, "get_serpapi_key", return_value=""):
            self.assertEqual(shopping.search_products("x")[1], "no_api_key")
        self.assertEqual(shopping.search_products("   ")[1], "empty_query")

    def test_availability_only_when_stated(self):
        self.assertIsNone(shopping.extract_availability({"title": "x"}))
        self.assertEqual(shopping.extract_availability({"extensions": ["Out of stock"]}), "out_of_stock")
        self.assertEqual(shopping.extract_availability({"in_stock": True}), "in_stock")

    def test_details_parser_tolerates_garbage(self):
        for bad in (None, [], {}, {"product_results": {"stores": ["x", None], "user_reviews": [1, {}]}}):
            d = shopping.parse_product_details(bad)
            self.assertEqual(set(d), {"sellers", "reviews", "features"})


if __name__ == "__main__":
    unittest.main()
