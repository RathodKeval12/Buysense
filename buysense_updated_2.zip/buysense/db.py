"""
db.py
-----
All SQLite database helpers: schema setup, auth (signup / login /
password reset), shopper profile (interests / budget / brand
preferences used to personalize live SerpApi searches), search
history, wishlist, and feedback storage.
"""

import hashlib
import hmac
import os
import re
import sqlite3
from datetime import datetime, timedelta

import pandas as pd

import db_features

DB_PATH = "buysense_history.db"

SECURITY_QUESTIONS = [
    "What is your pet's name?",
    "What is your favorite teacher's name?",
    "What city were you born in?",
    "What is your favorite movie?",
]


VALID_THEMES = ("dark", "light")
VALID_LANGS = ("en", "hi", "gu")


def normalize_theme(value):
    """
    Always returns "dark" or "light".

    Older builds of the app saved the *display label* (e.g. "☀️ Light",
    "🌙 Dark", "☀️ લાઇટ") into the DB instead of the canonical key.
    This maps any such value back to a valid key so the app never crashes.
    """
    v = (value or "").strip().lower()
    if v in VALID_THEMES:
        return v
    light_markers = ("light", "☀", "लाइट", "લાઇટ")
    if any(m in v for m in light_markers):
        return "light"
    return "dark"


def normalize_lang(value):
    """Always returns one of VALID_LANGS ("en" / "hi" / "gu")."""
    v = (value or "").strip().lower()
    if v in VALID_LANGS:
        return v
    if "ગુજરાતી" in v or "gujarati" in v:
        return "gu"
    if "हिन्दी" in v or "hindi" in v:
        return "hi"
    return "en"


def init_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)

    # `history` is now the *search* history table (one row per live
    # SerpApi search a shopper runs from the Recommendation page)
    # instead of an ML-model prediction log. The old ML-era columns
    # (age_group / city_name / avg_order_value / confidence) are kept
    # in the schema for backward compatibility with existing DB files,
    # but new rows leave them NULL and use query/budget/results_count
    # instead (added below via the migration safety-net).
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            age_group TEXT,
            city_name TEXT,
            avg_order_value REAL,
            predicted_category TEXT,
            confidence REAL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password_hash TEXT NOT NULL,
            email TEXT,
            security_question TEXT,
            security_answer_hash TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            rating INTEGER NOT NULL,
            comment TEXT
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS wishlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            item_name TEXT NOT NULL,
            predicted_category TEXT
        )
        """
    )
    # Migration safety-net: if an older wishlist table already exists
    # without these columns (added for real SerpApi product data —
    # image, price, and a link to the live listing), add them so the
    # app doesn't crash on older databases.
    existing_wishlist_cols = {row[1] for row in conn.execute("PRAGMA table_info(wishlist)")}
    for col, ddl in [
        ("image_url", "ALTER TABLE wishlist ADD COLUMN image_url TEXT"),
        ("price", "ALTER TABLE wishlist ADD COLUMN price TEXT"),
        ("product_link", "ALTER TABLE wishlist ADD COLUMN product_link TEXT"),
    ]:
        if col not in existing_wishlist_cols:
            try:
                conn.execute(ddl)
            except sqlite3.OperationalError:
                pass

    # Migration safety-net: if an older `history` table already exists
    # without the search-based columns (query / budget / results_count),
    # add them so searches can be logged without breaking old DB files.
    existing_history_cols = {row[1] for row in conn.execute("PRAGMA table_info(history)")}
    for col, ddl in [
        ("query", "ALTER TABLE history ADD COLUMN query TEXT"),
        ("budget", "ALTER TABLE history ADD COLUMN budget TEXT"),
        ("results_count", "ALTER TABLE history ADD COLUMN results_count INTEGER"),
    ]:
        if col not in existing_history_cols:
            try:
                conn.execute(ddl)
            except sqlite3.OperationalError:
                pass

    # Migration safety-net: if an older DB already exists without these
    # columns, add them so the app doesn't crash. Includes the shopper
    # profile fields (interests / budget / brand preferences / price
    # sensitivity / rating preference) used to personalize live
    # SerpApi searches.
    existing_cols = {row[1] for row in conn.execute("PRAGMA table_info(users)")}
    for col, ddl in [
        ("email", "ALTER TABLE users ADD COLUMN email TEXT"),
        ("security_question", "ALTER TABLE users ADD COLUMN security_question TEXT"),
        ("security_answer_hash", "ALTER TABLE users ADD COLUMN security_answer_hash TEXT"),
        ("last_login", "ALTER TABLE users ADD COLUMN last_login TEXT"),
        ("email_notify", "ALTER TABLE users ADD COLUMN email_notify INTEGER DEFAULT 0"),
        ("theme_pref", "ALTER TABLE users ADD COLUMN theme_pref TEXT DEFAULT 'dark'"),
        ("lang_pref", "ALTER TABLE users ADD COLUMN lang_pref TEXT DEFAULT 'en'"),
        ("interests", "ALTER TABLE users ADD COLUMN interests TEXT"),
        ("preferred_categories", "ALTER TABLE users ADD COLUMN preferred_categories TEXT"),
        ("budget_min", "ALTER TABLE users ADD COLUMN budget_min REAL"),
        ("budget_max", "ALTER TABLE users ADD COLUMN budget_max REAL"),
        ("brand_preference", "ALTER TABLE users ADD COLUMN brand_preference TEXT"),
        ("price_sensitivity", "ALTER TABLE users ADD COLUMN price_sensitivity TEXT DEFAULT 'medium'"),
        ("min_rating", "ALTER TABLE users ADD COLUMN min_rating REAL DEFAULT 0"),
    ]:
        if col not in existing_cols:
            try:
                conn.execute(ddl)
            except sqlite3.OperationalError:
                pass

    # Repair rows saved by older builds (display labels like "☀️ Light"
    # instead of the canonical "light"/"dark" and "en"/"hi"/"gu" keys).
    try:
        for username, theme_val, lang_val in conn.execute(
            "SELECT username, theme_pref, lang_pref FROM users"
        ).fetchall():
            fixed_theme = normalize_theme(theme_val)
            fixed_lang = normalize_lang(lang_val)
            if fixed_theme != theme_val or fixed_lang != lang_val:
                conn.execute(
                    "UPDATE users SET theme_pref = ?, lang_pref = ? WHERE username = ?",
                    (fixed_theme, fixed_lang, username),
                )
    except sqlite3.OperationalError:
        pass

    conn.commit()

    # Smart-shopping tables (price history, alerts, review cache, ...).
    # Additive + re-runnable; a failure here must never stop the app.
    try:
        db_features.migrate(conn)
    except sqlite3.Error:
        pass
    return conn


PBKDF2_ITERATIONS = 200_000
_HASH_PREFIX = "pbkdf2_sha256"


def hash_password(password):
    """Salted PBKDF2-HMAC-SHA256 -> 'pbkdf2_sha256$iterations$salt$hash'."""
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"{_HASH_PREFIX}${PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def _legacy_hash(text):
    """Unsalted SHA-256 used by older BuySense versions (verify-only)."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def check_hash(text, stored):
    """
    Constant-time check of `text` against a stored hash.
    Returns (matches, needs_upgrade). Legacy unsalted hashes still verify
    so existing accounts keep working; callers re-hash them on success.
    """
    if not stored:
        return False, False
    if stored.startswith(_HASH_PREFIX + "$"):
        try:
            _, iterations, salt_hex, hash_hex = stored.split("$")
            digest = hashlib.pbkdf2_hmac(
                "sha256", text.encode("utf-8"), bytes.fromhex(salt_hex), int(iterations)
            )
            return hmac.compare_digest(digest.hex(), hash_hex), False
        except (ValueError, TypeError):
            return False, False
    return hmac.compare_digest(_legacy_hash(text), stored), True


def normalize_answer(answer):
    """Security answers are matched case/whitespace-insensitively."""
    return answer.strip().lower()


def password_strength(password):
    """Returns (label, score 0-4) for a simple strength meter."""
    score = 0
    if len(password) >= 8:
        score += 1
    if any(c.isupper() for c in password):
        score += 1
    if any(c.isdigit() for c in password):
        score += 1
    if any(not c.isalnum() for c in password):
        score += 1

    labels = {0: "Very Weak", 1: "Weak", 2: "Fair", 3: "Good", 4: "Strong"}
    return labels[score], score


MIN_PASSWORD_LENGTH = 8
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_.\-]{3,32}$")


def validate_username(username):
    """True if the name is 3-32 letters/digits/._- (no HTML or spaces)."""
    return bool(USERNAME_PATTERN.match((username or "").strip()))


def validate_new_password(password):
    """Returns None if acceptable, else an error code:
    'too_short' or 'too_weak'. Used by BOTH signup and password reset."""
    if len(password or "") < MIN_PASSWORD_LENGTH:
        return "too_short"
    if password_strength(password)[1] < 2:
        return "too_weak"
    return None


def create_user(conn, username, password, email, security_question, security_answer):
    """Returns True on success, False if the username already exists
    (usernames are compared case-insensitively to prevent look-alikes)."""
    username = (username or "").strip()
    if not validate_username(username):
        return False
    if conn.execute(
        "SELECT 1 FROM users WHERE lower(username) = lower(?) LIMIT 1", (username,)
    ).fetchone():
        return False
    try:
        conn.execute(
            """
            INSERT INTO users
            (username, password_hash, email, security_question, security_answer_hash, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                username,
                hash_password(password),
                email.strip(),
                security_question,
                hash_password(normalize_answer(security_answer)),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            ),
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False


_DUMMY_HASH = "pbkdf2_sha256$%d$%s$%s" % (PBKDF2_ITERATIONS, "00" * 16, "00" * 32)


def verify_user(conn, username, password):
    cur = conn.execute(
        "SELECT password_hash FROM users WHERE username = ?", (username,)
    )
    row = cur.fetchone()
    if row is None:
        # still do comparable work so timing doesn't reveal unknown usernames
        check_hash(password, _DUMMY_HASH)
        return False
    ok, needs_upgrade = check_hash(password, row[0])
    if not ok:
        return False
    if needs_upgrade:
        conn.execute(
            "UPDATE users SET password_hash = ? WHERE username = ?",
            (hash_password(password), username),
        )
    conn.execute(
        "UPDATE users SET last_login = ? WHERE username = ?",
        (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), username),
    )
    conn.commit()
    return True


def get_last_login(conn, username):
    cur = conn.execute("SELECT last_login FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    return row[0] if row and row[0] else None


def get_security_question(conn, username):
    cur = conn.execute(
        "SELECT security_question FROM users WHERE username = ?", (username,)
    )
    row = cur.fetchone()
    return row[0] if row else None


def verify_security_answer(conn, username, answer):
    cur = conn.execute(
        "SELECT security_answer_hash FROM users WHERE username = ?", (username,)
    )
    row = cur.fetchone()
    if row is None or row[0] is None:
        return False
    ok, needs_upgrade = check_hash(normalize_answer(answer), row[0])
    if ok and needs_upgrade:
        conn.execute(
            "UPDATE users SET security_answer_hash = ? WHERE username = ?",
            (hash_password(normalize_answer(answer)), username),
        )
        conn.commit()
    return ok


def reset_password(conn, username, new_password):
    conn.execute(
        "UPDATE users SET password_hash = ? WHERE username = ?",
        (hash_password(new_password), username),
    )
    conn.commit()


def get_user_email(conn, username):
    cur = conn.execute("SELECT email FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    return row[0] if row else None


def get_email_notify_pref(conn, username):
    cur = conn.execute("SELECT email_notify FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    return bool(row[0]) if row and row[0] is not None else False


def set_email_notify_pref(conn, username, enabled):
    conn.execute(
        "UPDATE users SET email_notify = ? WHERE username = ?",
        (1 if enabled else 0, username),
    )
    conn.commit()


def get_theme_pref(conn, username):
    cur = conn.execute("SELECT theme_pref FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    return normalize_theme(row[0]) if row and row[0] else "dark"


def set_theme_pref(conn, username, theme):
    conn.execute(
        "UPDATE users SET theme_pref = ? WHERE username = ?",
        (normalize_theme(theme), username),
    )
    conn.commit()


def get_lang_pref(conn, username):
    cur = conn.execute("SELECT lang_pref FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    return normalize_lang(row[0]) if row and row[0] else "en"


def set_lang_pref(conn, username, lang):
    conn.execute(
        "UPDATE users SET lang_pref = ? WHERE username = ?",
        (normalize_lang(lang), username),
    )
    conn.commit()


# ---------------------------------------------------------------
# Shopper profile (drives personalized SerpApi search queries)
# ---------------------------------------------------------------

def get_profile(conn, username):
    """Returns a dict of this shopper's saved personalization fields."""
    cur = conn.execute(
        """
        SELECT interests, preferred_categories, budget_min, budget_max,
               brand_preference, price_sensitivity, min_rating
        FROM users WHERE username = ?
        """,
        (username,),
    )
    row = cur.fetchone()
    if row is None:
        return {}
    return {
        "interests": row[0] or "",
        "preferred_categories": row[1] or "",
        "budget_min": row[2],
        "budget_max": row[3],
        "brand_preference": row[4] or "",
        "price_sensitivity": row[5] or "medium",
        "min_rating": row[6] if row[6] is not None else 0,
    }


def set_profile(
    conn,
    username,
    interests,
    preferred_categories,
    budget_min,
    budget_max,
    brand_preference,
    price_sensitivity,
    min_rating,
):
    conn.execute(
        """
        UPDATE users
        SET interests = ?, preferred_categories = ?, budget_min = ?, budget_max = ?,
            brand_preference = ?, price_sensitivity = ?, min_rating = ?
        WHERE username = ?
        """,
        (
            interests,
            preferred_categories,
            budget_min,
            budget_max,
            brand_preference,
            price_sensitivity,
            min_rating,
            username,
        ),
    )
    conn.commit()


# ---------------------------------------------------------------
# Wishlist
# ---------------------------------------------------------------

def add_to_wishlist(
    conn,
    username,
    item_name,
    predicted_category,
    image_url=None,
    price=None,
    product_link=None,
    price_value=None,
    product_key=None,
    source=None,
    rating=None,
    availability=None,
):
    """
    image_url / price / product_link are filled in when the item came
    from a real SerpApi Google Shopping result (always the case now
    that recommendations are dataset-free). price_value / product_key /
    source / rating are optional extras used by price tracking; returns
    the new wishlist row id.
    """
    cur = conn.execute(
        """
        INSERT INTO wishlist
        (username, timestamp, item_name, predicted_category, image_url, price, product_link)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            username,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            item_name,
            predicted_category,
            image_url,
            price,
            product_link,
        ),
    )
    new_id = cur.lastrowid
    conn.commit()
    if product_key or price_value is not None:
        try:
            db_features.update_wishlist_product_fields(
                conn, new_id, price_value, product_key, source, rating, availability
            )
        except sqlite3.Error:
            pass
    return new_id


def is_in_wishlist(conn, username, item_name):
    cur = conn.execute(
        "SELECT 1 FROM wishlist WHERE username = ? AND item_name = ? LIMIT 1",
        (username, item_name),
    )
    return cur.fetchone() is not None


def get_wishlist(conn, username):
    cur = conn.execute(
        "SELECT id, timestamp, item_name, predicted_category, image_url, price, product_link "
        "FROM wishlist WHERE username = ? ORDER BY id DESC",
        (username,),
    )
    rows = cur.fetchall()
    df = pd.DataFrame(
        rows,
        columns=["ID", "Timestamp", "Item", "Category", "Image", "Price", "Link"],
    )
    # Older rows (saved before the SerpApi integration) have NULL in the
    # new columns; turn those into None instead of NaN so callers can
    # just check `row.get("Image")` truthily.
    return df.where(pd.notnull(df), None)


def get_wishlist_count(conn, username):
    cur = conn.execute(
        "SELECT COUNT(*) FROM wishlist WHERE username = ?", (username,)
    )
    row = cur.fetchone()
    return row[0] if row else 0


def remove_from_wishlist(conn, wishlist_id, username):
    """Deletes a wishlist row ONLY if it belongs to `username`.
    Returns True if a row was removed."""
    cur = conn.execute(
        "DELETE FROM wishlist WHERE id = ? AND username = ?", (wishlist_id, username)
    )
    conn.commit()
    return cur.rowcount > 0


def clear_wishlist(conn, username):
    conn.execute("DELETE FROM wishlist WHERE username = ?", (username,))
    conn.commit()


# ---------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------

def save_feedback(conn, username, rating, comment):
    try:
        rating = int(rating)
    except (TypeError, ValueError):
        rating = 0
    rating = max(1, min(5, rating))
    comment = (comment or "").strip()[:2000]
    conn.execute(
        "INSERT INTO feedback (username, timestamp, rating, comment) VALUES (?, ?, ?, ?)",
        (username, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), rating, comment.strip()),
    )
    conn.commit()


def get_user_feedback(conn, username):
    cur = conn.execute(
        "SELECT timestamp, rating, comment FROM feedback WHERE username = ? ORDER BY id DESC",
        (username,),
    )
    rows = cur.fetchall()
    return pd.DataFrame(rows, columns=["Timestamp", "Rating", "Comment"])


def get_all_feedback(conn):
    cur = conn.execute(
        "SELECT username, timestamp, rating, comment FROM feedback ORDER BY id DESC"
    )
    rows = cur.fetchall()
    return pd.DataFrame(rows, columns=["Username", "Timestamp", "Rating", "Comment"])


# ---------------------------------------------------------------
# Search history (live SerpApi searches, replaces the old ML
# prediction history)
# ---------------------------------------------------------------

def save_search(conn, username, query, budget, category, results_count, avg_price=None):
    conn.execute(
        """
        INSERT INTO history
        (username, timestamp, query, budget, predicted_category, results_count, avg_price)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            username,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            query,
            budget,
            category,
            results_count,
            avg_price,
        ),
    )
    conn.commit()


def get_search_history(conn, username):
    cur = conn.execute(
        "SELECT timestamp, query, budget, predicted_category, results_count "
        "FROM history WHERE username = ? ORDER BY id DESC",
        (username,),
    )
    rows = cur.fetchall()
    return pd.DataFrame(
        rows,
        columns=["Timestamp", "Search Query", "Budget", "Category", "Results Found"],
    )


def clear_search_history(conn, username):
    conn.execute("DELETE FROM history WHERE username = ?", (username,))
    conn.commit()


# ---------------------------------------------------------------
# Platform-wide stats (Home page — no dataset, so these are derived
# from real usage stored in this database)
# ---------------------------------------------------------------

def get_platform_stats(conn):
    total_users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    total_searches = conn.execute("SELECT COUNT(*) FROM history").fetchone()[0]
    total_wishlist = conn.execute("SELECT COUNT(*) FROM wishlist").fetchone()[0]
    cur = conn.execute(
        "SELECT predicted_category, COUNT(*) c FROM history "
        "WHERE predicted_category IS NOT NULL AND predicted_category != '' "
        "GROUP BY predicted_category ORDER BY c DESC LIMIT 1"
    )
    row = cur.fetchone()
    top_category = row[0] if row else None
    return {
        "total_users": total_users,
        "total_searches": total_searches,
        "total_wishlist": total_wishlist,
        "top_category": top_category,
    }


def get_category_distribution(conn):
    """Category counts across every search ever logged (all users) —
    used for the Home page 'Category Mix' chart."""
    cur = conn.execute(
        "SELECT predicted_category, COUNT(*) c FROM history "
        "WHERE predicted_category IS NOT NULL AND predicted_category != '' "
        "GROUP BY predicted_category ORDER BY c DESC"
    )
    rows = cur.fetchall()
    return pd.Series({r[0]: r[1] for r in rows})


# ---------------------------------------------------------------
# Persistent failed-attempt lockout (survives page refreshes)
# ---------------------------------------------------------------

LOCKOUT_LIMIT = 5
LOCKOUT_MINUTES = 15


def _attempt_key(scope, username):
    return f"{scope}:{(username or '').strip().lower()[:64]}"


def _ensure_attempts_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS login_attempts (
            attempt_key TEXT PRIMARY KEY,
            failed_count INTEGER NOT NULL DEFAULT 0,
            locked_until TEXT,
            last_failed_at TEXT
        )
        """
    )


def lock_seconds_remaining(conn, scope, username):
    """Seconds left on an active lock for this scope+username (0 if none).
    scope is 'login' or 'reset'."""
    _ensure_attempts_table(conn)
    row = conn.execute(
        "SELECT locked_until FROM login_attempts WHERE attempt_key = ?",
        (_attempt_key(scope, username),),
    ).fetchone()
    if not row or not row[0]:
        return 0
    try:
        remaining = (datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S") - datetime.now()).total_seconds()
    except ValueError:
        return 0
    return max(0, int(remaining))


def register_failure(conn, scope, username):
    """Records a failed attempt. Returns (attempts_left, locked_seconds)."""
    _ensure_attempts_table(conn)
    key = _attempt_key(scope, username)
    row = conn.execute(
        "SELECT failed_count, locked_until FROM login_attempts WHERE attempt_key = ?", (key,)
    ).fetchone()
    count = (row[0] if row else 0) + 1
    now = datetime.now()
    locked_until = None
    if count >= LOCKOUT_LIMIT:
        locked_until = (now + timedelta(minutes=LOCKOUT_MINUTES)).strftime("%Y-%m-%d %H:%M:%S")
        count = 0  # a fresh allowance starts after the lock expires
    conn.execute(
        "INSERT INTO login_attempts (attempt_key, failed_count, locked_until, last_failed_at) "
        "VALUES (?, ?, ?, ?) ON CONFLICT(attempt_key) DO UPDATE SET "
        "failed_count = excluded.failed_count, locked_until = excluded.locked_until, "
        "last_failed_at = excluded.last_failed_at",
        (key, count, locked_until, now.strftime("%Y-%m-%d %H:%M:%S")),
    )
    conn.commit()
    if locked_until:
        return 0, LOCKOUT_MINUTES * 60
    return LOCKOUT_LIMIT - count, 0


def clear_failures(conn, scope, username):
    _ensure_attempts_table(conn)
    conn.execute("DELETE FROM login_attempts WHERE attempt_key = ?", (_attempt_key(scope, username),))
    conn.commit()
