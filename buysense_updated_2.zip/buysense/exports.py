"""
exports.py
----------
Safe CSV / PDF export of the search history.

Fixes two real problems:
  * PDF: fpdf2's built-in Helvetica only supports Latin-1, so a history
    row containing "₹" (every budgeted search has one) or Hindi/Gujarati
    text raised an exception and broke the whole History page.
    Text is now converted to Latin-1 with readable replacements.
  * CSV: values beginning with = + - @ are executed as formulas by Excel
    ("CSV injection"); they are prefixed with an apostrophe.
"""

import re
import unicodedata

import pandas as pd

_REPLACEMENTS = {
    "₹": "Rs.", "€": "EUR ", "£": "GBP ", "—": "-", "–": "-", "…": "...",
    "“": '"', "”": '"', "‘": "'", "’": "'", "•": "-", "★": "*", "⭐": "*",
}
_FORMULA_START = re.compile(r"^[=+\-@\t\r]")


def pdf_safe_text(value):
    """Latin-1-safe string for fpdf2 core fonts (unsupported letters -> '?')."""
    text = "" if value is None else str(value)
    for src, dst in _REPLACEMENTS.items():
        text = text.replace(src, dst)
    text = unicodedata.normalize("NFKC", text)
    return text.encode("latin-1", "replace").decode("latin-1")


def csv_safe_value(value):
    """Neutralises spreadsheet formulas in text cells (numbers untouched)."""
    if isinstance(value, str) and _FORMULA_START.match(value):
        return "'" + value
    return value


def csv_bytes(df):
    safe = df.copy()
    for col in safe.columns:
        # object OR pandas' newer dedicated string dtype
        if pd.api.types.is_object_dtype(safe[col]) or pd.api.types.is_string_dtype(safe[col]):
            safe[col] = safe[col].map(csv_safe_value)
    # utf-8 with BOM so Excel shows ₹ / Hindi / Gujarati correctly
    return safe.to_csv(index=False).encode("utf-8-sig")


def generate_history_pdf(history_df, username):
    """PDF table of the user's search history (requires fpdf2)."""
    from fpdf import FPDF

    pdf = FPDF(orientation="L", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=12)
    pdf.add_page()

    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, "BuySense - Recommendation History", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(0, 8, pdf_safe_text(f"User: {username}"), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(2)

    columns = list(history_df.columns)
    if not columns:
        return bytes(pdf.output())
    col_width = (pdf.w - 20) / len(columns)

    pdf.set_font("Helvetica", "B", 9)
    pdf.set_fill_color(124, 58, 237)
    pdf.set_text_color(255, 255, 255)
    for col in columns:
        pdf.cell(col_width, 8, pdf_safe_text(col), border=1, fill=True)
    pdf.ln()

    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(20, 20, 20)
    for _, row in history_df.iterrows():
        for col in columns:
            value = pdf_safe_text("" if row[col] is None else row[col])
            if len(value) > 28:
                value = value[:25] + "..."
            pdf.cell(col_width, 7, value, border=1)
        pdf.ln()

    return bytes(pdf.output())
