"""
page_chatbot.py
---------------
AI Buying Assistant page. Keeps everything the original chatbot had
(Groq model auto-discovery + fallback, Clear Chat, Refresh Models) and
adds: natural-language product requests answered from LIVE SerpApi
data, comparison of selected products, budget-fit explanations, and the
shopper's saved preferences. See assistant.py for the rules.
"""


import streamlit as st
from groq import Groq

import ai_helpers
import assistant
import db
import templates as tpl
from i18n import t

PREFERRED_MODELS = [
    "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "openai/gpt-oss-20b",
    "openai/gpt-oss-120b",
]
NON_CHAT_KEYWORDS = ("whisper", "guard", "tts", "playai", "safeguard")


def _candidate_models(client):
    """Chat models actually available on this Groq account, best first."""
    try:
        available = [m.id for m in client.models.list().data]
    except Exception:
        return PREFERRED_MODELS
    chat_models = [m for m in available if not any(k in m.lower() for k in NON_CHAT_KEYWORDS)]
    ordered = [m for m in PREFERRED_MODELS if m in chat_models]
    ordered += [m for m in chat_models if m not in ordered]
    return ordered or PREFERRED_MODELS


def _render_live_products(products):
    """Compact cards for the REAL products an answer is based on."""
    st.caption("📡 " + t("chat_live_products"))
    cols = st.columns(min(3, len(products)))
    for i, p in enumerate(products[:6]):
        with cols[i % len(cols)]:
            if p.get("image"):
                st.image(p["image"], use_container_width=True)
            st.markdown(f"**{p['title'][:60]}**")
            st.caption(f"{p.get('price') or '—'} · {p.get('source') or '—'}"
                       + (f" · ⭐ {p['rating']}" if p.get("rating") else ""))
            if p.get("link"):
                st.markdown(f"[🔗 {t('view_product')}]({p['link']})")


def render(conn, username):
    tpl.hero(t("chatbot_title"), t("chatbot_subtitle"), pill_text="Assistant")

    groq_api_key = ai_helpers.get_groq_key()
    if not groq_api_key:
        st.warning(t("err_no_groq_key_chat"))
        return

    client = Groq(api_key=groq_api_key, timeout=40)
    if "groq_models" not in st.session_state:
        st.session_state.groq_models = _candidate_models(client)

    # chat_history now holds only user/assistant turns (+ optional "products"
    # for cards); the system prompt is rebuilt per request with fresh context.
    if "chat_history" not in st.session_state or any(
        m.get("role") == "system" for m in st.session_state.chat_history
    ):
        st.session_state.chat_history = [
            m for m in st.session_state.get("chat_history", []) if m.get("role") != "system"
        ]

    st.caption("💡 " + t("chat_examples"))

    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("products"):
                _render_live_products(message["products"])

    user_input = st.chat_input(t("chat_placeholder"))

    if user_input:
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)

        lang = st.session_state.get("lang", "en")
        profile = db.get_profile(conn, username) if username else {}
        last_products = next(
            (m["products"] for m in reversed(st.session_state.chat_history) if m.get("products")), []
        )

        bot_response, last_error, shown_products = None, None, []
        with st.chat_message("assistant"):
            with st.spinner(t("thinking")):
                try:
                    turn = assistant.prepare_turn(conn, username, user_input, last_products, lang)
                except Exception:  # never let a lookup problem kill the chat
                    turn = {"intent": "general", "context": "", "products": [], "notice": None}
                shown_products = turn["products"]
                messages = assistant.build_messages(
                    st.session_state.chat_history, profile, turn["context"], lang
                )
                for model_name in st.session_state.groq_models:
                    try:
                        response = client.chat.completions.create(
                            model=model_name, messages=messages, temperature=0.4, max_tokens=700,
                        )
                        bot_response = response.choices[0].message.content
                        st.session_state.groq_models = [model_name] + [
                            m for m in st.session_state.groq_models if m != model_name
                        ]
                        break
                    except Exception as e:
                        last_error = e
                        continue

            if bot_response:
                st.markdown(bot_response)
                if turn.get("notice"):
                    st.caption("ℹ️ " + t(turn["notice"]))
                if shown_products:
                    _render_live_products(shown_products)
            else:
                st.error(t(ai_helpers.error_key(ai_helpers.friendly_error(last_error))))

        if bot_response:
            st.session_state.chat_history.append(
                {"role": "assistant", "content": bot_response, "products": shown_products}
            )
        else:
            st.session_state.chat_history.pop()  # drop the failed turn

    col_a, col_b = st.columns([1, 1])
    with col_a:
        if st.button(t("clear_chat")):
            st.session_state.chat_history = []
            st.rerun()
    with col_b:
        if st.button("🔄 " + t("refresh_models")):
            st.session_state.pop("groq_models", None)
            st.rerun()
