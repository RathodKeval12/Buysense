"""
page_budget.py
--------------
Smart Budget Optimizer: real live products grouped by how they sit
against the shopper's budget. It only states objective price
differences — no product is called "the best".

Groups (each product appears in exactly one):
  * Budget-Friendly Alternatives : price <= 70% of the budget
  * Within Budget                : 70% of budget < price <= budget
  * Slightly Above Budget        : budget < price <= budget * (1 + tolerance)
Products further above the budget, or with no price, are not shown.
"""

import streamlit as st

import db
import db_features as dbf
import model as ml
import shopping
import templates as tpl
import ui_components as ui
from i18n import t

ALT_RATIO = 0.7


def group_products(products, budget, tolerance):
    groups = {"alt": [], "within": [], "above": []}
    skipped = 0
    for p in products:
        price = p.get("price_value")
        if price is None:
            skipped += 1
            continue
        if price <= budget * ALT_RATIO:
            groups["alt"].append(p)
        elif price <= budget:
            groups["within"].append(p)
        elif price <= budget * (1 + tolerance):
            groups["above"].append(p)
    for g in groups.values():
        g.sort(key=lambda p: p["price_value"])
    return groups, skipped


def price_gap_text(price, budget):
    diff = price - budget
    pct = abs(diff) / budget * 100 if budget else 0
    if diff > 0:
        return t("above_budget_by", amount=f"₹{diff:,.0f}", pct=f"{pct:.0f}")
    if diff < 0:
        return t("below_budget_by", amount=f"₹{-diff:,.0f}", pct=f"{pct:.0f}")
    return t("exactly_budget")


def render(conn, username):
    tpl.hero(t("budget_title"), t("budget_subtitle"), pill_text=t("budget_pill"))
    profile = db.get_profile(conn, username) if username else {}

    with st.form("budget_form"):
        c1, c2 = st.columns(2)
        with c1:
            default_q = (profile.get("preferred_categories") or "").split(",")[0].strip()
            query = st.text_input(t("budget_what"), value=default_q, placeholder="running shoes")
            brand = st.text_input(t("brand_optional"), value=(profile.get("brand_preference") or "").split(",")[0].strip())
        with c2:
            budget = st.number_input(t("budget_amount"), min_value=0.0,
                                     value=float(profile.get("budget_max") or 5000.0), step=500.0)
            tolerance = st.slider(t("budget_tolerance"), 5, 30, 15, step=5)
            min_rating = st.slider(t("min_rating"), 0.0, 5.0, float(profile.get("min_rating") or 0.0), step=0.5)
        go = st.form_submit_button(t("budget_optimize_btn"))

    if go:
        if not query.strip() or budget <= 0:
            st.warning(t("budget_need_inputs"))
        elif not shopping.get_serpapi_key():
            st.error(t("err_no_serpapi_key"))
        else:
            # Query WITHOUT "under ₹budget" so slightly-above options can appear.
            q_profile = {"product_query": query.strip(), "brand_preference": brand.strip()}
            search_q = ml.build_search_query(q_profile)
            with st.spinner(t("searching_for", query=search_q)):
                products, error = shopping.search_products(search_q, num_results=20)
            if not products:
                if error == "no_results":
                    st.info(t("no_products_found"))
                else:
                    st.error(t(shopping.error_i18n_key(error)))
            else:
                if min_rating:
                    products = [p for p in products if not p.get("rating") or p["rating"] >= min_rating]
                rank_profile = dict(profile, budget_max=budget, brand_preference=brand.strip(), min_rating=min_rating)
                products = ml.rank_products(products, rank_profile)
                dbf.record_prices_for_products(conn, products, username or None)
                st.session_state["budget_results"] = {
                    "products": products, "budget": budget, "tolerance": tolerance / 100,
                    "query": search_q,
                }

    data = st.session_state.get("budget_results")
    if not data:
        return
    groups, skipped = group_products(data["products"], data["budget"], data["tolerance"])
    budget = data["budget"]

    st.caption(t("budget_results_for", query=data["query"], budget=f"₹{budget:,.0f}"))
    m1, m2, m3 = st.columns(3)
    with m1:
        tpl.metric_card(t("group_alternatives"), str(len(groups["alt"])))
    with m2:
        tpl.metric_card(t("group_within"), str(len(groups["within"])))
    with m3:
        tpl.metric_card(t("group_above"), str(len(groups["above"])))
    st.caption(t("budget_rules_note", alt="70", tol=f"{data['tolerance'] * 100:.0f}"))
    if skipped:
        st.caption(t("budget_skipped", n=skipped))

    counter = 0
    for key, title_key in (("within", "group_within"), ("above", "group_above"), ("alt", "group_alternatives")):
        items = groups[key]
        tpl.section_title(f"{t(title_key)} ({len(items)})")
        if not items:
            st.caption(t("budget_group_empty"))
            continue
        cols = st.columns(3)
        for i, p in enumerate(items):
            with cols[i % 3]:
                ui.render_product(conn, username, p, "bo", counter, all_products=data["products"],
                                  show_details=False)
                st.caption("📏 " + price_gap_text(p["price_value"], budget))
            counter += 1
