"""
assistant.py
------------
Logic behind the upgraded AI Buying Assistant (chatbot).

For every user message it decides what kind of help is needed and builds
a CONTEXT block for the model:

  search   -> runs the normal live SerpApi search for the parsed request
              and hands the model ONLY those real products.
  compare  -> hands the model the products in the compare basket (or the
              last products the assistant showed).
  suitable -> hands the model one real product plus the budget, for an
              objective "does this fit my budget?" explanation.
  general  -> no product data at all; the model gives general advice.

The system prompt forbids inventing prices, availability or product
names and requires the answer to separate "Live product data" from
"General advice". The Streamlit page (page_chatbot.py) renders the real
product cards separately from the model's text.
"""

import re

import streamlit as st

import db
import db_features as dbf
import model as ml
import nlsearch
import shopping
import ui_components as ui
from ai_helpers import LANG_NAMES

SYSTEM_PROMPT = """You are the BuySense AI Buying Assistant inside the BuySense
shopping app (live product data comes from Google Shopping via SerpApi).

STRICT RULES
- NEVER invent product names, prices, discounts, availability, sellers,
  reviews or specifications. The ONLY real product facts you may state are
  those inside the block marked LIVE PRODUCT DATA in this conversation.
  If no such block is present, you have no live product data: do not name
  specific products or quote prices — explain that live results are shown
  by searching, and give general guidance only.
- Keep two things visibly separate in your answer:
    "📡 Live product data" — only facts copied from the LIVE PRODUCT DATA block.
    "💡 General advice" — generic shopping guidance not tied to a specific listing.
  Omit a heading if you have nothing for it.
- Do not declare one product universally "the best". Describe objective
  differences (price, rating, seller) and say what each suits.
- Use the shopper's saved preferences (given below) only when they help.
- If information is missing, say it is unavailable instead of guessing.
- Be concise and practical; short bullet points are fine."""


def profile_summary(profile):
    """One-line description of the saved preferences (empty if none)."""
    if not profile:
        return ""
    parts = []
    if profile.get("interests"):
        parts.append(f"interests: {profile['interests']}")
    if profile.get("preferred_categories"):
        parts.append(f"preferred categories: {profile['preferred_categories']}")
    if profile.get("budget_max"):
        parts.append(f"usual max budget: ₹{profile['budget_max']:,.0f}")
    if profile.get("brand_preference"):
        parts.append(f"preferred brands: {profile['brand_preference']}")
    if profile.get("price_sensitivity"):
        parts.append(f"price sensitivity: {profile['price_sensitivity']}")
    if profile.get("min_rating"):
        parts.append(f"minimum rating: {profile['min_rating']}")
    return "; ".join(parts)


def detect_intent(text):
    t_ = (text or "").lower()
    if re.search(r"\bcompare\b|\bcomparison\b|\bversus\b|\bvs\.?\b|\bdifference between\b", t_):
        return "compare"
    if re.search(r"\bwhy\b.*\b(suitable|fit|good|right)\b|\bsuitable for my budget\b|\bwithin my budget\b|\bfit my budget\b", t_):
        return "suitable"
    if nlsearch.looks_like_product_request(text):
        return "search"
    return "general"


def format_product_line(p):
    bits = [p.get("title", "")]
    bits.append(f"price: {p.get('price') or 'unavailable'}")
    if p.get("rating"):
        bits.append(f"rating: {p['rating']}")
    if p.get("source"):
        bits.append(f"seller: {p['source']}")
    if p.get("old_price"):
        bits.append(f"was: {p['old_price']}")
    if p.get("availability"):
        bits.append(f"availability: {p['availability']}")
    return " | ".join(bits)


def live_block(products):
    return "LIVE PRODUCT DATA (real, from Google Shopping):\n" + "\n".join(
        f"{i}. {format_product_line(p)}" for i, p in enumerate(products, 1)
    )


def _candidate_products(last_products):
    """Products 'these/this' most likely refers to, in priority order."""
    basket = ui.get_compare_list()
    if len(basket) >= 2:
        return basket
    if last_products:
        return last_products[:4]
    results = st.session_state.get("reco_results")
    if results:
        return results["products"][:4]
    return basket


def prepare_turn(conn, username, text, last_products, lang="en"):
    """
    Returns dict:
      intent, context (str added as an extra system message, or ""),
      products (real products to render as cards, may be []),
      notice (i18n key for UI-level notices or None)
    """
    intent = detect_intent(text)
    profile = db.get_profile(conn, username) if username else {}
    out = {"intent": intent, "context": "", "products": [], "notice": None}

    if intent == "search":
        if not shopping.get_serpapi_key():
            out["notice"] = "err_no_serpapi_key"
            out["context"] = ("No live product data is available (search is not configured). "
                              "Do not name or price any products.")
            return out
        params, _ = nlsearch.parse_query(text, lang)
        # saved taste carries over; budget/brand come from the message itself
        taste = {k: profile.get(k) for k in ("interests", "preferred_categories",
                                              "price_sensitivity", "min_rating")}
        search_profile = nlsearch.params_to_profile(params, taste)
        query = ml.build_search_query(search_profile)
        products, error = shopping.search_products(query, num_results=10)
        if not products:
            out["notice"] = "chat_no_live_results"
            out["context"] = (f"A live search for '{query}' returned no products"
                              f"{' (' + error + ')' if error and error != 'no_results' else ''}. "
                              "Say so; do not name or price any products.")
            return out
        ranked = ml.rank_products(products, search_profile)[:6]
        dbf.record_prices_for_products(conn, products, username or None)
        out["products"] = ranked
        out["context"] = (
            f"Search interpreted as: {nlsearch_summary(params)}. Query sent: '{query}'.\n"
            + live_block(ranked)
        )
        return out

    if intent == "compare":
        cands = _candidate_products(last_products)
        if len(cands) < 2:
            out["context"] = ("The shopper asked to compare products but fewer than two real "
                              "products are selected. Tell them to add 2–4 products with "
                              "'Add to Compare' on the Recommendation page, or ask for a search "
                              "such as 'find a phone under ₹30,000'. Do not invent products.")
            return out
        out["products"] = cands[:4]
        out["context"] = live_block(cands[:4]) + (
            "\nCompare ONLY these products using price, rating and seller. Quote the exact "
            "price differences from the data. Do not pick a universal winner.")
        return out

    if intent == "suitable":
        cands = _candidate_products(last_products)
        if not cands:
            out["context"] = ("The shopper asked whether a product suits their budget but no real "
                              "product is selected. Ask them to pick one (Add to Compare / run a "
                              "search first). Do not invent a product.")
            return out
        product = cands[0]
        budget = nlsearch.rule_parse(text).get("budget_max") or profile.get("budget_max")
        out["products"] = [product]
        budget_line = (f"Shopper's budget: ₹{float(budget):,.0f}." if budget
                       else "The shopper's budget is unknown — say so and ask for it.")
        out["context"] = (live_block([product]) + "\n" + budget_line +
                          "\nExplain objectively how the price compares with the budget and what "
                          "the rating/seller data does and doesn't show.")
        return out

    return out  # general advice: no live context


def nlsearch_summary(params):
    bits = [params.get("product") or ""]
    if params.get("brand"):
        bits.append(f"brand {params['brand']}")
    if params.get("budget_max"):
        bits.append(f"max ₹{params['budget_max']:,.0f}")
    if params.get("min_rating") is not None:
        bits.append(f"min rating {params['min_rating']}")
    return ", ".join(b for b in bits if b)


def build_messages(history, profile, context, lang):
    """
    history: list of {"role","content",...} (extra keys are dropped).
    Returns a clean message list for the Groq API.
    """
    system = SYSTEM_PROMPT
    summary = profile_summary(profile)
    system += f"\n\nShopper's saved preferences: {summary or 'none saved'}."
    system += f"\nReply in {LANG_NAMES.get(lang, 'English')}."
    messages = [{"role": "system", "content": system}]
    for m in history[-12:]:
        if m["role"] in ("user", "assistant"):
            messages.append({"role": m["role"], "content": m["content"]})
    if context:
        # placed right before the latest user turn so it is the freshest instruction
        messages.insert(len(messages) - 1, {"role": "system", "content": context})
    return messages
