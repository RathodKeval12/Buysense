"""
page_dashboard.py
-----------------
Smart Shopping Dashboard: personal statistics computed from the user's
own searches, wishlist and alerts stored in the BuySense database.
Metrics with no data yet show "—" instead of a made-up value.
"""

import re
from collections import Counter

import matplotlib.pyplot as plt
import streamlit as st

import db
import db_features as dbf
import model as ml
import nlsearch
import templates as tpl
from i18n import t


def most_preferred_brand(conn, username, profile):
    """Most frequent known brand across wishlist titles and search queries;
    falls back to the first brand saved in the profile."""
    brands = [b.strip() for b in (profile.get("brand_preference") or "").split(",") if b.strip()]
    known = list(dict.fromkeys(nlsearch.KNOWN_BRANDS + brands))
    texts = list(dbf.get_search_queries(conn, username))
    wl = dbf.get_wishlist_advanced(conn, username)
    texts += list(wl["Item"]) if not wl.empty else []
    counts = Counter()
    for text in texts:
        for b in known:
            if re.search(r"(?<![a-z0-9])" + re.escape(b.lower()) + r"(?![a-z0-9])", str(text).lower()):
                counts[b] += 1
    if counts:
        return counts.most_common(1)[0][0]
    return brands[0] if brands else None


def _bar(series_labels, series_values, title, ylabel):
    fig, ax = plt.subplots(figsize=(7, 3.6))
    ml.styled_fig_theme(fig, ax, theme=st.session_state.theme)
    ax.bar(series_labels, series_values, color=ml.CHART_PRIMARY)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=40)
    ml.plot_figure(fig)


def render(conn, username):
    tpl.hero(t("dash_title"), t("dash_subtitle"), pill_text=t("dash_pill"))
    if not username:
        st.warning(t("enter_name_view"))
        return
    try:
        stats = dbf.get_user_dashboard_stats(conn, username)
        profile = db.get_profile(conn, username)
        brand = most_preferred_brand(conn, username, profile)
    except Exception:
        st.error(t("db_error"))
        return

    def dash(v, fmt="{}"):
        return fmt.format(v) if v not in (None, "") else "—"

    rating_pref = profile.get("min_rating") or stats["avg_saved_rating"]
    rows = [
        [(t("total_searches"), dash(stats["total_searches"])),
         (t("wishlist_count"), dash(stats["wishlist_count"])),
         (t("most_searched_category"), dash(stats["top_category"]))],
        [(t("avg_price_searched"), dash(stats["avg_price_searched"] and round(stats["avg_price_searched"]), "₹{:,}")),
         (t("most_preferred_brand"), dash(brand)),
         (t("avg_rating_pref"), dash(rating_pref and round(float(rating_pref), 1), "{} ⭐"))],
        [(t("price_alerts_active"), dash(stats["price_alerts_active"])),
         (t("price_alerts_triggered"), dash(stats["price_alerts_triggered"])),
         (t("avail_alerts_active"), dash(stats["availability_alerts_active"]))],
    ]
    for row in rows:
        cols = st.columns(3)
        for col, (label, value) in zip(cols, row):
            with col:
                tpl.metric_card(label, value)
        st.write("")

    left, right = st.columns(2)
    with left:
        tpl.section_title(t("searches_over_time"))
        per_day = dbf.get_searches_per_day(conn, username)
        if per_day.empty:
            st.info(t("dash_no_data"))
        else:
            _bar(per_day["Date"], per_day["Searches"], "Searches per day", "Searches")
    with right:
        tpl.section_title(t("category_mix_mine"))
        history = db.get_search_history(conn, username)
        cats = history["Category"].dropna()
        cats = cats[cats != ""].value_counts()
        if cats.empty:
            st.info(t("dash_no_data"))
        else:
            _bar(list(cats.index), list(cats.values), "Searches by category", "Searches")

    st.write("")
    tpl.section_title(t("saved_products"))
    wl = dbf.get_wishlist_advanced(conn, username)
    if wl.empty:
        st.info(t("wishlist_empty"))
    else:
        top = wl.head(5)
        for _, r in top.iterrows():
            st.markdown(f"- **{r['Item'][:70]}** — {r.get('Price') or '—'}")

    st.write("")
    tpl.section_title(t("recent_searches"))
    recent = dbf.get_recent_searches(conn, username)
    if recent.empty:
        st.info(t("dash_no_data"))
    else:
        st.dataframe(recent, use_container_width=True, hide_index=True)
