"""
i18n.py
-------
Lightweight multi-language support for BuySense.

Covers the main chrome of the app (navigation, page heroes, key
buttons and common messages) in three languages:
    en -> English
    hi -> Hindi
    gu -> Gujarati

Field-level labels inside the long Recommendation form (age group,
browsing minutes, interest sliders, etc.) and chart captions are
intentionally left in English to keep this file a manageable size —
those are technical/data terms that most users recognise either way.
Add more keys here any time; every call site uses t(key) so nothing
else needs to change.
"""

import streamlit as st

LANGUAGES = {
    "en": "English",
    "hi": "हिन्दी",
    "gu": "ગુજરાતી",
}

TRANSLATIONS = {
    # ---------------- Brand / sidebar ----------------
    "brand_tag": {
        "en": "Discovery Engine",
        "hi": "डिस्कवरी इंजन",
        "gu": "ડિસ્કવરી એન્જિન",
    },
    "logged_in_as": {
        "en": "👋 Logged in as **{username}**",
        "hi": "👋 लॉगिन किया गया **{username}** के रूप में",
        "gu": "👋 **{username}** તરીકે લૉગિન થયેલ છે",
    },
    "last_login": {
        "en": "🕒 Last login: {value}",
        "hi": "🕒 पिछला लॉगिन: {value}",
        "gu": "🕒 છેલ્લો લૉગિન: {value}",
    },
    "logout": {"en": "🚪 Logout", "hi": "🚪 लॉगआउट", "gu": "🚪 લૉગઆઉટ"},
    "wishlist_badge": {
        "en": "❤️ Wishlist: {count} saved",
        "hi": "❤️ विशलिस्ट: {count} सेव किए गए",
        "gu": "❤️ વિશલિસ્ટ: {count} સેવ થયેલ",
    },
    "theme_label": {"en": "🎨 Theme", "hi": "🎨 थीम", "gu": "🎨 થીમ"},
    "theme_dark": {"en": "🌙 Dark", "hi": "🌙 डार्क", "gu": "🌙 ડાર્ક"},
    "theme_light": {"en": "☀️ Light", "hi": "☀️ लाइट", "gu": "☀️ લાઇટ"},
    "language_label": {"en": "🌐 Language", "hi": "🌐 भाषा", "gu": "🌐 ભાષા"},

    # ---------------- Nav menu ----------------
    "nav_home": {"en": "Home", "hi": "होम", "gu": "હોમ"},
    "nav_recommendation": {"en": "Recommendation", "hi": "अनुशंसा", "gu": "ભલામણ"},
    "nav_model": {"en": "ML Model Used", "hi": "उपयोग किया गया मॉडल", "gu": "વપરાયેલ મોડેલ"},
    "nav_comparison": {"en": "Model Comparison", "hi": "मॉडल तुलना", "gu": "મોડેલ સરખામણી"},
    "nav_history": {"en": "My History", "hi": "मेरा इतिहास", "gu": "મારો ઇતિહાસ"},
    "nav_wishlist": {"en": "Wishlist", "hi": "विशलिस्ट", "gu": "વિશલિસ્ટ"},
    "nav_feedback": {"en": "Feedback", "hi": "फीडबैक", "gu": "ફીડબેક"},
    "nav_dataset": {"en": "Dataset", "hi": "डेटासेट", "gu": "ડેટાસેટ"},
    "nav_chatbot": {"en": "Chatbot", "hi": "चैटबॉट", "gu": "ચેટબોટ"},
    "nav_profile": {"en": "Profile", "hi": "प्रोफ़ाइल", "gu": "પ્રોફાઇલ"},
    "nav_about": {"en": "About", "hi": "जानकारी", "gu": "વિશે"},

    # ---------------- Login page ----------------
    "tab_login": {"en": "🔑 Login", "hi": "🔑 लॉगिन", "gu": "🔑 લૉગિન"},
    "tab_signup": {"en": "🆕 Sign Up", "hi": "🆕 साइन अप", "gu": "🆕 સાઇન અપ"},
    "tab_forgot": {"en": "❓ Forgot Password", "hi": "❓ पासवर्ड भूल गए", "gu": "❓ પાસવર્ડ ભૂલી ગયા"},
    "btn_login": {"en": "Login", "hi": "लॉगिन करें", "gu": "લૉગિન કરો"},
    "btn_create_account": {"en": "Create Account", "hi": "खाता बनाएं", "gu": "એકાઉન્ટ બનાવો"},
    "btn_reset_password": {"en": "Reset Password", "hi": "पासवर्ड रीसेट करें", "gu": "પાસવર્ડ રીસેટ કરો"},

    # ---------------- Home ----------------
    "home_title": {
        "en": "Intelligent Product Discovery Engine",
        "hi": "इंटेलिजेंट प्रोडक्ट डिस्कवरी इंजन",
        "gu": "ઇન્ટેલિજન્ટ પ્રોડક્ટ ડિસ્કવરી એન્જિન",
    },
    "home_subtitle": {
        "en": "BuySense reads browsing behavior, purchase history, and interest signals to "
              "surface the product category each shopper is most likely to love — then backs "
              "it up with real product ideas.",
        "hi": "BuySense ब्राउज़िंग व्यवहार, खरीद इतिहास और रुचि के संकेतों को पढ़कर हर ग्राहक "
              "के लिए सबसे उपयुक्त प्रोडक्ट कैटेगरी सुझाता है — और असली प्रोडक्ट आइडिया भी देता है।",
        "gu": "BuySense બ્રાઉઝિંગ વર્તન, ખરીદીનો ઇતિહાસ અને રસના સંકેતો વાંચીને દરેક ગ્રાહકને સૌથી "
              "વધુ પસંદ આવે તેવી પ્રોડક્ટ કેટેગરી બતાવે છે — અને સાચા પ્રોડક્ટ આઇડિયા પણ આપે છે.",
    },

    # ---------------- Recommendation ----------------
    "reco_title": {
        "en": "Personalized Recommendation",
        "hi": "व्यक्तिगत अनुशंसा",
        "gu": "વ્યક્તિગત ભલામણ",
    },
    "reco_subtitle": {
        "en": "Enter shopper details and interest levels below to generate a product "
              "category recommendation, sample products, and a confidence breakdown.",
        "hi": "प्रोडक्ट कैटेगरी अनुशंसा, नमूना प्रोडक्ट और कॉन्फिडेंस देखने के लिए नीचे "
              "ग्राहक की जानकारी और रुचि स्तर भरें।",
        "gu": "પ્રોડક્ટ કેટેગરી ભલામણ, નમૂના પ્રોડક્ટ્સ અને કોન્ફિડન્સ મેળવવા માટે નીચે ગ્રાહકની "
              "વિગતો અને રસનું સ્તર ભરો.",
    },
    "btn_get_recommendation": {
        "en": "✨ Get Recommendation", "hi": "✨ अनुशंसा प्राप्त करें", "gu": "✨ ભલામણ મેળવો",
    },
    "saved_to_history": {
        "en": "✅ Saved to history for **{username}**",
        "hi": "✅ **{username}** के इतिहास में सेव हो गया",
        "gu": "✅ **{username}** ના ઇતિહાસમાં સેવ થયું",
    },
    "enter_name_history": {
        "en": "ℹ️ Enter your name in the sidebar to save this to your history.",
        "hi": "ℹ️ इसे इतिहास में सेव करने के लिए साइडबार में अपना नाम भरें।",
        "gu": "ℹ️ આ ઇતિહાસમાં સેવ કરવા સાઇડબારમાં તમારું નામ ભરો.",
    },
    "add_to_wishlist": {"en": "🤍 Add to Wishlist", "hi": "🤍 विशलिस्ट में जोड़ें", "gu": "🤍 વિશલિસ્ટમાં ઉમેરો"},
    "added_to_wishlist": {"en": "Added to wishlist!", "hi": "विशलिस्ट में जोड़ा गया!", "gu": "વિશલિસ્ટમાં ઉમેરાયું!"},

    # ---------------- Wishlist page ----------------
    "wishlist_title": {"en": "My Wishlist", "hi": "मेरी विशलिस्ट", "gu": "મારી વિશલિસ્ટ"},
    "wishlist_subtitle": {
        "en": "Products you saved from your recommendations, all in one place.",
        "hi": "आपकी अनुशंसाओं से सेव किए गए प्रोडक्ट, सब एक ही जगह।",
        "gu": "તમારી ભલામણોમાંથી સેવ કરેલા પ્રોડક્ટ્સ, બધા એક જ જગ્યાએ.",
    },
    "wishlist_empty": {
        "en": "Your wishlist is empty — add items from the Recommendation page.",
        "hi": "आपकी विशलिस्ट खाली है — अनुशंसा पेज से आइटम जोड़ें।",
        "gu": "તમારી વિશલિસ્ટ ખાલી છે — ભલામણ પેજ પરથી આઇટમ ઉમેરો.",
    },
    "remove": {"en": "🗑 Remove", "hi": "🗑 हटाएं", "gu": "🗑 દૂર કરો"},
    "clear_wishlist": {"en": "🗑 Clear Wishlist", "hi": "🗑 विशलिस्ट खाली करें", "gu": "🗑 વિશલિસ્ટ ખાલી કરો"},

    # ---------------- History ----------------
    "history_title": {"en": "My Recommendation History", "hi": "मेरा अनुशंसा इतिहास", "gu": "મારો ભલામણ ઇતિહાસ"},
    "history_subtitle": {
        "en": "Every prediction you generate on the Recommendation page is saved here, "
              "tied to the name you enter in the sidebar.",
        "hi": "Recommendation पेज पर बनाई गई हर भविष्यवाणी यहां सेव होती है, जो साइडबार "
              "में दिए गए नाम से जुड़ी होती है।",
        "gu": "Recommendation પેજ પર બનાવેલી દરેક આગાહી અહીં સેવ થાય છે, જે સાઇડબારમાં "
              "આપેલા નામ સાથે જોડાયેલ છે.",
    },
    "clear_history": {"en": "🗑 Clear My History", "hi": "🗑 मेरा इतिहास साफ़ करें", "gu": "🗑 મારો ઇતિહાસ સાફ કરો"},
    "download_csv": {"en": "⬇️ Download CSV", "hi": "⬇️ CSV डाउनलोड करें", "gu": "⬇️ CSV ડાઉનલોડ કરો"},
    "download_pdf": {"en": "⬇️ Download PDF", "hi": "⬇️ PDF डाउनलोड करें", "gu": "⬇️ PDF ડાઉનલોડ કરો"},
    "enter_name_view": {
        "en": "👈 Enter your name in the sidebar to view or build your history.",
        "hi": "👈 इतिहास देखने या बनाने के लिए साइडबार में अपना नाम भरें।",
        "gu": "👈 ઇતિહાસ જોવા કે બનાવવા સાઇડબારમાં તમારું નામ ભરો.",
    },
    "no_history_yet": {
        "en": "No history yet — go to **Recommendation** and generate a prediction first.",
        "hi": "अभी कोई इतिहास नहीं है — पहले **Recommendation** पर जाएं और भविष्यवाणी बनाएं।",
        "gu": "હજુ કોઈ ઇતિહાસ નથી — પહેલા **Recommendation** પર જાઓ અને આગાહી બનાવો.",
    },

    # ---------------- Feedback ----------------
    "feedback_title": {"en": "Share Your Feedback", "hi": "अपनी प्रतिक्रिया दें", "gu": "તમારો ફીડબેક આપો"},
    "feedback_subtitle": {
        "en": "Tell us what you think of BuySense — your rating and comments help "
              "improve the recommendation engine and overall experience.",
        "hi": "BuySense के बारे में अपनी राय बताएं — आपकी रेटिंग और कमेंट अनुशंसा इंजन और "
              "अनुभव को बेहतर बनाने में मदद करते हैं।",
        "gu": "BuySense વિશે તમારો અભિપ્રાય જણાવો — તમારું રેટિંગ અને કમેન્ટ ભલામણ એન્જિન અને "
              "અનુભવ સુધારવામાં મદદ કરે છે.",
    },
    "btn_submit_feedback": {"en": "Submit Feedback", "hi": "फीडबैक भेजें", "gu": "ફીડબેક સબમિટ કરો"},

    # ---------------- Profile ----------------
    "profile_title": {"en": "My Profile", "hi": "मेरी प्रोफ़ाइल", "gu": "મારી પ્રોફાઇલ"},
    "profile_subtitle": {
        "en": "Manage your account details and notification preferences.",
        "hi": "अपनी खाता जानकारी और सूचना प्राथमिकताएं प्रबंधित करें।",
        "gu": "તમારી એકાઉન્ટ વિગતો અને નોટિફિકેશન પસંદગીઓ મેનેજ કરો.",
    },
    "email_notify_label": {
        "en": "📧 Email me when I get a new recommendation",
        "hi": "📧 नई अनुशंसा मिलने पर मुझे ईमेल करें",
        "gu": "📧 નવી ભલામણ મળે ત્યારે મને ઇમેલ કરો",
    },
    "email_notify_saved": {
        "en": "Preference saved!", "hi": "पसंद सेव हो गई!", "gu": "પસંદગી સેવ થઈ!",
    },
    "email_sent": {"en": "📧 Notification email sent.", "hi": "📧 सूचना ईमेल भेजी गई।", "gu": "📧 નોટિફિકેશન ઇમેલ મોકલાયો."},
    "email_not_configured": {
        "en": "Email notifications are enabled, but SMTP isn't configured yet — see README.",
        "hi": "ईमेल सूचनाएं चालू हैं, लेकिन SMTP अभी सेट नहीं है — README देखें।",
        "gu": "ઇમેલ નોટિફિકેશન ચાલુ છે, પણ SMTP હજુ સેટ નથી — README જુઓ.",
    },

    # ---------------- Chatbot ----------------
    "chatbot_title": {"en": "BuySense AI Chatbot", "hi": "BuySense AI चैटबॉट", "gu": "BuySense AI ચેટબોટ"},
    "chatbot_subtitle": {
        "en": "Ask anything about products, shopping, or recommendations.",
        "hi": "प्रोडक्ट, शॉपिंग या अनुशंसाओं के बारे में कुछ भी पूछें।",
        "gu": "પ્રોડક્ટ, શોપિંગ કે ભલામણો વિશે કંઈ પણ પૂછો.",
    },
    "clear_chat": {"en": "🗑 Clear Chat", "hi": "🗑 चैट साफ़ करें", "gu": "🗑 ચેટ સાફ કરો"},

    # ---------------- Dataset ----------------
    "dataset_title": {"en": "Dataset", "hi": "डेटासेट", "gu": "ડેટાસેટ"},
    "dataset_subtitle": {
        "en": "Explore the custom dataset used to train the BuySense recommendation model.",
        "hi": "BuySense मॉडल को ट्रेन करने में उपयोग किए गए डेटासेट को देखें।",
        "gu": "BuySense મોડેલને ટ્રેન કરવા વપરાયેલ ડેટાસેટ જુઓ.",
    },

    # ---------------- About ----------------
    "about_title": {"en": "About BuySense", "hi": "BuySense के बारे में", "gu": "BuySense વિશે"},
    "about_subtitle": {
        "en": "BuySense helps shoppers quickly discover the right product category by "
              "learning their intent from behavior signals and interest patterns.",
        "hi": "BuySense व्यवहार और रुचि के पैटर्न से इरादा समझकर ग्राहकों को सही प्रोडक्ट "
              "कैटेगरी जल्दी खोजने में मदद करता है।",
        "gu": "BuySense વર્તન અને રસના પેટર્ન પરથી ઇરાદો સમજીને ગ્રાહકોને યોગ્ય પ્રોડક્ટ "
              "કેટેગરી ઝડપથી શોધવામાં મદદ કરે છે.",
    },
}


def t(key, lang=None, **kwargs):
    """Translate a key into the active language (falls back to English)."""
    if lang is None:
        lang = st.session_state.get("lang", "en")
    entry = TRANSLATIONS.get(key)
    if entry is None:
        return key
    text = entry.get(lang) or entry.get("en") or key
    if kwargs:
        try:
            text = text.format(**kwargs)
        except Exception:
            pass
    return text


# Translations for the smart-shopping features live in i18n_extra.py;
# merging here keeps every call site on the single t(key) helper above.
from i18n_extra import EXTRA as _EXTRA  # noqa: E402

TRANSLATIONS.update(_EXTRA)
