"""
currency.py
-----------
Price parsing and INR conversion for BuySense.

Rules (so prices are never silently mislabelled):
  * The currency of a listing is read from its price text (₹, Rs, INR,
    $, €, £ ...). If no currency can be identified it is None and the
    price is NOT used for INR budget filtering or ranking.
  * Only INR prices are used as-is. Other currencies are converted ONLY
    with a live rate from a configured exchange-rate service
    (EXCHANGE_RATE_URL, default https://open.er-api.com/v6/latest/{base}).
    If the rate can't be fetched the product keeps its original price
    text and has no INR value — no rate is ever invented.
"""

import os
import re
import time

import requests

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

DEFAULT_RATE_URL = "https://open.er-api.com/v6/latest/{base}"
RATE_TTL_SECONDS = 12 * 3600
_RATE_CACHE = {}  # base -> (timestamp, inr_rate)

# Longest tokens first so "US$" wins over "$".
_SYMBOLS = [
    ("rs.", "INR"), ("rs ", "INR"), ("inr", "INR"), ("₹", "INR"), ("rupee", "INR"),
    ("us$", "USD"), ("usd", "USD"), ("a$", "AUD"), ("c$", "CAD"), ("$", "USD"),
    ("eur", "EUR"), ("€", "EUR"), ("gbp", "GBP"), ("£", "GBP"),
    ("aed", "AED"), ("sgd", "SGD"), ("jpy", "JPY"), ("¥", "JPY"),
]


def detect_currency(price_text):
    """ISO code found in a price string such as '₹1,299' or '$12.99', else None."""
    if not price_text:
        return None
    text = str(price_text).strip().lower()
    if text.startswith("rs") and not text.startswith("rs."):
        text = "rs " + text[2:]
    for token, code in _SYMBOLS:
        if token in text:
            return code
    return None


_NUMBER = re.compile(r"\d[\d,.\s]*\d|\d")


def parse_amount(price_text):
    """
    First numeric amount in a price string -> float (or None).
    Handles '₹1,29,999.00', '1.299,50 €', '$12.99 - $20' (first value),
    'From ₹499'. Negative or zero amounts return None.
    """
    if price_text is None:
        return None
    if isinstance(price_text, (int, float)):
        return float(price_text) if price_text > 0 else None
    match = _NUMBER.search(str(price_text))
    if not match:
        return None
    # A minus sign right before the number (optionally after a currency
    # symbol: "-₹50", "₹-5") means a negative amount -> not a valid price.
    before = re.sub(r"[\s₹$€£¥]|rs\.?|inr|usd|eur|gbp", "", str(price_text)[: match.start()].lower())
    if before.endswith(("-", "−")):
        return None
    raw = re.sub(r"\s", "", match.group(0))
    if "," in raw and "." in raw:
        # the later separator is the decimal mark
        if raw.rfind(",") > raw.rfind("."):
            raw = raw.replace(".", "").replace(",", ".")
        else:
            raw = raw.replace(",", "")
    elif "," in raw:
        head, _, tail = raw.rpartition(",")
        # A single comma followed by exactly 2 digits and a short head
        # ("12,50") is a decimal comma; otherwise commas are thousands
        # separators ("1,299", "1,29,999").
        if raw.count(",") == 1 and len(tail) == 2 and len(head) <= 3:
            raw = head + "." + tail
        else:
            raw = raw.replace(",", "")
    elif raw.count(".") > 1:
        raw = raw.replace(".", "")
    try:
        value = float(raw)
    except ValueError:
        return None
    return value if value > 0 else None


def _rate_url(base):
    url = os.environ.get("EXCHANGE_RATE_URL", "")
    if not url and st is not None:
        try:
            url = st.secrets.get("EXCHANGE_RATE_URL", "")
        except Exception:
            url = ""
    return (url or DEFAULT_RATE_URL).format(base=base)


def get_inr_rate(base):
    """Live `1 base = x INR` rate, or None when unavailable. Cached 12h."""
    base = (base or "").upper()
    if base == "INR":
        return 1.0
    cached = _RATE_CACHE.get(base)
    if cached and time.time() - cached[0] < RATE_TTL_SECONDS:
        return cached[1]
    try:
        resp = requests.get(_rate_url(base), timeout=8)
        resp.raise_for_status()
        data = resp.json()
        rate = (data.get("rates") or {}).get("INR")
        rate = float(rate)
        if rate <= 0:
            return None
    except Exception:
        return None
    _RATE_CACHE[base] = (time.time(), rate)
    return rate


def to_inr(amount, currency):
    """Converts `amount` in `currency` to INR; None if unknown/unavailable."""
    if amount is None or not currency:
        return None
    rate = get_inr_rate(currency)
    if rate is None:
        return None
    return round(amount * rate, 2)
