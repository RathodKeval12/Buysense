"""
db_features.py
--------------
Database support for the BuySense "smart shopping" features. Everything
here EXTENDS the existing SQLite database created by db.py — nothing is
dropped or rewritten, and every migration is additive and re-runnable.

New tables
    price_history         one row per observed (product, seller, price, time)
    price_alerts          target-price alert per wishlist item
    availability_alerts   back-in-stock alert per wishlist item
    review_summaries      cached Groq review summaries
    wishlist_notes        category + note per wishlist item
    product_comparisons   saved comparison sets
    notifications         in-app notifications (price / availability alerts)

New columns on existing tables (added only if missing)
    wishlist.price_value, wishlist.product_key, wishlist.source,
    wishlist.rating, wishlist.current_price_value,
    wishlist.current_price_checked_at, wishlist.availability
    history.avg_price

db.init_db() calls migrate() so existing databases upgrade silently the
first time the updated app starts.
"""

import json
import math
import sqlite3
from datetime import datetime, timedelta

import pandas as pd


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _add_missing_columns(conn, table, columns):
    """columns: {name: 'SQL type'} — adds whichever are missing."""
    existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
    for name, ddl_type in columns.items():
        if name not in existing:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl_type}")
            except sqlite3.OperationalError:
                pass


def migrate(conn):
    """Creates the new tables/indexes and adds new columns. Safe to re-run."""
    # Needed so ON DELETE CASCADE works (removing a wishlist item also
    # removes its alerts / note).
    conn.execute("PRAGMA foreign_keys = ON")

    _add_missing_columns(
        conn,
        "wishlist",
        {
            "price_value": "REAL",
            "product_key": "TEXT",
            "source": "TEXT",
            "rating": "REAL",
            "current_price_value": "REAL",
            "current_price_checked_at": "TEXT",
            "availability": "TEXT",
        },
    )
    _add_missing_columns(conn, "history", {"avg_price": "REAL"})

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS price_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_key TEXT NOT NULL,
            title TEXT NOT NULL,
            source TEXT,
            price REAL NOT NULL,
            recorded_at TEXT NOT NULL,
            username TEXT
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_price_history_key_time "
        "ON price_history (product_key, recorded_at)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_price_history_user ON price_history (username)"
    )

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS price_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            wishlist_id INTEGER NOT NULL UNIQUE,
            target_price REAL NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1,
            last_price REAL,
            last_checked_at TEXT,
            last_notified_price REAL,
            last_notified_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (wishlist_id) REFERENCES wishlist(id) ON DELETE CASCADE
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_price_alerts_user ON price_alerts (username)"
    )

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS availability_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            wishlist_id INTEGER NOT NULL UNIQUE,
            enabled INTEGER NOT NULL DEFAULT 1,
            last_status TEXT,
            last_checked_at TEXT,
            last_notified_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (wishlist_id) REFERENCES wishlist(id) ON DELETE CASCADE
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_availability_alerts_user "
        "ON availability_alerts (username)"
    )

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS review_summaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_key TEXT NOT NULL,
            lang TEXT NOT NULL,
            reviews_hash TEXT NOT NULL,
            summary_json TEXT NOT NULL,
            model TEXT,
            created_at TEXT NOT NULL,
            UNIQUE (product_key, lang, reviews_hash)
        )
        """
    )

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS wishlist_notes (
            wishlist_id INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            category TEXT,
            note TEXT,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (wishlist_id) REFERENCES wishlist(id) ON DELETE CASCADE
        )
        """
    )

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS product_comparisons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            title TEXT NOT NULL,
            products_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_comparisons_user ON product_comparisons (username)"
    )

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            kind TEXT NOT NULL,
            message TEXT NOT NULL,
            link TEXT,
            created_at TEXT NOT NULL,
            is_read INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications (username, is_read)"
    )
    conn.commit()


# ---------------------------------------------------------------
# Price history
# ---------------------------------------------------------------

# Don't store the same price for the same seller again within this window.
PRICE_DEDUP_HOURS = 6


def record_price(conn, product_key, title, source, price, username=None):
    """
    Stores one observed price. Skips the insert if the same seller's
    last stored price for this product is identical and recent, so
    re-running a search doesn't pile up duplicate points.
    Returns True if a row was inserted.
    """
    if not product_key or price is None:
        return False
    try:
        price = float(price)
    except (TypeError, ValueError):
        return False
    if not math.isfinite(price) or price <= 0:  # NaN / inf / zero / negative
        return False

    row = conn.execute(
        "SELECT price, recorded_at FROM price_history "
        "WHERE product_key = ? AND COALESCE(source,'') = ? ORDER BY id DESC LIMIT 1",
        (product_key, source or ""),
    ).fetchone()
    if row and abs(row[0] - price) < 0.005:
        try:
            last = datetime.strptime(row[1], "%Y-%m-%d %H:%M:%S")
            if datetime.now() - last < timedelta(hours=PRICE_DEDUP_HOURS):
                return False
        except ValueError:
            pass

    conn.execute(
        "INSERT INTO price_history (product_key, title, source, price, recorded_at, username) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (product_key, title, source or "", price, _now(), username),
    )
    conn.commit()
    return True


def record_prices_for_products(conn, products, username=None):
    """Records every priced product from a live search. Returns rows inserted."""
    inserted = 0
    try:
        for p in products:
            if record_price(
                conn, p.get("key"), p.get("title") or "", p.get("source"),
                p.get("price_value"), username,
            ):
                inserted += 1
    except sqlite3.Error:
        pass  # price history is a bonus — never break a search over it
    return inserted


def get_price_points(conn, product_key, source=None):
    """
    Returns a DataFrame [recorded_at (datetime), source, price] for a
    product. source=None -> all sellers.
    """
    sql = "SELECT recorded_at, source, price FROM price_history WHERE product_key = ?"
    params = [product_key]
    if source:
        sql += " AND COALESCE(source,'') = ?"
        params.append(source)
    sql += " ORDER BY recorded_at ASC, id ASC"
    rows = conn.execute(sql, params).fetchall()
    df = pd.DataFrame(rows, columns=["recorded_at", "source", "price"])
    if not df.empty:
        df["recorded_at"] = pd.to_datetime(df["recorded_at"])
    return df


def get_tracked_products(conn, username):
    """Products this user has encountered, newest first:
    list of (product_key, latest_title, observations)."""
    rows = conn.execute(
        """
        SELECT product_key, MAX(title), COUNT(*)
        FROM price_history WHERE username = ?
        GROUP BY product_key ORDER BY MAX(id) DESC LIMIT 300
        """,
        (username,),
    ).fetchall()
    return rows


def get_price_sellers(conn, product_key):
    rows = conn.execute(
        "SELECT DISTINCT COALESCE(source,'') FROM price_history WHERE product_key = ?",
        (product_key,),
    ).fetchall()
    return sorted(r[0] for r in rows if r[0])


# ---------------------------------------------------------------
# Wishlist (advanced)
# ---------------------------------------------------------------

def update_wishlist_product_fields(conn, wishlist_id, price_value, product_key, source,
                                   rating, availability=None):
    conn.execute(
        "UPDATE wishlist SET price_value = ?, product_key = ?, source = ?, rating = ?, "
        "availability = ?, "
        "current_price_value = COALESCE(current_price_value, ?), "
        "current_price_checked_at = COALESCE(current_price_checked_at, ?) WHERE id = ?",
        (price_value, product_key, source, rating, availability, price_value, _now(), wishlist_id),
    )
    conn.commit()


def set_wishlist_availability(conn, wishlist_id, availability):
    """Stores the latest availability the data source reported (never guessed)."""
    conn.execute("UPDATE wishlist SET availability = ? WHERE id = ?", (availability, wishlist_id))
    conn.commit()


def get_wishlist_id(conn, username, item_name):
    row = conn.execute(
        "SELECT id FROM wishlist WHERE username = ? AND item_name = ? ORDER BY id DESC LIMIT 1",
        (username, item_name),
    ).fetchone()
    return row[0] if row else None


def set_wishlist_current_price(conn, wishlist_id, price_value):
    conn.execute(
        "UPDATE wishlist SET current_price_value = ?, current_price_checked_at = ? WHERE id = ?",
        (price_value, _now(), wishlist_id),
    )
    conn.commit()


def get_wishlist_advanced(conn, username):
    """
    Wishlist joined with note/category, price alert and availability
    alert. One row per saved item.
    """
    rows = conn.execute(
        """
        SELECT w.id, w.timestamp, w.item_name, w.predicted_category, w.image_url,
               w.price, w.product_link, w.price_value, w.product_key, w.source,
               w.rating, w.current_price_value, w.current_price_checked_at, w.availability,
               n.category, n.note,
               pa.target_price, pa.enabled, pa.last_notified_at,
               aa.enabled, aa.last_status
        FROM wishlist w
        LEFT JOIN wishlist_notes n ON n.wishlist_id = w.id
        LEFT JOIN price_alerts pa ON pa.wishlist_id = w.id
        LEFT JOIN availability_alerts aa ON aa.wishlist_id = w.id
        WHERE w.username = ?
        ORDER BY w.id DESC
        """,
        (username,),
    ).fetchall()
    cols = [
        "ID", "Timestamp", "Item", "SavedCategory", "Image", "Price", "Link",
        "SavedPriceValue", "ProductKey", "Source", "Rating", "CurrentPriceValue",
        "PriceCheckedAt", "Availability", "UserCategory", "Note", "TargetPrice", "PriceAlertOn",
        "PriceAlertNotifiedAt", "AvailAlertOn", "AvailStatus",
    ]
    # object dtype so missing values are real None (not NaN) everywhere
    df = pd.DataFrame(rows, columns=cols).astype(object)
    return df.where(pd.notnull(df), None)


def owns_wishlist_item(conn, username, wishlist_id):
    """True only if wishlist row `wishlist_id` belongs to `username`."""
    return conn.execute(
        "SELECT 1 FROM wishlist WHERE id = ? AND username = ?", (wishlist_id, username)
    ).fetchone() is not None


def save_wishlist_note(conn, wishlist_id, username, category, note):
    if not owns_wishlist_item(conn, username, wishlist_id):
        return False
    conn.execute(
        """
        INSERT INTO wishlist_notes (wishlist_id, username, category, note, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(wishlist_id) DO UPDATE SET
            category = excluded.category, note = excluded.note, updated_at = excluded.updated_at
        """,
        (wishlist_id, username, (category or "").strip()[:60], (note or "").strip()[:500], _now()),
    )
    conn.commit()
    return True


# ---------------------------------------------------------------
# Price alerts
# ---------------------------------------------------------------

def set_price_alert(conn, username, wishlist_id, target_price, enabled):
    """Creates/updates the alert. Changing the target resets the
    'already notified' marker so the new target can fire again.
    Returns False (and changes nothing) for an invalid target or for a
    wishlist item that isn't the user's."""
    try:
        target_price = float(target_price)
    except (TypeError, ValueError):
        return False
    if not (target_price > 0) or target_price != target_price or target_price == float("inf"):
        return False
    if not owns_wishlist_item(conn, username, wishlist_id):
        return False
    existing = conn.execute(
        "SELECT target_price FROM price_alerts WHERE wishlist_id = ?", (wishlist_id,)
    ).fetchone()
    if existing is None:
        conn.execute(
            "INSERT INTO price_alerts (username, wishlist_id, target_price, enabled, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (username, wishlist_id, float(target_price), 1 if enabled else 0, _now()),
        )
    else:
        reset = abs(existing[0] - float(target_price)) > 0.005
        conn.execute(
            "UPDATE price_alerts SET target_price = ?, enabled = ?"
            + (", last_notified_price = NULL" if reset else "")
            + " WHERE wishlist_id = ?",
            (float(target_price), 1 if enabled else 0, wishlist_id),
        )
    conn.commit()
    return True


def get_active_price_alerts(conn, username):
    """[(alert_id, wishlist_id, item_name, product_key, source, target, last_notified_price)]"""
    return conn.execute(
        """
        SELECT pa.id, pa.wishlist_id, w.item_name, w.product_key, w.source,
               pa.target_price, pa.last_notified_price
        FROM price_alerts pa JOIN wishlist w ON w.id = pa.wishlist_id
        WHERE pa.username = ? AND pa.enabled = 1
        """,
        (username,),
    ).fetchall()


def mark_price_checked(conn, alert_id, price, notified):
    """Records the latest price seen. `notified` True stores it as the
    price we already alerted on; a price back above target clears it
    (handled by the caller passing clear=True via set below)."""
    if notified:
        conn.execute(
            "UPDATE price_alerts SET last_price = ?, last_checked_at = ?, "
            "last_notified_price = ?, last_notified_at = ? WHERE id = ?",
            (price, _now(), price, _now(), alert_id),
        )
    else:
        conn.execute(
            "UPDATE price_alerts SET last_price = ?, last_checked_at = ? WHERE id = ?",
            (price, _now(), alert_id),
        )
    conn.commit()


def clear_price_notified(conn, alert_id):
    """Price went back above target: allow a future drop to alert again."""
    conn.execute(
        "UPDATE price_alerts SET last_notified_price = NULL WHERE id = ?", (alert_id,)
    )
    conn.commit()


def count_price_alerts(conn, username):
    """(active_alerts, triggered_alerts) — triggered = notified at least once."""
    active = conn.execute(
        "SELECT COUNT(*) FROM price_alerts WHERE username = ? AND enabled = 1", (username,)
    ).fetchone()[0]
    triggered = conn.execute(
        "SELECT COUNT(*) FROM price_alerts WHERE username = ? AND last_notified_at IS NOT NULL",
        (username,),
    ).fetchone()[0]
    return active, triggered


# ---------------------------------------------------------------
# Availability alerts
# ---------------------------------------------------------------

def set_availability_alert(conn, username, wishlist_id, enabled, status=None):
    if not owns_wishlist_item(conn, username, wishlist_id):
        return False
    existing = conn.execute(
        "SELECT id FROM availability_alerts WHERE wishlist_id = ?", (wishlist_id,)
    ).fetchone()
    if existing is None:
        conn.execute(
            "INSERT INTO availability_alerts "
            "(username, wishlist_id, enabled, last_status, created_at) VALUES (?, ?, ?, ?, ?)",
            (username, wishlist_id, 1 if enabled else 0, status, _now()),
        )
    else:
        conn.execute(
            "UPDATE availability_alerts SET enabled = ? WHERE wishlist_id = ?",
            (1 if enabled else 0, wishlist_id),
        )
    conn.commit()
    return True


def get_active_availability_alerts(conn, username):
    """[(alert_id, wishlist_id, item_name, product_key, source, last_status)]"""
    return conn.execute(
        """
        SELECT aa.id, aa.wishlist_id, w.item_name, w.product_key, w.source, aa.last_status
        FROM availability_alerts aa JOIN wishlist w ON w.id = aa.wishlist_id
        WHERE aa.username = ? AND aa.enabled = 1
        """,
        (username,),
    ).fetchall()


def update_availability_status(conn, alert_id, status, notified=False):
    if notified:
        conn.execute(
            "UPDATE availability_alerts SET last_status = ?, last_checked_at = ?, "
            "last_notified_at = ? WHERE id = ?",
            (status, _now(), _now(), alert_id),
        )
    else:
        conn.execute(
            "UPDATE availability_alerts SET last_status = ?, last_checked_at = ? WHERE id = ?",
            (status, _now(), alert_id),
        )
    conn.commit()


# ---------------------------------------------------------------
# Notifications (in-app)
# ---------------------------------------------------------------

def add_notification(conn, username, kind, message, link=None):
    conn.execute(
        "INSERT INTO notifications (username, kind, message, link, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (username, kind, message, link, _now()),
    )
    conn.commit()


def get_notifications(conn, username, unread_only=False, limit=50):
    sql = (
        "SELECT id, kind, message, link, created_at, is_read FROM notifications "
        "WHERE username = ?"
    )
    if unread_only:
        sql += " AND is_read = 0"
    sql += " ORDER BY id DESC LIMIT ?"
    return conn.execute(sql, (username, limit)).fetchall()


def count_unread_notifications(conn, username):
    return conn.execute(
        "SELECT COUNT(*) FROM notifications WHERE username = ? AND is_read = 0", (username,)
    ).fetchone()[0]


def mark_notifications_read(conn, username):
    conn.execute("UPDATE notifications SET is_read = 1 WHERE username = ?", (username,))
    conn.commit()


# ---------------------------------------------------------------
# Review summaries (cache)
# ---------------------------------------------------------------

def get_cached_review_summary(conn, product_key, lang, reviews_hash):
    row = conn.execute(
        "SELECT summary_json FROM review_summaries "
        "WHERE product_key = ? AND lang = ? AND reviews_hash = ?",
        (product_key, lang, reviews_hash),
    ).fetchone()
    if not row:
        return None
    try:
        return json.loads(row[0])
    except ValueError:
        return None


def save_review_summary(conn, product_key, lang, reviews_hash, summary, model=None):
    conn.execute(
        "INSERT OR REPLACE INTO review_summaries "
        "(product_key, lang, reviews_hash, summary_json, model, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (product_key, lang, reviews_hash, json.dumps(summary, ensure_ascii=False), model, _now()),
    )
    conn.commit()


# ---------------------------------------------------------------
# Saved comparisons
# ---------------------------------------------------------------

def save_comparison(conn, username, title, products):
    """products: list of product dicts (stored as a snapshot)."""
    conn.execute(
        "INSERT INTO product_comparisons (username, title, products_json, created_at) "
        "VALUES (?, ?, ?, ?)",
        (username, title, json.dumps(products, ensure_ascii=False), _now()),
    )
    conn.commit()


def get_saved_comparisons(conn, username):
    """[(id, title, products(list), created_at)]"""
    out = []
    for cid, title, blob, created in conn.execute(
        "SELECT id, title, products_json, created_at FROM product_comparisons "
        "WHERE username = ? ORDER BY id DESC LIMIT 50",
        (username,),
    ).fetchall():
        try:
            out.append((cid, title, json.loads(blob), created))
        except ValueError:
            continue
    return out


def delete_comparison(conn, username, comparison_id):
    conn.execute(
        "DELETE FROM product_comparisons WHERE id = ? AND username = ?",
        (comparison_id, username),
    )
    conn.commit()


# ---------------------------------------------------------------
# Dashboard statistics
# ---------------------------------------------------------------

def get_user_dashboard_stats(conn, username):
    """All per-user numbers used by the Shopping Dashboard (None = no data)."""
    total_searches = conn.execute(
        "SELECT COUNT(*) FROM history WHERE username = ?", (username,)
    ).fetchone()[0]

    top_cat = conn.execute(
        "SELECT predicted_category, COUNT(*) c FROM history WHERE username = ? "
        "AND predicted_category IS NOT NULL AND predicted_category != '' "
        "GROUP BY predicted_category ORDER BY c DESC LIMIT 1",
        (username,),
    ).fetchone()

    avg_price = conn.execute(
        "SELECT AVG(avg_price) FROM history WHERE username = ? AND avg_price IS NOT NULL",
        (username,),
    ).fetchone()[0]

    wishlist_count = conn.execute(
        "SELECT COUNT(*) FROM wishlist WHERE username = ?", (username,)
    ).fetchone()[0]

    avg_saved_rating = conn.execute(
        "SELECT AVG(rating) FROM wishlist WHERE username = ? AND rating IS NOT NULL",
        (username,),
    ).fetchone()[0]

    active_alerts, triggered_alerts = count_price_alerts(conn, username)
    avail_alerts = conn.execute(
        "SELECT COUNT(*) FROM availability_alerts WHERE username = ? AND enabled = 1",
        (username,),
    ).fetchone()[0]

    return {
        "total_searches": total_searches,
        "top_category": top_cat[0] if top_cat else None,
        "avg_price_searched": avg_price,
        "wishlist_count": wishlist_count,
        "avg_saved_rating": avg_saved_rating,
        "price_alerts_active": active_alerts,
        "price_alerts_triggered": triggered_alerts,
        "availability_alerts_active": avail_alerts,
    }


def get_recent_searches(conn, username, limit=8):
    rows = conn.execute(
        "SELECT timestamp, query, budget, predicted_category, results_count "
        "FROM history WHERE username = ? ORDER BY id DESC LIMIT ?",
        (username, limit),
    ).fetchall()
    return pd.DataFrame(
        rows, columns=["Timestamp", "Search Query", "Budget", "Category", "Results Found"]
    )


def get_search_queries(conn, username, limit=200):
    return [
        r[0]
        for r in conn.execute(
            "SELECT query FROM history WHERE username = ? AND query IS NOT NULL "
            "ORDER BY id DESC LIMIT ?",
            (username, limit),
        ).fetchall()
    ]


def get_searches_per_day(conn, username, days=30):
    rows = conn.execute(
        "SELECT substr(timestamp, 1, 10) d, COUNT(*) FROM history WHERE username = ? "
        "AND timestamp >= ? GROUP BY d ORDER BY d",
        (username, (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")),
    ).fetchall()
    return pd.DataFrame(rows, columns=["Date", "Searches"])
