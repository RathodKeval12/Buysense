"""
shopping.py
-----------
Live product search powered by SerpApi's Google Shopping engine.

This is the ONLY source of product data in BuySense. There is no
offline dataset or static catalog: every title, price, image, rating,
seller, and link shown to a shopper comes straight from a SerpApi
Google Shopping response.

The SerpApi key is read the same way every other API key in this
project is (GROQ_API_KEY, SMTP_*): first from an environment variable,
then from `.streamlit/secrets.toml`. Nothing crashes and no error is
raised in the UI if it isn't configured — callers get an empty list
back (with a reason string) and the page shows a clear "not
configured" message instead of any fake product.

Required setting (env var or .streamlit/secrets.toml):
    SERPAPI_API_KEY   your key from https://serpapi.com/manage-api-key
"""

import os
import re

import requests

import currency

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

SERPAPI_ENDPOINT = "https://serpapi.com/search.json"
REQUEST_TIMEOUT = 12  # seconds
DEFAULT_NUM_RESULTS = 12


def get_serpapi_key():
    """Returns the configured SerpApi key, or "" if not set anywhere."""
    key = os.environ.get("SERPAPI_API_KEY", "")
    if not key and st is not None:
        try:
            key = st.secrets.get("SERPAPI_API_KEY", "")
        except Exception:
            key = ""
    return key


def _parse_price(price_text):
    """Numeric amount from a price string (currency NOT converted here)."""
    return currency.parse_amount(price_text)


def safe_url(url, allow_data_image=False):
    """Only http(s) links (and optionally inline images) are ever rendered;
    anything else (javascript:, file:, ...) is dropped."""
    if not isinstance(url, str):
        return ""
    url = url.strip()
    low = url.lower()
    if low.startswith(("https://", "http://")):
        return url
    if allow_data_image and low.startswith("data:image/"):
        return url
    return ""


_API_KEY_IN_TEXT = re.compile(r"api_key=[^&\s\"']+", re.IGNORECASE)


def safe_error(exc):
    """
    Short error code for an exception. Never contains the request URL,
    so the SerpApi key (a query parameter) can't reach the UI or logs.
    """
    status = getattr(getattr(exc, "response", None), "status_code", None)
    if status in (401, 403):
        return "invalid_api_key"
    if status == 429:
        return "rate_limited"
    if status:
        return f"http_{status}"
    if isinstance(exc, requests.exceptions.Timeout):
        return "timeout"
    if isinstance(exc, requests.exceptions.ConnectionError):
        return "network"
    return "request_failed"


def classify_api_error(message):
    """Maps SerpApi's own `error` text to a short code (key redacted)."""
    text = _API_KEY_IN_TEXT.sub("api_key=***", str(message or "")).lower()
    if "hasn't returned any results" in text or "no results" in text:
        return "no_results"
    if "invalid api key" in text or "api key" in text and "invalid" in text:
        return "invalid_api_key"
    if "run out of searches" in text or "out of searches" in text or "quota" in text:
        return "quota_exceeded"
    if "rate limit" in text or "too many requests" in text:
        return "rate_limited"
    return "request_failed"


def error_i18n_key(error):
    """i18n key for a shopping error code (see i18n_extra.py)."""
    return {
        "invalid_api_key": "err_serp_auth",
        "quota_exceeded": "err_serp_quota",
        "rate_limited": "err_serp_rate",
        "timeout": "err_timeout",
        "network": "err_network",
    }.get(error, "err_serp_generic")


# BuySense shows every price in INR, so the search is pinned to Google's
# India market (gl=in, google.co.in). Without these SerpApi defaults to
# the US store and returns USD prices.
MARKET_PARAMS = {"gl": "in", "hl": "en", "google_domain": "google.co.in"}


def _raw_search(query, api_key, num_results):
    params = {
        "engine": "google_shopping",
        "q": query,
        "api_key": api_key,
        "num": num_results,
        **MARKET_PARAMS,
    }
    response = requests.get(SERPAPI_ENDPOINT, params=params, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    return response.json()


# Cache identical queries for 30 minutes so re-rendering the same
# recommendation (theme/lang switches, reruns, etc.) doesn't re-hit the
# API or burn extra SerpApi credits.
if st is not None:
    _raw_search = st.cache_data(ttl=1800, show_spinner=False)(_raw_search)


def normalize_price(item, currency_hint=None):
    """
    Returns (inr_value | None, currency_code | None, display_text).

    * INR listings: used as-is.
    * Other currencies: converted with a live configured rate; if no
      rate is available the INR value is None and the ORIGINAL price text
      is still shown (never a made-up number).
    * No currency symbol at all: SerpApi was asked for the India market
      (MARKET_PARAMS), so a bare number is INR; with no price at all the
      result is (None, None, "Price unavailable").
    """
    text = item.get("price")
    amount = item.get("extracted_price")
    if not isinstance(amount, (int, float)) or isinstance(amount, bool) or amount <= 0:
        # missing / invalid numeric field -> fall back to the displayed text
        amount = currency.parse_amount(text)
    if amount is None:
        return None, currency.detect_currency(text), (text or "Price unavailable")

    cur = currency.detect_currency(text) or currency_hint or "INR"
    display = text if text else f"₹{amount:,.0f}"
    if cur == "INR":
        return float(amount), "INR", display
    return currency.to_inr(float(amount), cur), cur, display


def search_products(query, num_results=DEFAULT_NUM_RESULTS):
    """
    Queries SerpApi Google Shopping for `query` and returns
    (products, error) where products is a list of up to `num_results`
    normalized dicts, each with ONLY real data from SerpApi:

        {"title", "price", "price_value", "image", "link", "source", "rating"}

    error is None on success, "no_api_key" if SERPAPI_API_KEY isn't
    configured, or a short message string if the request itself failed.
    Never raises — callers can always show a friendly message instead
    of a fake product.
    """
    api_key = get_serpapi_key()
    if not api_key:
        return [], "no_api_key"

    if not query or not query.strip():
        return [], "empty_query"

    try:
        data = _raw_search(query.strip(), api_key, num_results)
    except Exception as exc:  # network / credentials dependent
        return [], safe_error(exc)

    if not isinstance(data, dict):
        return [], "request_failed"
    if data.get("error"):
        return [], classify_api_error(data["error"])

    products = []
    for item in (data.get("shopping_results") or [])[:num_results]:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or query)
        price_value, cur, price_text = normalize_price(item)
        old_value, _, _ = normalize_price(
            {"price": item.get("old_price"), "extracted_price": item.get("extracted_old_price")},
            currency_hint=cur,
        )
        products.append(
            {
                "title": title,
                "price": price_text,
                "price_value": price_value,  # always INR (or None)
                "currency": cur,
                "image": safe_url(item.get("thumbnail"), allow_data_image=True),
                "link": safe_url(item.get("product_link") or item.get("link")),
                "source": item.get("source") or "",
                "rating": item.get("rating"),
                # ---- extra real fields (only what SerpApi returns) ----
                "key": product_key(title),
                "reviews_count": item.get("reviews"),
                "old_price": item.get("old_price"),
                "old_price_value": old_value,
                "tag": item.get("tag") or "",  # e.g. "20% OFF" when provided
                "delivery": item.get("delivery") or "",
                "snippet": item.get("snippet") or "",
                "extensions": [str(e) for e in (item.get("extensions") or [])],
                "condition": item.get("second_hand_condition") or "",
                "product_id": item.get("product_id") or "",
                "page_token": item.get("immersive_product_page_token") or "",
                "availability": extract_availability(item),
            }
        )

    if not products:
        return [], "no_results"

    return products, None


# ---------------------------------------------------------------
# Helpers shared by price history / alerts / comparison
# ---------------------------------------------------------------

_STOPWORDS = {"the", "a", "an", "and", "with", "for", "of", "in", "new", "buy", "online"}


def title_tokens(title):
    """Lower-case alphanumeric tokens of a product title (stop-words removed)."""
    words = re.findall(r"[a-z0-9]+", (title or "").lower())
    return [w for w in words if w not in _STOPWORDS]


def product_key(title):
    """
    Stable key used to recognise the SAME / SIMILAR product across
    searches: the sorted unique first 12 meaningful words of the title.
    (Sellers word titles slightly differently, so an exact match is too
    strict; see title_similarity() for the fuzzy comparison.)
    """
    tokens = sorted(set(title_tokens(title)[:12]))
    if not tokens:  # e.g. a title made only of stop-words like "A"
        fallback = re.sub(r"\s+", " ", (title or "").strip().lower())
        return fallback[:60]
    return " ".join(tokens)


def title_similarity(a, b):
    """Jaccard similarity (0..1) between two titles' word sets."""
    ta, tb = set(title_tokens(a)[:12]), set(title_tokens(b)[:12])
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def find_matching_product(products, title, source=None, threshold=0.6):
    """
    Finds the listing in `products` that is the same product as `title`.
    Prefers the same seller; otherwise returns the cheapest similar
    listing. Returns None if nothing is similar enough.
    """
    similar = [
        p for p in products if title_similarity(p.get("title"), title) >= threshold
    ]
    if not similar:
        return None
    if source:
        same_seller = [p for p in similar if (p.get("source") or "") == source]
        if same_seller:
            similar = same_seller
    priced = [p for p in similar if p.get("price_value")]
    return min(priced, key=lambda p: p["price_value"]) if priced else similar[0]


_OUT_PHRASES = ("out of stock", "sold out", "unavailable", "currently unavailable")
_IN_PHRASES = ("in stock", "available", "in-stock")


def extract_availability(obj):
    """
    Returns "in_stock", "out_of_stock" or None (unknown) using ONLY
    explicit availability information present in a SerpApi item.
    Nothing is guessed: if the source doesn't say, the answer is None.
    """
    if not isinstance(obj, dict):
        return None
    flag = obj.get("in_stock")
    if isinstance(flag, bool):
        return "in_stock" if flag else "out_of_stock"

    texts = []
    for field in ("availability", "stock", "tag", "delivery"):
        value = obj.get(field)
        if isinstance(value, str):
            texts.append(value)
    for field in ("extensions", "details_and_offers"):
        value = obj.get(field)
        if isinstance(value, list):
            texts += [str(v) for v in value]

    joined = " | ".join(texts).lower()
    if any(p in joined for p in _OUT_PHRASES):
        return "out_of_stock"
    if any(p in joined for p in _IN_PHRASES):
        return "in_stock"
    return None


# ---------------------------------------------------------------
# Optional detail lookup (sellers + user reviews) for ONE product
# ---------------------------------------------------------------

def _raw_details(page_token, api_key):
    params = {
        "engine": "google_immersive_product",
        "page_token": page_token,
        "api_key": api_key,
        **MARKET_PARAMS,
    }
    response = requests.get(SERPAPI_ENDPOINT, params=params, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    return response.json()


if st is not None:
    _raw_details = st.cache_data(ttl=1800, show_spinner=False)(_raw_details)


def fetch_product_details(page_token):
    """
    Calls SerpApi's Google Immersive Product API for one product (uses
    the `page_token` returned with a shopping result). Returns
    (details, error) where details is:

        {"sellers": [{"seller","price","price_value","rating","link",
                      "availability","shipping"}],
         "reviews": [{"text","rating","source","date"}],
         "features": [str]}

    Every field is whatever the API returned — empty lists mean the
    source had nothing. Never raises.
    """
    api_key = get_serpapi_key()
    if not api_key:
        return None, "no_api_key"
    if not page_token:
        return None, "no_details_token"
    try:
        data = _raw_details(page_token, api_key)
    except Exception as exc:  # network dependent
        return None, safe_error(exc)
    if not isinstance(data, dict):
        return None, "request_failed"
    if data.get("error"):
        return None, classify_api_error(data["error"])
    return parse_product_details(data), None


def parse_product_details(data):
    """Pure parser (separate so it can be unit-tested without network)."""
    data = data if isinstance(data, dict) else {}
    pr = data.get("product_results") if isinstance(data.get("product_results"), dict) else data

    sellers = []
    for s in (pr.get("stores") or []):
        if not isinstance(s, dict):
            continue
        price_text = s.get("price")
        inr_value, _cur, _text = normalize_price(s)
        sellers.append(
            {
                "seller": s.get("name") or "",
                "price": price_text or "",
                "price_value": inr_value,
                "rating": s.get("rating"),
                "link": safe_url(s.get("link")),
                "availability": extract_availability(s),
                "shipping": s.get("shipping") or "",
            }
        )

    reviews = []
    raw_reviews = pr.get("user_reviews") or data.get("user_reviews") or []
    for r in raw_reviews:
        if not isinstance(r, dict):
            continue
        text = r.get("text") or r.get("content") or r.get("snippet") or ""
        title = r.get("title") or ""
        body = (f"{title}. {text}" if title and text else text or title).strip()
        if body:
            reviews.append(
                {
                    "text": body,
                    "rating": r.get("rating"),
                    "source": r.get("source") or "",
                    "date": r.get("date") or "",
                }
            )

    features = [str(f) for f in (pr.get("features") or []) if f]
    if isinstance(pr.get("description"), str) and not features:
        features = [pr["description"]]

    return {"sellers": sellers, "reviews": reviews, "features": features}
