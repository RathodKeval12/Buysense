# BuySense — Dataset-Free Update

## What changed
- **Removed entirely:** `buysense_dataset.csv`, the RandomForest /
  Logistic Regression / KNN training pipeline, `PRODUCT_CATALOG`,
  SHAP explanations, and the "ML Model Used" / "Model Comparison" /
  "Dataset" pages (there's no dataset or trained model left to show).
- **Recommendation page** is now fully personalized + live:
  your profile (interests, preferred categories, budget, brand
  preferences, price sensitivity, minimum rating) builds a search
  query, which is sent straight to **SerpApi Google Shopping**. Every
  product shown — name, price, image, rating, seller, link — is real
  and comes from that live response. Results are then ranked to fit
  your profile (`model.rank_products`).
- **Groq** is still used, but only to write a short natural-language
  explanation of the already-fetched, already-ranked real products —
  it never invents a product, price, or image.
- **Database:** your existing `buysense_history.db` keeps working.
  New columns are added automatically (interests, budget, brand
  preference, price sensitivity, min rating on `users`; query/budget/
  results_count on `history`) the first time you run the updated app.
- **Preserved as-is:** login/signup, password reset, Profile,
  Wishlist, My History (now shows search history), Feedback,
  notifications, theme + language support, PDF/CSV history export,
  and the Chatbot (system prompt updated to no longer reference the
  removed dataset).

## Setup
1. `pip install -r requirements.txt`
2. Set `SERPAPI_API_KEY` (required for real products) and
   `GROQ_API_KEY` (optional, powers the chatbot + AI insight) either
   as environment variables or in `.streamlit/secrets.toml` — copy
   `.streamlit/secrets.toml.example` to get started.
3. `streamlit run app.py`

If `SERPAPI_API_KEY` is missing, the Recommendation page shows a
clear configuration message instead of any product — it never shows
dummy data.


---
# Smart-shopping upgrade (latest)

New pages: Smart Search (voice + image), Gift Ideas, Compare, Budget Optimizer,
Price Tracker, Nearby Stores, Dashboard. Upgraded: Recommendation (natural-language
box + per-product details: price history, sellers, reviews, offers), Wishlist
(categories, notes, price/availability alerts, filters), Chatbot (AI Buying Assistant).

New modules: db_features, pricing, ai_helpers, reviews, nlsearch, gift, multimodal,
stores, assistant, reco_flow, ui_components, product_details, i18n_extra,
page_compare / page_wishlist / page_pricetracker / page_budget / page_gift /
page_smartsearch / page_stores / page_dashboard / page_chatbot.

Database: additive migration on first start (new tables price_history, price_alerts,
availability_alerts, review_summaries, wishlist_notes, product_comparisons,
notifications; new columns on wishlist and history). Existing data is untouched.

Keys: GROQ_API_KEY, SERPAPI_API_KEY (+ existing SMTP settings). See secrets.toml.example.
Run: pip install -r requirements.txt && streamlit run app.py


---
# QA pass (testing, bug fixing)

Run the tests (no pytest needed; pytest also works):
    python -m unittest discover -s tests -v

Fixed: prices were requested from the US Google store (now India: gl=in, google.co.in) and
non-INR prices are converted only with a live rate (currency.py); API keys could leak into
error messages; passwords were unsalted SHA-256 (now salted PBKDF2, old accounts upgrade on
next login); login lockout was bypassable by refreshing (now stored in the DB); anyone could
delete another user's wishlist item; PDF export crashed on "₹"/Hindi/Gujarati; CSV export
allowed spreadsheet formulas; usernames could contain HTML; a new DB connection was opened on
every rerun; NaN/negative prices and stop-word-only titles broke price history; chart labels
showed squares in Hindi/Gujarati.
