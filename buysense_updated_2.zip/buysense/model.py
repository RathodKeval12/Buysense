"""
model.py
--------
Dataset-free personalization logic, plus the shared matplotlib chart
styling (colors matched to the teal / orange / rose theme).

BuySense no longer trains a model on a static CSV. Instead:
  - build_search_query() turns a shopper's profile (interests, budget,
    brand preferences, etc.) into a short Google-Shopping-style query.
  - rank_products() re-orders the *real* products shopping.py returns
    from SerpApi so the best fit for that profile comes first.

No product names, prices, or images are invented here — this module
only decides what to search for and how to order real results.
"""

import io

import matplotlib.pyplot as plt
import streamlit as st

CATEGORY_OPTIONS = [
    "Electronics",
    "Fashion",
    "Home Decor",
    "Books",
    "Fitness",
    "Beauty",
    "Sports",
    "Grocery",
    "Toys",
    "Automotive",
]

# ---------------------------------------------------------------
# Shared chart color palette (teal / orange / rose / purple theme)
# ---------------------------------------------------------------
CHART_PRIMARY = "#7C3AED"    # violet
CHART_ACCENT = "#FB923C"     # orange
CHART_PINK = "#FB7185"       # rose
CHART_PURPLE = "#A78BFA"     # soft purple
CHART_CYCLE = ["#7C3AED", "#FB923C", "#FB7185", "#38BDF8", "#FBBF24", "#34D399"]


def build_search_query(profile):
    """
    Turns a shopper profile dict into a short search query for SerpApi
    Google Shopping.

    profile keys used (all optional):
        product_query          free-text product interest, e.g. "gaming laptop"
        interests               comma-separated interests, e.g. "Gaming, Fitness"
        preferred_categories    comma-separated categories, e.g. "Electronics"
        brand_preference        comma-separated brands, e.g. "Samsung, Nike"
        budget_max               numeric max budget

    Example: {"interests": "Gaming", "budget_max": 50000} with a past
    search of "Gaming laptops" as product_query ->
        "Gaming laptops under ₹50000"
    """
    text = (profile.get("product_query") or "").strip()
    if not text:
        interests = (profile.get("interests") or "").split(",")[0].strip()
        category = (profile.get("preferred_categories") or "").split(",")[0].strip()
        text = interests or category or "trending products"

    brand = (profile.get("brand_preference") or "").split(",")[0].strip()
    if brand and brand.lower() not in text.lower():
        text = f"{brand} {text}"

    budget_max = profile.get("budget_max")
    if budget_max:
        try:
            text = f"{text} under ₹{int(float(budget_max))}"
        except (TypeError, ValueError):
            pass

    return text.strip()


def _score_product(product, profile):
    """Higher score = better fit for this shopper's profile."""
    score = 0.0
    title = (product.get("title") or "").lower()

    # Interest / category keyword match
    keywords = []
    for field in ("interests", "preferred_categories"):
        value = profile.get(field) or ""
        keywords += [k.strip().lower() for k in value.split(",") if k.strip()]
    for kw in keywords:
        if kw and kw in title:
            score += 3

    # Brand preference match
    brands = [b.strip().lower() for b in (profile.get("brand_preference") or "").split(",") if b.strip()]
    for b in brands:
        if b and b in title:
            score += 2

    # Budget match
    price = product.get("price_value")
    budget_max = profile.get("budget_max")
    budget_min = profile.get("budget_min")
    sensitivity = (profile.get("price_sensitivity") or "medium").lower()

    if price is not None:
        if budget_max:
            if price <= budget_max:
                score += 2
                if sensitivity == "high":
                    # Reward cheaper-within-budget options more for
                    # price-sensitive shoppers.
                    score += max(0.0, (budget_max - price) / budget_max) * 2
            else:
                score -= 3
        if budget_min and price < budget_min:
            score -= 1

    # Rating match
    rating = product.get("rating")
    min_rating = profile.get("min_rating") or 0
    if rating:
        score += float(rating)
        if rating < min_rating:
            score -= 2

    return score


def rank_products(products, profile):
    """Returns `products` re-ordered best-fit-first for this shopper profile.
    Never modifies title/price/image/link — only the order changes."""
    return sorted(products, key=lambda p: _score_product(p, profile), reverse=True)


# ---------------------------------------------------------------
# Chart styling helpers (unchanged from the dataset-based version)
# ---------------------------------------------------------------

def styled_fig_theme(fig, ax, theme="dark"):
    """Apply transparent-background chart styling.

    theme="dark"  -> light text/lines for the dark app theme (default)
    theme="light" -> dark text/lines for the light app theme
    """
    is_light = theme == "light"
    spine_color = "#999999" if is_light else "#555555"
    tick_color = "#3A3550" if is_light else "#CCCCCC"
    label_color = "#2A2438" if is_light else "#EEEEEE"
    title_color = "#1B1523" if is_light else "#FFFFFF"

    fig.patch.set_alpha(0)
    ax.set_facecolor("none")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(spine_color)
    ax.spines["bottom"].set_color(spine_color)
    ax.tick_params(colors=tick_color)
    ax.xaxis.label.set_color(label_color)
    ax.yaxis.label.set_color(label_color)
    ax.title.set_color(title_color)


def chart_text_color(theme="dark"):
    """Text color for chart elements not covered by styled_fig_theme (e.g. pie labels)."""
    return "#2A2438" if theme == "light" else "#EEEEEE"


def chart_edge_color(theme="dark"):
    """Wedge/segment edge color that should match the page background."""
    return "#FFFFFF" if theme == "light" else "#1B1C20"


def plot_figure(fig):
    """
    Render a matplotlib figure with a transparent background.

    st.pyplot(fig, transparent=True) is deprecated (savefig kwargs are no
    longer accepted), so we save the figure ourselves and show it with
    st.image() instead. Same look, no deprecation warning.
    """
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", transparent=True, dpi=200, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    try:
        st.image(buf, use_container_width=True)
    except TypeError:  # older Streamlit versions
        st.image(buf, use_column_width=True)
