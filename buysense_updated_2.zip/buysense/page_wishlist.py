"""
page_wishlist.py
----------------
Advanced Wishlist: categories, notes, target-price alert, back-in-stock
alert, current price + change, filtering/sorting, compare-selected and
remove. The original card look (templates.wishlist_card_rich) is kept.

"Current price" is the latest price BuySense actually observed for the
item in a live search (see pricing.evaluate_alerts); it is refreshed by
the "Refresh prices" button or automatically whenever a Recommendation
search returns the same product. If it was never re-observed, the page
says so rather than guessing.
"""

import html

import pandas as pd
import streamlit as st

import db
import db_features as dbf
import pricing
import templates as tpl
import ui_components as ui
from i18n import t


def _fmt(v):
    return f"₹{v:,.0f}" if v is not None and not pd.isna(v) else "—"


def render_notifications(conn, username):
    """In-app notification list (price drops / back in stock)."""
    unread = dbf.get_notifications(conn, username, unread_only=True)
    if not unread:
        return
    tpl.section_title("🔔 " + t("notifications_title", n=len(unread)))
    for _, kind, message, link, created, _ in unread:
        icon = "📉" if kind == "price_drop" else "📦"
        line = f"{icon} {message}  \n<small>{created}</small>"
        if link:
            line += f"  ·  [{t('view_product')}]({link})"
        st.markdown(line, unsafe_allow_html=True)
    if st.button(t("mark_all_read"), key="notif_mark_read"):
        dbf.mark_notifications_read(conn, username)
        st.rerun()


def _apply_filters(df):
    df = df.copy()
    df["Category"] = df["UserCategory"].where(
        df["UserCategory"].notna() & (df["UserCategory"] != ""), df["SavedCategory"]
    )
    df["ChangePct"] = [
        pricing.price_change_pct(s, c) for s, c in zip(df["SavedPriceValue"], df["CurrentPriceValue"])
    ]

    f1, f2, f3 = st.columns([1.2, 1.2, 1])
    with f1:
        cats = sorted({c for c in df["Category"].dropna() if str(c).strip()})
        chosen = st.multiselect(t("filter_category"), cats, key="wl_filter_cat")
    with f2:
        text = st.text_input(t("search_wishlist"), key="wl_filter_text")
    with f3:
        only_alerts = st.checkbox(t("only_with_alerts"), key="wl_filter_alerts")

    if chosen:
        df = df[df["Category"].isin(chosen)]
    if text.strip():
        df = df[df["Item"].str.contains(text.strip(), case=False, na=False)]
    if only_alerts:
        df = df[(df["PriceAlertOn"] == 1) | (df["AvailAlertOn"] == 1)]

    sort_key = st.selectbox(
        t("sort_by"),
        ["newest", "price_low", "price_high", "change", "name"],
        format_func=lambda v: t(f"wl_sort_{v}"),
        key="wl_sort",
    )
    df["_price"] = df["CurrentPriceValue"].fillna(df["SavedPriceValue"])
    if sort_key == "price_low":
        df = df.sort_values("_price", ascending=True, na_position="last")
    elif sort_key == "price_high":
        df = df.sort_values("_price", ascending=False, na_position="last")
    elif sort_key == "change":
        df = df.sort_values("ChangePct", ascending=True, na_position="last")
    elif sort_key == "name":
        df = df.sort_values("Item", key=lambda s: s.str.lower())
    return df


def render(conn, username):
    tpl.hero(t("wishlist_title"), t("wishlist_subtitle"), pill_text="Saved Products")

    if not username:
        st.warning(t("enter_name_view"))
        return

    try:
        wl = dbf.get_wishlist_advanced(conn, username)
    except Exception:
        st.error(t("db_error"))
        return

    flash = st.session_state.pop("wl_flash", None)
    if flash:
        getattr(st, flash[0])(flash[1])

    render_notifications(conn, username)

    if wl.empty:
        st.info(t("wishlist_empty"))
        return

    # ---- top metrics ----
    active_alerts, _ = dbf.count_price_alerts(conn, username)
    cats = wl["UserCategory"].where(wl["UserCategory"].notna() & (wl["UserCategory"] != ""), wl["SavedCategory"])
    c1, c2, c3 = st.columns(3)
    with c1:
        tpl.metric_card(t("total_saved"), f"{len(wl)}")
    with c2:
        tpl.metric_card(t("most_saved_category"), cats.mode().iloc[0] if not cats.dropna().empty else "—")
    with c3:
        tpl.metric_card(t("price_alerts_active"), f"{active_alerts}")

    # ---- check alerts now / refresh prices (explicit = uses SerpApi credits) ----
    b1, b2, _sp = st.columns([1, 1, 2])
    lang = st.session_state.get("lang", "en")
    for col, label, key, only_alerts in (
        (b1, t("check_alerts_now"), "wl_check_alerts", True),
        (b2, t("refresh_prices"), "wl_refresh_prices", False),
    ):
        with col:
            if st.button(label, key=key):
                with st.spinner(t("loading")):
                    events, checked, err = pricing.check_wishlist_now(
                        conn, username, lang, only_alerts=only_alerts)
                if err == "no_api_key":
                    st.error(t("err_no_serpapi_key"))
                elif checked == 0:
                    st.info(t("no_alerts_to_check"))
                else:
                    st.session_state["wl_flash"] = (
                        "warning" if err else "success",
                        t("err_partial_check") if err else t("checked_n_items", n=checked),
                    )
                    for e in events:
                        st.toast("🔔 " + e["message"])
                    st.rerun()

    st.write("")
    df = _apply_filters(wl)
    if df.empty:
        st.info(t("no_wishlist_match"))
        return

    # ---- compare selected ----
    labels = {int(r["ID"]): r["Item"][:60] for _, r in df.iterrows()}
    picked = st.multiselect(
        t("compare_select_wishlist"), list(labels), format_func=lambda i: labels[i], key="wl_cmp_pick"
    )
    if picked:
        if len(picked) > ui.MAX_COMPARE:
            st.warning(t("compare_full", n=ui.MAX_COMPARE))
        elif st.button(t("add_selected_to_compare"), key="wl_cmp_btn"):
            from page_compare import _wishlist_to_product
            for _, r in df[df["ID"].isin(picked)].iterrows():
                ui.add_to_compare(_wishlist_to_product(r))
            st.success(t("compare_added_open"))

    st.write("")
    for _, row in df.iterrows():
        wid = int(row["ID"])
        left, right = st.columns([5, 1])
        with left:
            category = row["Category"] or ""
            if row.get("Image") or row.get("Price"):
                tpl.wishlist_card_rich(
                    html.escape(row["Item"]), html.escape(str(category)), row["Timestamp"],
                    price=html.escape(row.get("Price") or ""), image=html.escape(row.get("Image") or "", quote=True),
                )
                if row.get("Link"):
                    st.markdown(f"[🔗 {t('view_on_shopping')}]({row['Link']})")
            else:
                tpl.wishlist_card(html.escape(row["Item"]), html.escape(str(category)), row["Timestamp"])
        with right:
            if st.button(t("remove"), key=f"wishlist_remove_{wid}"):
                db.remove_from_wishlist(conn, wid, username)
                st.rerun()

        # price line
        saved, current = row["SavedPriceValue"], row["CurrentPriceValue"]
        m1, m2, m3 = st.columns(3)
        with m1:
            tpl.metric_card(t("saved_price"), _fmt(saved))
        with m2:
            tpl.metric_card(t("current_price"), _fmt(current))
        with m3:
            pct = row["ChangePct"]
            if pct is None or pd.isna(pct) or saved is None:
                tpl.metric_card(t("price_change"), "—")
            else:
                arrow = "▲" if pct > 0 else ("▼" if pct < 0 else "■")
                tpl.metric_card(t("price_change"), f"{arrow} {pct:+.1f}%")
        if row.get("PriceCheckedAt"):
            st.caption(t("price_last_seen", when=row["PriceCheckedAt"]))

        with st.expander(t("wishlist_manage")):
            _render_item_form(conn, username, row, wid)

        st.write("")

    if st.button(t("clear_wishlist")):
        db.clear_wishlist(conn, username)
        st.rerun()


def _render_item_form(conn, username, row, wid):
    availability = row.get("Availability")
    with st.form(f"wl_form_{wid}"):
        f1, f2 = st.columns(2)
        with f1:
            category = st.text_input(t("wl_category"), value=row.get("UserCategory") or row.get("SavedCategory") or "")
        with f2:
            default_target = row.get("TargetPrice") or (
                float(row["CurrentPriceValue"]) if row.get("CurrentPriceValue") else
                (float(row["SavedPriceValue"]) if row.get("SavedPriceValue") else 0.0))
            target = st.number_input(t("target_price"), min_value=0.0, value=float(default_target), step=100.0)
        note = st.text_area(t("wl_note"), value=row.get("Note") or "", height=70)
        price_on = st.checkbox(t("price_alert_enable"), value=bool(row.get("PriceAlertOn")))

        # Availability alert: only offered when the SOURCE says out of stock.
        if availability == "out_of_stock":
            avail_on = st.checkbox(t("avail_alert_enable"), value=bool(row.get("AvailAlertOn")))
        elif availability == "in_stock":
            avail_on = bool(row.get("AvailAlertOn"))
            st.caption("✅ " + t("avail_in_stock_no_alert"))
        else:
            avail_on = bool(row.get("AvailAlertOn"))
            st.caption("ℹ️ " + t("avail_not_provided"))
        saved = st.form_submit_button(t("save_changes"))

    if saved:
        try:
            dbf.save_wishlist_note(conn, wid, username, category, note)
            if price_on and target <= 0:
                st.error(t("target_price_required"))
                return
            if price_on or row.get("TargetPrice"):
                effective = target if target > 0 else (row.get("TargetPrice") or 0)
                if not dbf.set_price_alert(conn, username, wid, effective, price_on):
                    st.error(t("target_price_required"))
                    return
            if availability == "out_of_stock" or row.get("AvailAlertOn") is not None:
                dbf.set_availability_alert(conn, username, wid, avail_on, availability)
            st.success(t("changes_saved"))
            st.rerun()
        except Exception:
            st.error(t("db_error"))
