"""
templates.py
------------
Loads the HTML snippets from templates.html (split on
`<!-- TEMPLATE:name -->` markers) and exposes small helper
functions that render them into the Streamlit app.

Keeping the markup in a separate .html file (instead of inline
strings inside the Python code) keeps app.py focused on logic.
"""

import os
import html

import streamlit as st

TEMPLATES_PATH = os.path.join(os.path.dirname(__file__), "templates.html")


def _load_templates():
    """Parse templates.html into a {name: html_string} dict."""
    with open(TEMPLATES_PATH, "r", encoding="utf-8") as f:
        raw = f.read()

    blocks = {}
    current_name = None
    current_lines = []

    for line in raw.splitlines():
        marker = line.strip()
        if marker.startswith("<!-- TEMPLATE:") and marker.endswith("-->"):
            if current_name is not None:
                blocks[current_name] = "\n".join(current_lines).strip()
            current_name = marker.replace("<!-- TEMPLATE:", "").replace("-->", "").strip()
            current_lines = []
        else:
            current_lines.append(line)

    if current_name is not None:
        blocks[current_name] = "\n".join(current_lines).strip()

    return blocks


TEMPLATES = _load_templates()


def load_css(css_path=None):
    """Read style.css and inject it into the page inside a <style> tag."""
    if css_path is None:
        css_path = os.path.join(os.path.dirname(__file__), "style.css")
    with open(css_path, "r", encoding="utf-8") as f:
        css = f.read()
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


# Variable overrides for the light theme. Only values that differ from
# the dark defaults declared in style.css need to be listed here.
LIGHT_THEME_VARS = {
    "--bs-bg": "#F7F5FC",
    "--bs-card": "#FFFFFF",
    "--bs-card-border": "rgba(27, 21, 35, 0.10)",
    "--bs-text": "#1B1523",
    "--bs-text-soft": "#5B5568",
    "--bs-input-bg": "#F1EEF9",
    "--bs-sidebar-bg": "#FFFFFF",
    "--bs-menu-hover": "rgba(124, 58, 237, 0.08)",
}


def apply_theme(theme="dark"):
    """
    Call AFTER load_css(). For "light", injects a small :root override
    that redeclares only the variables that need to change — the CSS
    cascade makes it win over the dark defaults in style.css without
    touching any other rule.
    """
    if theme != "light":
        return
    rules = "\n".join(f"{k}: {v};" for k, v in LIGHT_THEME_VARS.items())
    css = (
        ":root {\n" + rules + "\n}\n"
        "section[data-testid=\"stSidebar\"] { "
        "border-right: 1px solid rgba(27, 21, 35, 0.08); }"
    )
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def esc(value):
    """HTML-escape text before it goes into an unsafe_allow_html template
    (usernames, queries and category names are user-controlled)."""
    return html.escape("" if value is None else str(value), quote=True)


def hero(title, subtitle, pill_text="BuySense"):
    st.markdown(
        TEMPLATES["hero"].format(title=esc(title), subtitle=esc(subtitle), pill_text=esc(pill_text)),
        unsafe_allow_html=True,
    )


def section_title(text):
    st.markdown(
        TEMPLATES["section_title"].format(text=esc(text)),
        unsafe_allow_html=True,
    )


def metric_card(label, value):
    st.markdown(
        TEMPLATES["metric_card"].format(label=esc(label), value=esc(value)),
        unsafe_allow_html=True,
    )


def sidebar_brand():
    st.markdown(TEMPLATES["sidebar_brand"], unsafe_allow_html=True)


def result_banner(prediction):
    st.markdown(
        TEMPLATES["result_banner"].format(prediction=esc(prediction)),
        unsafe_allow_html=True,
    )


def product_card(item, prediction):
    st.markdown(
        TEMPLATES["product_card"].format(item=item, prediction=prediction),
        unsafe_allow_html=True,
    )


def login_wrap_open():
    st.markdown(TEMPLATES["login_wrap_open"], unsafe_allow_html=True)


def login_logo():
    st.markdown(TEMPLATES["login_logo"], unsafe_allow_html=True)


def login_card_open():
    st.markdown(TEMPLATES["login_card_open"], unsafe_allow_html=True)


def div_close():
    st.markdown(TEMPLATES["div_close"], unsafe_allow_html=True)


def about_card(icon, heading, description):
    st.markdown(
        TEMPLATES["about_card"].format(icon=esc(icon), heading=esc(heading), description=esc(description)),
        unsafe_allow_html=True,
    )


def footer_note():
    st.markdown(TEMPLATES["footer_note"], unsafe_allow_html=True)


def wishlist_card(item, category, timestamp):
    st.markdown(
        TEMPLATES["wishlist_card"].format(item=item, category=category, timestamp=timestamp),
        unsafe_allow_html=True,
    )


def live_product_card(title, price, image, source=""):
    """Renders a real SerpApi Google Shopping result: image, title, price, source."""
    st.markdown(
        TEMPLATES["live_product_card"].format(
            title=title,
            price=price or "Price unavailable",
            image=image or "",
            source=source or "",
        ),
        unsafe_allow_html=True,
    )


def wishlist_card_rich(item, category, timestamp, price="", image=""):
    """Like wishlist_card(), but with a product image/price for items saved
    from a live SerpApi result."""
    st.markdown(
        TEMPLATES["wishlist_card_rich"].format(
            item=item,
            category=category,
            timestamp=timestamp,
            price=price or "",
            image=image or "",
        ),
        unsafe_allow_html=True,
    )
