"""
gift.py
-------
AI Gift Recommendation helper. It only builds a SHOPPING QUERY (using
Groq when available, a simple template otherwise). The actual gift ideas
shown to the user are real products fetched through the normal live
SerpApi flow — the model never names or prices a product.
"""

import ai_helpers

OCCASIONS = ["Birthday", "Anniversary", "Graduation", "Festival", "Wedding", "Housewarming", "Thank you"]
RECIPIENTS = ["Partner", "Parent", "Friend", "Child", "Sibling", "Colleague", "Teacher"]


def template_query(occasion, recipient, interests, category, budget):
    """Offline fallback query, built purely from what the user entered."""
    parts = []
    if interests:
        parts.append(interests.split(",")[0].strip())
    if category:
        parts.append(category.lower())
    base = " ".join(p for p in parts if p) or "gift"
    if "gift" not in base.lower():
        base += " gift"
    who = {"Partner": "for her or him", "Parent": "for parents", "Friend": "for friend",
           "Child": "for kids", "Sibling": "for sibling", "Colleague": "for colleague",
           "Teacher": "for teacher"}.get(recipient, "")
    query = f"{base} {who}".strip()
    if budget:
        query += f" under ₹{int(budget)}"
    return query


def build_gift_query(occasion, recipient, interests, category, budget):
    """Returns (query, source) where source is "ai" or "template"."""
    fallback = template_query(occasion, recipient, interests, category, budget)
    if not ai_helpers.has_groq():
        return fallback, "template"
    system = (
        "You write ONE short Google Shopping search query (max 8 words) for a gift. "
        "Output only the query text — no quotes, no explanation, no product price claims."
    )
    user = (
        f"Occasion: {occasion}\nRecipient: {recipient}\nInterests: {interests or 'not specified'}\n"
        f"Preferred category: {category or 'any'}\nBudget (INR): {int(budget) if budget else 'not specified'}\n"
        "Write the query in English and include the budget as 'under ₹<amount>' if given."
    )
    text, error, _ = ai_helpers.chat(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        max_tokens=40, temperature=0.4,
    )
    if error or not text:
        return fallback, "template"
    query = text.strip().strip('"').splitlines()[0][:100].strip()
    return (query or fallback), ("ai" if query else "template")
