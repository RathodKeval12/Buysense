"""
page_compare.py
---------------
Product Comparison page: 2–4 real products side by side.

The page shows OBJECTIVE differences only (price gap, rating gap, which
fields differ). It deliberately never labels a product "best" — the
shopper decides.
"""

import pandas as pd
import streamlit as st

import db_features as dbf
import templates as tpl
import ui_components as ui
from i18n import t


def _avail_label(value):
    return {"in_stock": t("avail_in_stock"), "out_of_stock": t("avail_out_of_stock")}.get(
        value, t("avail_unknown"))


def build_comparison_table(products):
    """Attribute rows x product columns (DataFrame of strings) + diff facts."""
    names = [f"{i + 1}. {(p['title'][:28] + '…') if len(p['title']) > 28 else p['title']}"
             for i, p in enumerate(products)]
    prices = [p.get("price_value") for p in products]
    ratings = [p.get("rating") for p in products]
    priced = [x for x in prices if x is not None]
    rated = [x for x in ratings if x is not None]
    min_price = min(priced) if priced else None
    max_rating = max(rated) if rated else None

    def price_diff(p):
        if p is None or min_price is None:
            return "—"
        if p == min_price:
            return t("lowest_among_selected")
        return f"+₹{p - min_price:,.0f} (+{(p - min_price) / min_price * 100:.0f}%)"

    def rating_diff(r):
        if r is None or max_rating is None:
            return "—"
        if r == max_rating:
            return t("highest_among_selected")
        return f"−{max_rating - r:.1f}"

    def offer(p):
        o, c = p.get("old_price_value"), p.get("price_value")
        if o and c and o > c:
            return f"₹{o:,.0f} → ₹{c:,.0f} (−{(o - c) / o * 100:.0f}%)"
        return p.get("tag") or "—"

    rows = {
        t("price"): [p.get("price") or "—" for p in products],
        t("price_difference"): [price_diff(x) for x in prices],
        t("rating"): [f"{r}" if r is not None else "—" for r in ratings],
        t("rating_difference"): [rating_diff(r) for r in ratings],
        t("reviews_count"): [f"{p['reviews_count']:,}" if isinstance(p.get("reviews_count"), (int, float)) else "—" for p in products],
        t("seller"): [p.get("source") or "—" for p in products],
        t("availability"): [_avail_label(p.get("availability")) for p in products],
        t("offer_label"): [offer(p) for p in products],
        t("delivery"): [p.get("delivery") or "—" for p in products],
        t("condition"): [p.get("condition") or "—" for p in products],
        t("key_attributes"): [
            "; ".join(p.get("extensions") or []) or (p.get("snippet") or "—") for p in products
        ],
    }
    return pd.DataFrame(rows, index=names).T, min_price, max_rating


def _wishlist_to_product(row):
    price_value = row.get("CurrentPriceValue") or row.get("SavedPriceValue")
    return {
        "title": row["Item"], "price": row.get("Price") or "", "price_value": price_value,
        "image": row.get("Image") or "", "link": row.get("Link") or "",
        "source": row.get("Source") or "", "rating": row.get("Rating"),
        "key": row.get("ProductKey") or "",
    }


def render(conn, username):
    tpl.hero(t("compare_title"), t("compare_subtitle"), pill_text=t("compare_pill"))
    basket = ui.get_compare_list()

    # ---- add from wishlist ----
    if username:
        wl = dbf.get_wishlist_advanced(conn, username)
        if not wl.empty:
            with st.expander(t("compare_add_from_wishlist")):
                options = {f"{r['Item'][:60]}": r for _, r in wl.iterrows()}
                picked = st.multiselect(t("compare_pick_wishlist"), list(options), key="cmp_wl_pick")
                if st.button(t("add_selected"), key="cmp_wl_add") and picked:
                    for name in picked:
                        if ui.add_to_compare(_wishlist_to_product(options[name])) == "full":
                            st.warning(t("compare_full", n=ui.MAX_COMPARE))
                            break
                    st.rerun()

    if not basket:
        st.info(t("compare_empty"))
    elif len(basket) < ui.MIN_COMPARE:
        st.info(t("compare_need_two"))

    # ---- product header cards ----
    if basket:
        cols = st.columns(len(basket))
        for i, (col, p) in enumerate(zip(cols, basket)):
            with col:
                if p.get("image"):
                    st.image(p["image"], use_container_width=True)
                st.markdown(f"**{i + 1}. {p['title'][:70]}**")
                st.markdown(f"### {p.get('price') or '—'}")
                if p.get("link"):
                    st.markdown(f"[🔗 {t('view_product')}]({p['link']})")
                if st.button(t("remove"), key=f"cmp_rm_{i}"):
                    ui.remove_from_compare(i)
                    st.rerun()

    # ---- comparison table + objective differences ----
    if len(basket) >= ui.MIN_COMPARE:
        st.write("")
        tpl.section_title(t("compare_table_title"))
        table, min_price, max_rating = build_comparison_table(basket)
        st.dataframe(table, use_container_width=True)

        priced = [p for p in basket if p.get("price_value") is not None]
        rated = [p for p in basket if p.get("rating") is not None]
        c1, c2 = st.columns(2)
        with c1:
            if len(priced) >= 2:
                hi = max(p["price_value"] for p in priced)
                lo = min(p["price_value"] for p in priced)
                tpl.metric_card(t("price_spread"), f"₹{hi - lo:,.0f}")
                st.caption(t("price_spread_note", pct=f"{(hi - lo) / lo * 100:.0f}"))
            else:
                tpl.metric_card(t("price_spread"), "—")
        with c2:
            if len(rated) >= 2:
                spread = max(p["rating"] for p in rated) - min(p["rating"] for p in rated)
                tpl.metric_card(t("rating_spread"), f"{spread:.1f}")
            else:
                tpl.metric_card(t("rating_spread"), "—")
        st.caption(t("compare_objective_note"))

        b1, b2 = st.columns(2)
        with b1:
            if username and st.button(t("save_comparison"), key="cmp_save"):
                try:
                    dbf.save_comparison(
                        conn, username,
                        " vs ".join(p["title"][:25] for p in basket), basket,
                    )
                    st.success(t("comparison_saved"))
                except Exception:
                    st.error(t("db_error"))
        with b2:
            if st.button(t("clear_comparison"), key="cmp_clear"):
                st.session_state["compare_list"] = []
                st.rerun()

    # ---- saved comparisons ----
    if username:
        try:
            saved = dbf.get_saved_comparisons(conn, username)
        except Exception:
            saved = []
        if saved:
            st.write("")
            tpl.section_title(t("saved_comparisons"))
            for cid, title, products, created in saved:
                with st.expander(f"{title}  ·  {created}"):
                    st.caption(t("saved_snapshot_note"))
                    table, _, _ = build_comparison_table(products)
                    st.dataframe(table, use_container_width=True)
                    l1, l2 = st.columns(2)
                    with l1:
                        if st.button(t("load_comparison"), key=f"cmp_load_{cid}"):
                            st.session_state["compare_list"] = products[: ui.MAX_COMPARE]
                            st.rerun()
                    with l2:
                        if st.button(t("remove"), key=f"cmp_del_{cid}"):
                            dbf.delete_comparison(conn, username, cid)
                            st.rerun()
