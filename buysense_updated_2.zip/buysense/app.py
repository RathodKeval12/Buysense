import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
from streamlit_option_menu import option_menu

import db
import db_features as dbf
import exports
import model as ml
import notify
import page_budget
import page_chatbot
import page_compare
import page_dashboard
import page_gift
import page_pricetracker
import page_smartsearch
import page_stores
import page_wishlist
import reco_flow
import templates as tpl
from i18n import LANGUAGES, t

st.set_page_config(
    page_title="BuySense - Intelligent Product Discovery Engine",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="expanded",
)

if "theme" not in st.session_state:
    st.session_state.theme = "dark"
if "lang" not in st.session_state:
    st.session_state.lang = "en"


def _clean_theme(value):
    """Always returns "dark" or "light" (fixes old saved labels like "☀️ Light")."""
    v = str(value or "").strip().lower()
    if v in ("dark", "light"):
        return v
    if any(m in v for m in ("light", "☀", "लाइट", "લાઇટ")):
        return "light"
    return "dark"


def _clean_lang(value):
    """Always returns one of the keys in LANGUAGES (en / hi / gu)."""
    v = str(value or "").strip().lower()
    if v in LANGUAGES:
        return v
    if "ગુજરાતી" in v or "gujarati" in v:
        return "gu"
    if "हिन्दी" in v or "hindi" in v:
        return "hi"
    return "en"


# Safety net: never let a bad theme/lang value crash the app.
# (Defined here in app.py so it works even with an older db.py.)
st.session_state.theme = _clean_theme(st.session_state.theme)
st.session_state.lang = _clean_lang(st.session_state.lang)

# Inject style.css (kept in its own file, see style.css), then apply the
# light-theme variable overrides on top of it if that's the active theme.
tpl.load_css()
tpl.apply_theme(st.session_state.theme)

@st.cache_resource(show_spinner=False)
def _get_connection():
    """One shared SQLite connection per server process. (Previously a new
    connection was opened and never closed on every Streamlit rerun.)"""
    return db.init_db()


db_conn = _get_connection()


def show_login_page():
    lang_col, _spacer = st.columns([1, 3])
    with lang_col:
        chosen_lang = st.selectbox(
            t("language_label"),
            options=list(LANGUAGES.keys()),
            format_func=lambda code: LANGUAGES[code],
            index=list(LANGUAGES.keys()).index(st.session_state.lang),
            key="login_lang_select",
        )
        if chosen_lang != st.session_state.lang:
            st.session_state.lang = chosen_lang
            st.rerun()

    tpl.login_wrap_open()
    tpl.login_logo()
    tpl.login_card_open()

    tab_login, tab_signup, tab_forgot = st.tabs(
        [t("tab_login"), t("tab_signup"), t("tab_forgot")]
    )

    # ---------------- LOGIN ----------------
    with tab_login:
        with st.form("login_form"):
            login_username = st.text_input("Username", key="login_username")
            login_password = st.text_input("Password", type="password", key="login_password")
            login_submitted = st.form_submit_button(t("btn_login"))

        if login_submitted:
            uname = login_username.strip()
            # The lock is stored in the database (per username), so
            # refreshing the page or opening a new tab does not reset it.
            locked_for = db.lock_seconds_remaining(db_conn, "login", uname) if uname else 0
            if not uname or not login_password:
                st.error("Please enter both username and password.")
            elif locked_for:
                st.error(t("login_locked", minutes=max(1, -(-locked_for // 60))))
            elif db.verify_user(db_conn, uname, login_password):
                db.clear_failures(db_conn, "login", uname)
                st.session_state.logged_in = True
                st.session_state.username = uname
                # Restore this user's saved theme / language preferences.
                st.session_state.theme = db.get_theme_pref(db_conn, uname)
                st.session_state.lang = db.get_lang_pref(db_conn, uname)
                st.rerun()
            else:
                left, locked_secs = db.register_failure(db_conn, "login", uname)
                if locked_secs:
                    st.error(t("login_locked", minutes=locked_secs // 60))
                else:
                    st.error(t("login_invalid_left", left=left))

    # ---------------- SIGN UP ----------------
    with tab_signup:
        with st.form("signup_form"):
            signup_username = st.text_input("Choose a Username", key="signup_username")
            signup_email = st.text_input("Email Address", key="signup_email")
            signup_password = st.text_input(
                "Choose a Password", type="password", key="signup_password",
                help="Use 8+ characters, a number, an uppercase letter, and a symbol for a strong password."
            )
            signup_password_confirm = st.text_input(
                "Confirm Password", type="password", key="signup_password_confirm"
            )
            st.markdown("**Security Question** (used to recover your password)")
            signup_question = st.selectbox(
                "Choose a security question", db.SECURITY_QUESTIONS, key="signup_question"
            )
            signup_answer = st.text_input("Your Answer", key="signup_answer")
            signup_terms = st.checkbox(
                "I agree that my data is used only for this project/demo.",
                key="signup_terms",
            )
            signup_submitted = st.form_submit_button(t("btn_create_account"))

        if signup_password:
            label, score = db.password_strength(signup_password)
            st.progress(score / 4)
            st.caption(f"Password strength: **{label}**")

        if signup_submitted:
            label, score = db.password_strength(signup_password)
            if not signup_username.strip() or not signup_password or not signup_email.strip():
                st.error("Please fill in username, email, and password.")
            elif not db.validate_username(signup_username):
                st.error(t("username_invalid"))
            elif "@" not in signup_email or "." not in signup_email:
                st.error("Please enter a valid email address.")
            elif db.validate_new_password(signup_password) == "too_short":
                st.error(t("password_too_short", n=db.MIN_PASSWORD_LENGTH))
            elif db.validate_new_password(signup_password) == "too_weak":
                st.error(t("password_too_weak"))
            elif signup_password != signup_password_confirm:
                st.error("Passwords do not match.")
            elif not signup_answer.strip():
                st.error("Please answer the security question — it's needed to recover your password.")
            elif not signup_terms:
                st.error("Please confirm the checkbox to continue.")
            elif db.create_user(
                db_conn,
                signup_username.strip(),
                signup_password,
                signup_email,
                signup_question,
                signup_answer,
            ):
                st.success("Account created! Please switch to the Login tab to sign in.")
            else:
                st.error("That username is already taken.")

    # ---------------- FORGOT PASSWORD ----------------
    with tab_forgot:
        st.caption(
            "Enter your username, answer your security question correctly, "
            "then set a new password."
        )
        forgot_username = st.text_input("Username", key="forgot_username")

        question = None
        if forgot_username.strip():
            question = db.get_security_question(db_conn, forgot_username.strip())
            if question is None:
                st.warning("No account found with that username.")

        if question:
            with st.form("forgot_password_form"):
                st.markdown(f"**Security Question:** {question}")
                forgot_answer = st.text_input("Your Answer", key="forgot_answer")
                new_password = st.text_input("New Password", type="password", key="new_password")
                new_password_confirm = st.text_input(
                    "Confirm New Password", type="password", key="new_password_confirm"
                )
                reset_submitted = st.form_submit_button(t("btn_reset_password"))

            if reset_submitted:
                f_user = forgot_username.strip()
                locked_for = db.lock_seconds_remaining(db_conn, "reset", f_user)
                if locked_for:
                    st.error(t("login_locked", minutes=max(1, -(-locked_for // 60))))
                elif not forgot_answer.strip() or not new_password:
                    st.error("Please fill in all fields.")
                elif db.validate_new_password(new_password) == "too_short":
                    st.error(t("password_too_short", n=db.MIN_PASSWORD_LENGTH))
                elif db.validate_new_password(new_password) == "too_weak":
                    st.error(t("password_too_weak"))
                elif new_password != new_password_confirm:
                    st.error("Passwords do not match.")
                elif not db.verify_security_answer(db_conn, f_user, forgot_answer):
                    left, locked_secs = db.register_failure(db_conn, "reset", f_user)
                    if locked_secs:
                        st.error(t("login_locked", minutes=locked_secs // 60))
                    else:
                        st.error(t("reset_answer_wrong", left=left))
                else:
                    db.clear_failures(db_conn, "reset", f_user)
                    db.reset_password(db_conn, f_user, new_password)
                    # a reset also clears any login lock on the account
                    db.clear_failures(db_conn, "login", f_user)
                    st.success("Password reset! You can now log in from the Login tab.")

    tpl.div_close()
    tpl.div_close()


if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "username" not in st.session_state:
    st.session_state.username = ""

if not st.session_state.logged_in:
    show_login_page()
    st.stop()

with st.sidebar:
    tpl.sidebar_brand()

    st.markdown(t("logged_in_as", username=st.session_state.username))
    _last_login = db.get_last_login(db_conn, st.session_state.username)
    if _last_login:
        st.caption(t("last_login", value=_last_login))
    _wishlist_count = db.get_wishlist_count(db_conn, st.session_state.username.strip())
    st.caption(t("wishlist_badge", count=_wishlist_count))
    try:
        _unread = dbf.count_unread_notifications(db_conn, st.session_state.username.strip())
    except Exception:
        _unread = 0
    if _unread:
        st.caption(t("notif_badge", count=_unread))
    if st.button(t("logout")):
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.rerun()

    st.write("")

    # ---------------- Theme + Language controls ----------------
    ctrl_col1, ctrl_col2 = st.columns(2)
    with ctrl_col1:
        theme_choice = st.selectbox(
            t("theme_label"),
            options=["dark", "light"],
            format_func=lambda v: t("theme_dark") if v == "dark" else t("theme_light"),
            index=["dark", "light"].index(st.session_state.theme),
            key="theme_select",
        )
    with ctrl_col2:
        lang_choice = st.selectbox(
            t("language_label"),
            options=list(LANGUAGES.keys()),
            format_func=lambda code: LANGUAGES[code],
            index=list(LANGUAGES.keys()).index(st.session_state.lang),
            key="lang_select",
        )

    if theme_choice != st.session_state.theme or lang_choice != st.session_state.lang:
        st.session_state.theme = theme_choice
        st.session_state.lang = lang_choice
        db.set_theme_pref(db_conn, st.session_state.username, theme_choice)
        db.set_lang_pref(db_conn, st.session_state.username, lang_choice)
        st.rerun()

    st.write("")

    # Canonical (English) menu keys used for all `menu == "..."` checks
    # further down, kept stable regardless of the active display language.
    # ML Model Used / Model Comparison / Dataset are gone along with the
    # dataset itself — everything else is preserved.
    NAV_KEYS = [
        ("Home", "nav_home", "house"),
        ("Recommendation", "nav_recommendation", "stars"),
        ("Smart Search", "nav_smart_search", "mic"),
        ("Gift Ideas", "nav_gift", "gift"),
        ("Compare", "nav_compare", "columns-gap"),
        ("Budget Optimizer", "nav_budget", "piggy-bank"),
        ("Price Tracker", "nav_tracker", "graph-down-arrow"),
        ("Nearby Stores", "nav_stores", "geo-alt"),
        ("Dashboard", "nav_dashboard", "speedometer2"),
        ("My History", "nav_history", "clock-history"),
        ("Wishlist", "nav_wishlist", "heart"),
        ("Feedback", "nav_feedback", "chat-square-heart"),
        ("Chatbot", "nav_chatbot", "chat-dots"),
        ("Profile", "nav_profile", "person-circle"),
        ("About", "nav_about", "info-circle"),
    ]
    nav_labels = [t(key) for _, key, _ in NAV_KEYS]
    nav_icons = [icon for _, _, icon in NAV_KEYS]
    label_to_canonical = {t(key): canonical for canonical, key, _ in NAV_KEYS}

    selected_label = option_menu(
        menu_title=None,
        options=nav_labels,
        icons=nav_icons,
        menu_icon="grid",
        default_index=0,
        styles={
            "container": {"padding": "0", "background-color": "transparent"},
            "icon": {"color": ml.CHART_PRIMARY, "font-size": "16px"},
            "nav-link": {
                "font-size": "14.5px",
                "font-weight": "500",
                "text-align": "left",
                "margin": "4px 0",
                "border-radius": "10px",
                "color": "var(--bs-text-soft)",
                "--hover-color": "var(--bs-menu-hover)",
            },
            "nav-link-selected": {
                "background": f"linear-gradient(90deg, {ml.CHART_PRIMARY}, {ml.CHART_ACCENT})",
                "color": "#ffffff",
                "font-weight": "600",
            },
        },
    )
    menu = label_to_canonical.get(selected_label, "Home")


if menu == "Home":
    tpl.hero(t("home_title"), t("home_subtitle"))

    stats = db.get_platform_stats(db_conn)
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        tpl.metric_card("Total Users", f"{stats['total_users']:,}")
    with c2:
        tpl.metric_card("Searches Run", f"{stats['total_searches']:,}")
    with c3:
        tpl.metric_card("Wishlist Saves", f"{stats['total_wishlist']:,}")
    with c4:
        tpl.metric_card("Top Category", stats["top_category"] or "—")

    st.write("")
    left, right = st.columns([1.1, 1])

    with left:
        tpl.section_title("How BuySense Works")
        st.markdown(
            """
            <div class="bs-card">
                <div class="bs-step">
                    <div class="bs-step-num">1</div>
                    <div class="bs-step-text">Learns your interests, budget, brand preferences, and rating expectations from your profile.</div>
                </div>
                <div class="bs-step">
                    <div class="bs-step-num">2</div>
                    <div class="bs-step-text">Builds a personalized search query and sends it to Google Shopping (via SerpApi) in real time.</div>
                </div>
                <div class="bs-step">
                    <div class="bs-step-num">3</div>
                    <div class="bs-step-text">Ranks the real results by how well they fit you — price, rating, brand, and interests — no static catalog involved.</div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with right:
        tpl.section_title("Category Mix (All Searches)")
        category_counts = db.get_category_distribution(db_conn)
        if category_counts.empty:
            st.info("No searches yet — run a Recommendation to see the category mix here.")
        else:
            fig, ax = plt.subplots(figsize=(6, 4.2))
            colors = [ml.CHART_CYCLE[i % len(ml.CHART_CYCLE)] for i in range(len(category_counts))]
            ax.pie(
                category_counts.values,
                labels=category_counts.index,
                autopct="%1.0f%%",
                colors=colors,
                textprops={"color": ml.chart_text_color(st.session_state.theme), "fontsize": 9},
                wedgeprops={"edgecolor": ml.chart_edge_color(st.session_state.theme), "linewidth": 1.5},
            )
            fig.patch.set_alpha(0)
            ml.plot_figure(fig)

    tpl.footer_note()


elif menu == "Recommendation":
    tpl.hero(
        t("reco_title"),
        t("reco_subtitle"),
        pill_text="Live Google Shopping",
    )

    username = st.session_state.username.strip()
    saved_profile = db.get_profile(db_conn, username) if username else {}

    # ---- Natural-language search (new) — the manual form below is unchanged ----
    tpl.section_title("🗣️ " + t("nl_search_title"))
    with st.form("nl_form"):
        nl_text = st.text_input(t("nl_search_label"), placeholder=t("nl_placeholder"))
        nl_submitted = st.form_submit_button(t("nl_search_btn"))
    if nl_submitted:
        reco_flow.run_natural_language(db_conn, username, nl_text, saved_profile)
    st.caption(t("nl_or_manual"))

    tpl.section_title("Your Shopping Profile")
    with st.form("recommendation_form"):
        product_query = st.text_input(
            "What are you shopping for? (optional — e.g. \"gaming laptop\")",
            value=st.session_state.get("last_product_query", ""),
        )

        col1, col2 = st.columns(2)
        with col1:
            interests = st.text_input(
                "Interests (comma-separated)",
                value=saved_profile.get("interests", ""),
                placeholder="Gaming, Fitness, Fashion",
            )
            default_categories = [
                c.strip() for c in (saved_profile.get("preferred_categories") or "").split(",")
                if c.strip() in ml.CATEGORY_OPTIONS
            ]
            preferred_categories = st.multiselect(
                "Preferred Categories",
                options=ml.CATEGORY_OPTIONS,
                default=default_categories,
            )
            brand_preference = st.text_input(
                "Preferred Brands (comma-separated, optional)",
                value=saved_profile.get("brand_preference", ""),
                placeholder="Samsung, Nike",
            )

        with col2:
            budget_max = st.number_input(
                "Budget (max, ₹)",
                min_value=0.0,
                value=float(saved_profile.get("budget_max") or 5000.0),
                step=500.0,
            )
            price_sensitivity_options = ["low", "medium", "high"]
            saved_sensitivity = saved_profile.get("price_sensitivity") or "medium"
            if saved_sensitivity not in price_sensitivity_options:
                saved_sensitivity = "medium"
            price_sensitivity = st.selectbox(
                "Price Sensitivity",
                options=price_sensitivity_options,
                index=price_sensitivity_options.index(saved_sensitivity),
                format_func=lambda v: v.capitalize(),
            )
            min_rating = st.slider(
                "Minimum Rating Preference",
                0.0, 5.0,
                float(saved_profile.get("min_rating") or 0.0),
                step=0.5,
            )

        submitted = st.form_submit_button(t("btn_get_recommendation"))

    if submitted:
        profile = {
            "product_query": product_query.strip(),
            "interests": interests.strip(),
            "preferred_categories": ", ".join(preferred_categories),
            "budget_min": None,
            "budget_max": budget_max if budget_max > 0 else None,
            "brand_preference": brand_preference.strip(),
            "price_sensitivity": price_sensitivity,
            "min_rating": min_rating,
        }
        st.session_state["last_product_query"] = product_query.strip()

        if username:
            db.set_profile(
                db_conn,
                username,
                profile["interests"],
                profile["preferred_categories"],
                profile["budget_min"],
                profile["budget_max"],
                profile["brand_preference"],
                profile["price_sensitivity"],
                profile["min_rating"],
            )

        # Live search + ranking + history + price tracking + alerts live in
        # reco_flow.py so the Natural-Language, Voice, Image and Gift
        # features can share exactly the same pipeline.
        reco_flow.run_recommendation(db_conn, username, profile)

    # Results persist in session_state, so "Add to wishlist / compare"
    # clicks don't make them disappear.
    reco_flow.render_results(db_conn, username)


elif menu == "My History":
    tpl.hero(
        t("history_title"),
        t("history_subtitle"),
        pill_text="SQLite Powered",
    )

    if not st.session_state.username.strip():
        st.warning(t("enter_name_view"))
    else:
        username = st.session_state.username.strip()
        history_df = db.get_search_history(db_conn, username)

        if history_df.empty:
            st.info(t("no_history_yet"))
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                tpl.metric_card("Total Searches", f"{len(history_df)}")
            with c2:
                mode_cat = history_df["Category"].mode()
                tpl.metric_card("Most Searched Category", mode_cat.iloc[0] if not mode_cat.empty else "—")
            with c3:
                avg_results = history_df["Results Found"].dropna()
                tpl.metric_card(
                    "Avg Results Found",
                    f"{avg_results.mean():.1f}" if not avg_results.empty else "—",
                )

            st.write("")
            tpl.section_title(f"History for {username}")
            st.dataframe(history_df, use_container_width=True, hide_index=True)

            dl_col1, dl_col2, dl_col3 = st.columns(3)
            with dl_col1:
                st.download_button(
                    t("download_csv"),
                    data=exports.csv_bytes(history_df),
                    file_name=f"buysense_history_{username}.csv",
                    mime="text/csv",
                )
            with dl_col2:
                try:
                    pdf_bytes = exports.generate_history_pdf(history_df, username)
                    st.download_button(
                        t("download_pdf"),
                        data=pdf_bytes,
                        file_name=f"buysense_history_{username}.pdf",
                        mime="application/pdf",
                    )
                except ImportError:
                    st.caption("Install `fpdf2` (see requirements.txt) to enable PDF export.")
                except Exception:
                    st.caption(t("export_pdf_failed"))
            with dl_col3:
                if st.button(t("clear_history")):
                    db.clear_search_history(db_conn, username)
                    st.rerun()


elif menu == "Wishlist":
    page_wishlist.render(db_conn, st.session_state.username.strip())


elif menu == "Profile":
    tpl.hero(
        t("profile_title"),
        t("profile_subtitle"),
        pill_text="Account Settings",
    )

    username = st.session_state.username.strip()
    tpl.section_title(username or "—")

    user_email = db.get_user_email(db_conn, username) or ""
    c1, c2 = st.columns(2)
    with c1:
        tpl.metric_card("Username", username)
    with c2:
        tpl.metric_card("Email", user_email if user_email else "—")

    st.write("")
    tpl.section_title("Notifications")
    current_pref = db.get_email_notify_pref(db_conn, username)
    new_pref = st.checkbox(t("email_notify_label"), value=current_pref, key="email_notify_checkbox")
    if new_pref != current_pref:
        db.set_email_notify_pref(db_conn, username, new_pref)
        st.success(t("email_notify_saved"))

    if new_pref and notify.get_smtp_config() is None:
        st.caption(f"ℹ️ {t('email_not_configured')}")

    st.write("")
    tpl.section_title("Shopping Preferences")
    profile = db.get_profile(db_conn, username)
    if profile and (profile.get("interests") or profile.get("preferred_categories")):
        st.caption(
            f"Interests: {profile.get('interests') or '—'} · "
            f"Categories: {profile.get('preferred_categories') or '—'} · "
            f"Budget: ₹{profile.get('budget_max') or '—'} · "
            f"Brands: {profile.get('brand_preference') or '—'}"
        )
    else:
        st.caption("No shopping preferences saved yet — set them on the Recommendation page.")


elif menu == "Feedback":
    tpl.hero(
        t("feedback_title"),
        t("feedback_subtitle"),
        pill_text="We're Listening",
    )

    username = st.session_state.username.strip()

    tpl.section_title("Rate Your Experience")
    with st.form("feedback_form"):
        rating = st.slider("How would you rate BuySense?", 1, 5, 5, format="%d ⭐")
        comment = st.text_area(
            "Your Feedback",
            placeholder="What did you like? What can be improved?",
            height=120,
        )
        feedback_submitted = st.form_submit_button(t("btn_submit_feedback"))

    if feedback_submitted:
        if not comment.strip():
            st.error("Please write a short comment before submitting.")
        else:
            db.save_feedback(db_conn, username, rating, comment)
            st.success("🙏 Thank you! Your feedback has been recorded.")

    st.write("")
    tpl.section_title("Your Past Feedback")
    my_feedback_df = db.get_user_feedback(db_conn, username)
    if my_feedback_df.empty:
        st.info("You haven't submitted any feedback yet.")
    else:
        avg_rating = my_feedback_df["Rating"].mean()
        c1, c2 = st.columns(2)
        with c1:
            tpl.metric_card("Feedback Submitted", f"{len(my_feedback_df)}")
        with c2:
            tpl.metric_card("Your Average Rating", f"{avg_rating:.1f} ⭐")
        st.write("")
        st.dataframe(my_feedback_df, use_container_width=True, hide_index=True)

    st.write("")
    tpl.section_title("Overall App Rating (All Users)")
    all_feedback_df = db.get_all_feedback(db_conn)
    if all_feedback_df.empty:
        st.info("No feedback submitted yet — be the first!")
    else:
        c1, c2 = st.columns(2)
        with c1:
            tpl.metric_card("Total Feedback Entries", f"{len(all_feedback_df)}")
        with c2:
            tpl.metric_card("Overall Average Rating", f"{all_feedback_df['Rating'].mean():.1f} ⭐")

        fig, ax = plt.subplots(figsize=(7, 4))
        ml.styled_fig_theme(fig, ax, theme=st.session_state.theme)
        rating_counts = all_feedback_df["Rating"].value_counts().sort_index()
        ax.bar(rating_counts.index.astype(str) + " ⭐", rating_counts.values, color=ml.CHART_ACCENT)
        ax.set_title("Rating Distribution")
        ax.set_xlabel("Rating")
        ax.set_ylabel("Number of Users")
        ml.plot_figure(fig)


elif menu == "About":
    tpl.hero(
        t("about_title"),
        t("about_subtitle"),
        pill_text="Project Info",
    )

    c1, c2, c3 = st.columns(3)
    with c1:
        tpl.about_card(
            "🛒",
            "Live Product Data",
            "Every product shown comes straight from Google Shopping via SerpApi "
            "in real time — real names, prices, images, ratings, sellers, and "
            "links. Nothing is hardcoded or simulated.",
        )
    with c2:
        tpl.about_card(
            "🎯",
            "Personalized Ranking",
            "Your interests, budget, brand preferences, and minimum rating "
            "shape which real products are shown and in what order — no "
            "static dataset involved.",
        )
    with c3:
        tpl.about_card(
            "🧭",
            "Interactive Sections",
            "Home, Recommendation, History, Wishlist, Feedback, and an AI "
            "chatbot — all in one place.",
        )

    tpl.footer_note()


elif menu == "Chatbot":
    page_chatbot.render(db_conn, st.session_state.username.strip())


# ---- New pages ----
elif menu == "Smart Search":
    page_smartsearch.render(db_conn, st.session_state.username.strip())

elif menu == "Gift Ideas":
    page_gift.render(db_conn, st.session_state.username.strip())

elif menu == "Compare":
    page_compare.render(db_conn, st.session_state.username.strip())

elif menu == "Budget Optimizer":
    page_budget.render(db_conn, st.session_state.username.strip())

elif menu == "Price Tracker":
    page_pricetracker.render(db_conn, st.session_state.username.strip())

elif menu == "Nearby Stores":
    page_stores.render(db_conn, st.session_state.username.strip())

elif menu == "Dashboard":
    page_dashboard.render(db_conn, st.session_state.username.strip())
