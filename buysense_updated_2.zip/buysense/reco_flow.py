"""
reco_flow.py
------------
The shared "run a live recommendation and show it" flow used by the
Recommendation page (manual form AND natural-language box), Voice
search, Image search and Gift ideas.

Results are kept in st.session_state so clicking "Add to wishlist" or
"Add to compare" on a card doesn't make the results disappear.
Every product shown is a real SerpApi Google Shopping result; this
module only orders and presents them.
"""

import matplotlib.pyplot as plt
import streamlit as st

import ai_helpers
import db
import db_features as dbf
import model as ml
import nlsearch
import notify
import personalize
import pricing
import shopping
import templates as tpl
import ui_components as ui
from i18n import t

RESULT_KEY = "reco_results"


def category_label_for(profile):
    cats = [c.strip() for c in (profile.get("preferred_categories") or "").split(",") if c.strip()]
    if cats:
        return cats[0]
    interests = (profile.get("interests") or "").split(",")[0].strip()
    return interests or "General"


def run_recommendation(conn, username, profile, category_label=None, result_key=RESULT_KEY,
                       query_override=None):
    """
    Searches Google Shopping (via SerpApi), ranks the real results for
    `profile`, logs the search, records prices, evaluates the user's
    alerts and stores everything in session_state[result_key].
    Returns True if products were found.
    """
    st.session_state.pop(result_key, None)
    query = query_override or ml.build_search_query(profile)
    if not shopping.get_serpapi_key():
        st.error(t("err_no_serpapi_key"))
        return False

    with st.spinner(t("searching_for", query=query)):
        products, shopping_error = shopping.search_products(query, num_results=12)

    if not products:
        if shopping_error == "no_results":
            st.info(t("no_products_found"))
        else:
            st.error(t(shopping.error_i18n_key(shopping_error)))
        return False

    ranked = ml.rank_products(products, profile)[:9]
    category_label = category_label or category_label_for(profile)
    notes = []

    # Price history: every real price seen in this search is recorded.
    dbf.record_prices_for_products(conn, products, username or None)

    if username:
        priced = [p["price_value"] for p in ranked if p.get("price_value")]
        avg_price = sum(priced) / len(priced) if priced else None
        try:
            db.save_search(
                conn, username, query, str(profile.get("budget_max") or ""),
                category_label, len(ranked), avg_price,
            )
            notes.append(t("saved_to_history", username=username))
        except Exception:
            notes.append(t("db_error"))

        if db.get_email_notify_pref(conn, username):
            sent, info = notify.send_recommendation_email(
                db.get_user_email(conn, username), username, query, ranked
            )
            if sent:
                notes.append(t("email_sent"))
            elif info == "smtp_not_configured":
                notes.append("ℹ️ " + t("email_not_configured"))

        # Price-drop / back-in-stock alerts get checked for free against
        # these live results (no extra API call).
        for event in pricing.evaluate_alerts(conn, username, products, st.session_state.get("lang", "en")):
            st.toast("🔔 " + event["message"])
    else:
        notes.append(t("enter_name_history"))

    st.session_state[result_key] = {
        "query": query, "products": ranked, "all_products": products,
        "profile": profile, "category": category_label, "notes": notes,
    }
    return True


def render_results(conn, username, result_key=RESULT_KEY, ctx="reco"):
    """Draws the stored results (cards, price chart, AI insight)."""
    data = st.session_state.get(result_key)
    if not data:
        return
    ranked, profile, query = data["products"], data["profile"], data["query"]

    tpl.result_banner(query)
    for note in data.get("notes", []):
        st.caption(note)

    left, right = st.columns([1, 1.1])
    with left:
        tpl.section_title(t("live_products_title"))
        for idx, product in enumerate(ranked):
            ui.render_product(
                conn, username, product, ctx, idx,
                category_label=data["category"], all_products=data["all_products"],
            )

    with right:
        tpl.section_title(t("price_comparison_title"))
        priced = [p for p in ranked if p.get("price_value")]
        if priced:
            fig, ax = plt.subplots(figsize=(7, 4.2))
            ml.styled_fig_theme(fig, ax, theme=st.session_state.theme)
            labels = [(p["title"][:18] + "…") if len(p["title"]) > 18 else p["title"] for p in priced]
            bars = ax.bar(labels, [p["price_value"] for p in priced], color=ml.CHART_PRIMARY)
            if len(bars) > 0:
                bars[0].set_color(ml.CHART_ACCENT)
            ax.set_title("Price by Product")
            ax.set_ylabel("Price (₹)")
            ax.tick_params(axis="x", rotation=40)
            ml.plot_figure(fig)
        else:
            st.info(t("price_unavailable_all"))

    # AI personalization layer (explains already-fetched real products only)
    tpl.section_title("🤖 " + t("insight_title"))
    with st.spinner(t("insight_loading")):
        insight_text, insight_error = personalize.get_personalized_insight(profile, query, ranked[:5])
    if insight_text:
        st.markdown(
            '<div class="bs-card" style="border-left:4px solid var(--bs-pink);">'
            f"<p>💡 {insight_text}</p></div>",
            unsafe_allow_html=True,
        )
    elif insight_error == "no_api_key":
        st.caption("ℹ️ " + t("insight_no_key"))
    elif insight_error:
        st.caption("ℹ️ " + t(ai_helpers.error_key(ai_helpers.friendly_error(insight_error))))


# ---------------------------------------------------------------
# Natural-language box (used on Recommendation + Voice search)
# ---------------------------------------------------------------

def understood_summary(params):
    """Human-readable chips of how a request was interpreted."""
    parts = []
    if params.get("product"):
        parts.append(f"🔎 {params['product']}")
    if params.get("brand"):
        parts.append(f"🏷️ {params['brand']}")
    if params.get("budget_min") and params.get("budget_max"):
        parts.append(f"💰 ₹{params['budget_min']:,.0f}–₹{params['budget_max']:,.0f}")
    elif params.get("budget_max"):
        parts.append(f"💰 ≤ ₹{params['budget_max']:,.0f}")
    elif params.get("budget_min"):
        parts.append(f"💰 ≥ ₹{params['budget_min']:,.0f}")
    if params.get("min_rating") is not None:
        parts.append(f"⭐ ≥ {params['min_rating']}")
    if params.get("interests"):
        parts.append(f"❤️ {params['interests']}")
    for c in params.get("constraints") or []:
        parts.append(f"✔️ {c}")
    return "  ·  ".join(parts)


def run_natural_language(conn, username, text, base_profile, result_key=RESULT_KEY):
    """Parses `text`, shows how it was understood, and runs the search."""
    text = (text or "").strip()
    if not text:
        st.warning(t("nl_empty"))
        return False
    params, ai_error = nlsearch.parse_query(text, st.session_state.get("lang", "en"))
    st.caption(t("nl_understood") + " " + understood_summary(params))
    if ai_error == "no_api_key":
        st.caption("ℹ️ " + t("nl_rules_only"))
    # Only the shopper's *taste* settings carry over. Budget, brand and
    # rating come from what they just asked for, so a stale saved budget
    # can't silently change the search.
    taste = {k: (base_profile or {}).get(k) for k in ("interests", "preferred_categories", "price_sensitivity")}
    profile = nlsearch.params_to_profile(params, taste)
    if not profile.get("product_query"):
        st.warning(t("nl_no_product"))
        return False
    return run_recommendation(conn, username, profile, result_key=result_key)
