"""
page_smartsearch.py
-------------------
Voice search and Image search. Both end by running the normal live
recommendation flow on a TEXT query.

Privacy: recorded audio and uploaded images are processed in memory and
never saved to disk or the database.
"""

import hashlib

import streamlit as st

import ai_helpers
import multimodal
import reco_flow
import templates as tpl
from i18n import t


def render(conn, username):
    tpl.hero(t("smart_title"), t("smart_subtitle"), pill_text=t("smart_pill"))
    tab_voice, tab_image = st.tabs(["🎤 " + t("tab_voice"), "📷 " + t("tab_image")])
    with tab_voice:
        _voice_tab(conn, username)
    with tab_image:
        _image_tab(conn, username)


# ---------------------------- voice ----------------------------

def _voice_tab(conn, username):
    st.caption(t("voice_hint"))
    if not multimodal.audio_input_supported():
        st.info(t("voice_unsupported"))
    elif not ai_helpers.has_groq():
        st.info(t("err_no_groq_key"))
    else:
        audio = st.audio_input(t("voice_record"), key="voice_audio")
        if audio is not None:
            audio_bytes = audio.getvalue()
            digest = hashlib.sha256(audio_bytes).hexdigest()
            if st.session_state.get("voice_digest") != digest:  # transcribe each recording once
                with st.spinner(t("voice_transcribing")):
                    text, error = multimodal.transcribe_audio(audio_bytes)
                st.session_state["voice_digest"] = digest
                if error:
                    st.session_state["voice_text"] = ""
                    st.session_state["voice_error"] = error
                else:
                    st.session_state["voice_text"] = text
                    st.session_state["voice_error"] = None
                    st.session_state["voice_query_box"] = text
            err = st.session_state.get("voice_error")
            if err == "empty_audio":
                st.warning(t("voice_empty"))
            elif err:
                st.error(t(ai_helpers.error_key(err)))

    # Typed fallback / editable transcript (mic blocked, unsupported browser, mis-heard words)
    text = st.text_input(t("voice_query_label"), key="voice_query_box",
                         placeholder="Show me wireless headphones under 3000 rupees")
    if st.button(t("voice_search_btn"), key="voice_go"):
        reco_flow.run_natural_language(
            conn, username, text, {}, result_key="voice_results")
    reco_flow.render_results(conn, username, result_key="voice_results", ctx="voice")


# ---------------------------- image ----------------------------

def _image_tab(conn, username):
    st.caption(t("image_hint"))
    if not ai_helpers.has_groq():
        st.info(t("err_no_groq_key"))
        return
    upload = st.file_uploader(t("image_upload"), type=["jpg", "jpeg", "png", "webp"], key="img_upload")
    if upload is None:
        return
    image_bytes = upload.getvalue()
    mime = upload.type or "image/jpeg"
    st.image(image_bytes, width=260)

    digest = hashlib.sha256(image_bytes).hexdigest()
    if st.button(t("image_analyze_btn"), key="img_analyze"):
        with st.spinner(t("image_analyzing")):
            result, error = multimodal.analyze_product_image(image_bytes, mime)
        st.session_state["img_analysis"] = {"digest": digest, "result": result, "error": error}
        if result and result.get("search_query"):
            st.session_state["img_query_box"] = result["search_query"]

    analysis = st.session_state.get("img_analysis")
    if not analysis or analysis["digest"] != digest:
        return
    result, error = analysis["result"], analysis["error"]

    if error in ("unsupported_image", "image_too_large", "no_api_key", "rate_limited",
                 "timeout", "network", "bad_key", "api_error"):
        st.error(t({"unsupported_image": "err_unsupported_image",
                    "image_too_large": "err_image_too_large"}.get(error, ai_helpers.error_key(error))))
        return
    if error == "not_a_product":
        st.warning(t("image_not_product"))
        return

    st.markdown(f"**{t('image_category')}:** {result['category'] or '—'}")
    st.markdown(f"**{t('image_brand')}:** {result['brand'] or t('image_brand_unknown')}")
    if result["characteristics"]:
        st.markdown(f"**{t('image_characteristics')}:** " + ", ".join(result["characteristics"]))
    st.caption(t("image_confidence", level=t(f"conf_{result['confidence']}") if result["confidence"] in ("low", "medium", "high") else result["confidence"]))
    st.info(t("image_disclaimer"))
    if result["confidence"] == "low":
        st.warning(t("image_low_confidence"))

    query = st.text_input(t("image_query_label"), key="img_query_box")
    if st.button(t("image_search_btn"), key="img_go") and query.strip():
        reco_flow.run_recommendation(
            conn, username, {"product_query": query.strip(), "price_sensitivity": "medium", "min_rating": 0},
            category_label=result["category"] or "General", result_key="image_results",
            query_override=query.strip(),
        )
    reco_flow.render_results(conn, username, result_key="image_results", ctx="image")
