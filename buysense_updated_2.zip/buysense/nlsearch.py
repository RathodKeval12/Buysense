"""
nlsearch.py
-----------
Natural-language shopping requests -> structured search parameters.

    "I want a Samsung phone under ₹25,000 with at least 4.3 rating"
        -> {product: "Samsung phone", budget_max: 25000,
            brand: "Samsung", min_rating: 4.3, ...}

Two layers:
  1. rule_parse()  — regular expressions; offline, free, deterministic.
     Extracts numbers (budget / rating) and known brands reliably.
  2. ai_parse()    — Groq turns free text into JSON (product phrase,
     interests, extra constraints), which also copes with Hindi/Gujarati.
     Numbers found by the rules always win over the model's numbers.

If Groq isn't configured (or fails), the rule layer alone is used, so
this feature never blocks the Recommendation page. The result is only
ever used to build a SerpApi query and rank REAL results — it does not
create any product data.
"""

import re

import ai_helpers

KNOWN_BRANDS = [
    "Samsung", "Apple", "Xiaomi", "Redmi", "Realme", "OnePlus", "Oppo", "Vivo",
    "iQOO", "Poco", "Motorola", "Nokia", "Nothing", "Google", "Sony", "LG", "HP",
    "Dell", "Lenovo", "Asus", "Acer", "MSI", "Boat", "JBL", "Bose", "Sennheiser",
    "Noise", "Nike", "Adidas", "Puma", "Reebok", "Skechers", "Canon", "Nikon",
    "Whirlpool", "Philips", "Panasonic", "Bosch", "Prestige", "Levi's", "Titan",
    "Fossil", "Casio", "Amazfit", "Fitbit", "Garmin",
]

_FILLER_PREFIX = re.compile(
    r"^\s*(?:hi[, ]+|hello[, ]+)?(?:please\s+)?(?:i\s+(?:want|need|am looking for|'m looking for)|"
    r"(?:can you |could you )?(?:find|show|get|search for|suggest|recommend)(?: me)?|"
    r"looking for|show me|give me|i would like|i'd like)\s*(?:to buy\s*)?(?:a|an|some|the)?\s*",
    re.IGNORECASE,
)

_NUM = r"(\d[\d,]*(?:\.\d+)?)"
_UNIT = r"\s*(k|thousand|lakh|lakhs|lac|lacs|rupees|rupee|rs|inr)?"
_CUR = r"(?:rs\.?|inr|₹|rupees)?\s*"


def _to_number(num_text, unit):
    value = float(num_text.replace(",", ""))
    unit = (unit or "").lower()
    if unit in ("k", "thousand"):
        value *= 1000
    elif unit in ("lakh", "lakhs", "lac", "lacs"):
        value *= 100000
    return value


def _find_budget(text):
    """Returns (budget_min, budget_max, matched_spans)."""
    spans = []
    # between X and Y
    m = re.search(
        r"between\s*" + _CUR + _NUM + _UNIT + r"\s*(?:and|to|-)\s*" + _CUR + _NUM + _UNIT,
        text, re.IGNORECASE,
    )
    if m:
        lo = _to_number(m.group(1), m.group(2))
        hi = _to_number(m.group(3), m.group(4) or m.group(2))
        spans.append(m.span())
        return min(lo, hi), max(lo, hi), spans

    # under / below / within / up to / max ...
    m = re.search(
        r"(?:under|below|less than|within|upto|up to|max(?:imum)?|budget(?: of| is)?|not more than|<=?)\s*"
        + _CUR + _NUM + _UNIT,
        text, re.IGNORECASE,
    )
    if m:
        spans.append(m.span())
        return None, _to_number(m.group(1), m.group(2)), spans

    # "₹25,000 or less" / "25000 rupees or below"
    m = re.search(_CUR + _NUM + _UNIT + r"\s*(?:or less|or below|or under|max)", text, re.IGNORECASE)
    if m:
        spans.append(m.span())
        return None, _to_number(m.group(1), m.group(2)), spans

    # above / over / more than X  -> minimum budget
    m = re.search(r"(?:above|over|more than|at least|minimum|>=?)\s*" + _CUR + _NUM + _UNIT
                  + r"(?!\s*(?:stars|star|rating|rated|★))", text, re.IGNORECASE)
    if m and _to_number(m.group(1), m.group(2)) > 5:  # >5 so ratings aren't mistaken for prices
        spans.append(m.span())
        return _to_number(m.group(1), m.group(2)), None, spans
    return None, None, spans


def _find_rating(text):
    """Returns (min_rating, span) or (None, None). Accepts 0-5 only."""
    patterns = [
        r"(?:at least|minimum|min|above|over|atleast|>=?)\s*(\d(?:\.\d)?)\s*\+?\s*(?:stars|star|rating|rated|★)",
        r"(\d(?:\.\d)?)\s*\+?\s*(?:stars|star|★)\s*(?:and above|or above|or more)?",
        r"(?:rating|rated)\s*(?:of|is)?\s*(?:at least|above|over|minimum|>=?)?\s*(\d(?:\.\d)?)\b",
        r"(\d(?:\.\d)?)\s*\+\s*rating",
        r"(\d(?:\.\d)?)\s*(?:rating|rated)",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            value = float(m.group(1))
            if 0 < value <= 5:
                return value, m.span()
    # Vague wording ("good ratings", "highly rated") -> 4.0. This is an
    # interpretation of the request and is shown to the shopper in the
    # "Understood as" summary so they can correct it.
    m = re.search(
        r"(?:good|great|high|top|best)\s+(?:ratings?|reviews?)|highly[- ]rated|well[- ]rated|top[- ]rated",
        text, re.IGNORECASE,
    )
    if m:
        return 4.0, m.span()
    return None, None


def _find_brand(text):
    for brand in KNOWN_BRANDS:
        if re.search(r"(?<![A-Za-z])" + re.escape(brand) + r"(?![A-Za-z])", text, re.IGNORECASE):
            return brand
    return None


def rule_parse(text):
    """Offline parse. Always returns the full result dict."""
    text = (text or "").strip()
    budget_min, budget_max, b_spans = _find_budget(text)
    rating, r_span = _find_rating(text)
    brand = _find_brand(text)

    # product phrase = text without the budget/rating phrases and filler
    spans = list(b_spans) + ([r_span] if r_span else [])
    product = text
    for start, end in sorted(spans, reverse=True):
        product = product[:start] + " " + product[end:]
    product = _FILLER_PREFIX.sub("", product)
    product = re.sub(r"\s+", " ", product).strip(" ,.;-")
    product = re.sub(r"\b(with|and|having|that has|which has|of)$", "", product, flags=re.I)
    product = product.strip(" ,.;-")

    return {
        "product": product,
        "budget_min": budget_min,
        "budget_max": budget_max,
        "brand": brand or "",
        "min_rating": rating,
        "interests": "",
        "constraints": [],
        "source": "rules",
    }


def _num_or_none(value, lo=0.0, hi=None):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if number < lo or (hi is not None and number > hi):
        return None
    return number


def ai_parse(text, lang="en"):
    """Groq JSON parse. Returns (dict|None, error|None)."""
    system = (
        "You convert a shopper's request into search parameters. Reply with JSON only. "
        "Do not invent values the shopper did not state; use null or an empty string "
        "when something is not mentioned. Prices are in Indian rupees (INR)."
    )
    user = (
        f'Request: "{text}"\n\nReturn exactly:\n'
        '{"product": "short English search phrase incl. key attributes (e.g. \'gaming laptop 16GB RAM\')", '
        '"brand": "", "budget_min": null, "budget_max": null, "min_rating": null, '
        '"interests": "comma separated, only if stated", '
        '"constraints": ["other stated requirements such as colour, size, feature"]}'
    )
    out, error, _ = ai_helpers.chat(
        [{"role": "system", "content": system}, {"role": "user", "content": user}],
        max_tokens=300, temperature=0.0, json_mode=True,
    )
    if error:
        return None, error
    data = ai_helpers.parse_json(out)
    if not data:
        return None, "api_error"
    return {
        "product": str(data.get("product") or "").strip(),
        "budget_min": _num_or_none(data.get("budget_min")),
        "budget_max": _num_or_none(data.get("budget_max")),
        "brand": str(data.get("brand") or "").strip(),
        "min_rating": _num_or_none(data.get("min_rating"), 0.0, 5.0),
        "interests": str(data.get("interests") or "").strip(),
        "constraints": [str(c).strip() for c in (data.get("constraints") or []) if str(c).strip()][:5],
        "source": "ai",
    }, None


def parse_query(text, lang="en"):
    """
    Hybrid parse used by the UI. Returns (params_dict, ai_error_or_None).
    Numbers/brand detected by rules take priority over the model's.
    """
    rules = rule_parse(text)
    if not ai_helpers.has_groq():
        return rules, "no_api_key"
    ai, error = ai_parse(text, lang)
    if ai is None:
        return rules, error

    merged = dict(ai)
    for field in ("budget_min", "budget_max", "min_rating"):
        if rules.get(field) is not None:
            merged[field] = rules[field]
    if rules.get("brand"):
        merged["brand"] = rules["brand"]
    if not merged.get("product"):
        merged["product"] = rules.get("product") or text.strip()
    merged["source"] = "ai+rules"
    return merged, None


def params_to_profile(params, base_profile=None):
    """
    Merges parsed NL parameters over the shopper's saved/manual profile
    in the same dict shape model.build_search_query()/rank_products() use.
    Anything the shopper didn't mention keeps its profile value.
    """
    profile = dict(base_profile or {})
    product = params.get("product") or ""
    constraints = params.get("constraints") or []
    # extra constraints help the search query (e.g. "black", "16GB")
    extra = [c for c in constraints if c.lower() not in product.lower()][:2]
    profile["product_query"] = " ".join([product] + extra).strip()
    if params.get("brand"):
        profile["brand_preference"] = params["brand"]
    if params.get("budget_max"):
        profile["budget_max"] = params["budget_max"]
    if params.get("budget_min"):
        profile["budget_min"] = params["budget_min"]
    if params.get("min_rating") is not None:
        profile["min_rating"] = params["min_rating"]
    if params.get("interests"):
        profile["interests"] = params["interests"]
    return profile


def looks_like_product_request(text):
    """Cheap heuristic used by the chat assistant to decide whether to
    run a live product search for a message."""
    t = (text or "").lower()
    if re.search(r"\bcompare\b|\bwhy (?:is|are|should)\b|\bhow (?:do|does|to)\b", t):
        return False
    verbs = ("find", "show me", "search", "looking for", "i need", "i want",
             "suggest", "recommend", "get me", "best ", "under ", "below ")
    has_verb = any(v in t for v in verbs)
    b_min, b_max, _ = _find_budget(t)
    return has_verb and (b_max is not None or b_min is not None or len(t.split()) >= 3)
