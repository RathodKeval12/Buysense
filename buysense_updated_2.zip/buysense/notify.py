"""
notify.py
---------
Optional email notification support. Sends a short email whenever a
user (who has opted in) generates a new set of live, personalized
product recommendations.

SMTP settings are read from environment variables first, then from
st.secrets. Nothing is sent — and no error is raised in the UI — if
SMTP isn't configured; get_smtp_config() simply returns None and the
caller can show a one-line hint instead.

Required settings (env vars or .streamlit/secrets.toml):
    SMTP_HOST      e.g. smtp.gmail.com
    SMTP_PORT      e.g. 587
    SMTP_USER      the mailbox username / address that sends the mail
    SMTP_PASSWORD  the mailbox password or app-password
    SMTP_FROM      (optional) "From" address, defaults to SMTP_USER
"""

import os
import smtplib
from email.mime.text import MIMEText

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None


def _get_setting(key):
    value = os.environ.get(key, "")
    if not value and st is not None:
        try:
            value = st.secrets.get(key, "")
        except Exception:
            value = ""
    return value


def get_smtp_config():
    """Returns a dict of SMTP settings, or None if not fully configured."""
    host = _get_setting("SMTP_HOST")
    port = _get_setting("SMTP_PORT")
    user = _get_setting("SMTP_USER")
    password = _get_setting("SMTP_PASSWORD")
    sender = _get_setting("SMTP_FROM") or user

    if not (host and port and user and password):
        return None

    try:
        port = int(port)
    except ValueError:
        return None

    return {
        "host": host,
        "port": port,
        "user": user,
        "password": password,
        "sender": sender,
    }


def send_recommendation_email(to_email, username, query, products):
    """
    Sends a short notification email about a new, live BuySense
    recommendation. `products` are the real SerpApi results shown to
    the shopper — titles/prices are taken as-is, nothing is invented.
    Returns (success: bool, message: str).
    """
    config = get_smtp_config()
    if config is None:
        return False, "smtp_not_configured"

    if not to_email or "@" not in to_email:
        return False, "invalid_email"

    product_lines = "\n".join(
        f"  • {p.get('title')} - {p.get('price') or 'price unavailable'}"
        for p in products
    ) or "  (no products found for this search)"

    body = (
        f"Hi {username},\n\n"
        f"Your latest BuySense recommendation is ready:\n\n"
        f"  Search: {query}\n\n"
        f"Top real products (live from Google Shopping):\n{product_lines}\n\n"
        f"— BuySense · Intelligent Product Discovery Engine"
    )

    message = MIMEText(body, "plain", "utf-8")
    message["Subject"] = f"BuySense: new recommendations for '{query}'"
    message["From"] = config["sender"]
    message["To"] = to_email

    try:
        with smtplib.SMTP(config["host"], config["port"], timeout=10) as server:
            server.starttls()
            server.login(config["user"], config["password"])
            server.sendmail(config["sender"], [to_email], message.as_string())
        return True, "sent"
    except Exception as exc:  # pragma: no cover - network/credentials dependent
        return False, str(exc)


def send_alert_email(to_email, username, subject, body_lines):
    """
    Generic alert email used by price-drop / back-in-stock alerts.
    `body_lines` is a list of already-formatted strings (real data only).
    Returns (success: bool, message: str) — same contract as
    send_recommendation_email().
    """
    config = get_smtp_config()
    if config is None:
        return False, "smtp_not_configured"
    if not to_email or "@" not in to_email:
        return False, "invalid_email"

    body = (
        f"Hi {username},\n\n"
        + "\n".join(body_lines)
        + "\n\n— BuySense · Intelligent Product Discovery Engine"
    )
    message = MIMEText(body, "plain", "utf-8")
    message["Subject"] = subject
    message["From"] = config["sender"]
    message["To"] = to_email

    try:
        with smtplib.SMTP(config["host"], config["port"], timeout=10) as server:
            server.starttls()
            server.login(config["user"], config["password"])
            server.sendmail(config["sender"], [to_email], message.as_string())
        return True, "sent"
    except Exception as exc:  # pragma: no cover - network/credentials dependent
        return False, str(exc)
