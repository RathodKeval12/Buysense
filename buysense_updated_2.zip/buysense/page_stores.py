"""
page_stores.py
--------------
Nearby Store Finder (OpenStreetMap, no API key). Location is used only
for the lookup — it is not saved anywhere.
"""

import pandas as pd
import streamlit as st

import db
import model as ml
import stores
import templates as tpl
from i18n import t


def _browser_location():
    """Optional: uses the browser's geolocation if `streamlit-js-eval`
    is installed. Returns (lat, lon) or None."""
    try:
        from streamlit_js_eval import get_geolocation
    except Exception:
        return None
    try:
        loc = get_geolocation()
    except Exception:
        return None
    if isinstance(loc, dict) and loc.get("coords"):
        return loc["coords"].get("latitude"), loc["coords"].get("longitude")
    return None


def render(conn, username):
    tpl.hero(t("stores_title"), t("stores_subtitle"), pill_text=t("stores_pill"))
    profile = db.get_profile(conn, username) if username else {}
    default_cat = (profile.get("preferred_categories") or "").split(",")[0].strip()
    cats = ml.CATEGORY_OPTIONS
    category = st.selectbox(
        t("stores_category"), cats, index=cats.index(default_cat) if default_cat in cats else 0
    )

    use_gps = False
    try:
        import streamlit_js_eval  # noqa: F401
        use_gps = st.checkbox(t("stores_use_gps"), key="stores_gps")
    except Exception:
        st.caption(t("stores_gps_unavailable"))

    # The browser-location component must render on every run to deliver its
    # value, so it is read here (before the button), not after the click.
    gps = _browser_location() if use_gps else None
    if use_gps and gps is None:
        st.caption(t("stores_gps_waiting"))

    place = st.text_input(t("stores_location"), placeholder="Rajkot, Gujarat", key="stores_place")
    radius = st.slider(t("stores_radius"), 1, 10, 3)
    st.caption("🔒 " + t("stores_privacy"))

    if not st.button(t("stores_search_btn"), key="stores_go"):
        return

    lat = lon = None
    if use_gps:
        if gps and gps[0] is not None:
            lat, lon = gps
        else:
            st.warning(t("stores_gps_denied"))
    if lat is None and not place.strip():
        st.warning(t("stores_need_location"))
        return

    with st.spinner(t("loading")):
        found, center, error = stores.find_stores(category, place, lat, lon, radius)

    where = place.strip() or "my location"
    maps_url = stores.maps_search_url(category, where)
    if error == "location_not_found":
        st.error(t("stores_not_found"))
    elif error == "network":
        st.error(t("stores_network"))
        st.markdown(f"[🗺️ {t('stores_open_maps')}]({maps_url})")
    elif error == "no_stores":
        st.info(t("stores_none"))
        st.markdown(f"[🗺️ {t('stores_open_maps')}]({maps_url})")
    elif found:
        df = pd.DataFrame(found)
        st.map(df.rename(columns={"lon": "longitude", "lat": "latitude"})[["latitude", "longitude"]])
        view = df[["name", "type", "distance_km", "address", "osm_url"]].rename(columns={
            "name": t("store_name"), "type": t("store_type"), "distance_km": t("distance_km"),
            "address": t("address"), "osm_url": t("link"),
        })
        st.dataframe(view, use_container_width=True, hide_index=True,
                     column_config={t("link"): st.column_config.LinkColumn(t("link"), display_text="🗺️")})
        st.caption(t("stores_source_note"))
        st.markdown(f"[🗺️ {t('stores_open_maps')}]({maps_url})")
